// ============================================================================
//
// Copyright (c) 2006-2015, Talend SA
//
// Ce code source a été automatiquement généré par_Talend Open Studio for Data Integration
// / Soumis à la Licence Apache, Version 2.0 (la "Licence") ;
// votre utilisation de ce fichier doit respecter les termes de la Licence.
// Vous pouvez obtenir une copie de la Licence sur
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Sauf lorsqu'explicitement prévu par la loi en vigueur ou accepté par écrit, le logiciel
// distribué sous la Licence est distribué "TEL QUEL",
// SANS GARANTIE OU CONDITION D'AUCUNE SORTE, expresse ou implicite.
// Consultez la Licence pour connaître la terminologie spécifique régissant les autorisations et
// les limites prévues par la Licence.


package local_project.stg_load_0_1;

import routines.Numeric;
import routines.DataOperation;
import routines.TalendDataGenerator;
import routines.TalendStringUtil;
import routines.TalendString;
import routines.StringHandling;
import routines.Relational;
import routines.TalendDate;
import routines.Mathematical;
import routines.Clean;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;
 





@SuppressWarnings("unused")

/**
 * Job: STG_Load Purpose: Chargement des données dans STG<br>
 * Description:  <br>
 * @author user@talend.com
 * @version 8.0.1.20211109_1610
 * @status 
 */
public class STG_Load implements TalendJob {

protected static void logIgnoredError(String message, Throwable cause) {
       System.err.println(message);
       if (cause != null) {
               cause.printStackTrace();
       }

}


	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}
	
	private final static String defaultCharset = java.nio.charset.Charset.defaultCharset().name();

	
	private final static String utf8Charset = "UTF-8";
	//contains type for every context property
	public class PropertiesWithType extends java.util.Properties {
		private static final long serialVersionUID = 1L;
		private java.util.Map<String,String> propertyTypes = new java.util.HashMap<>();
		
		public PropertiesWithType(java.util.Properties properties){
			super(properties);
		}
		public PropertiesWithType(){
			super();
		}
		
		public void setContextType(String key, String type) {
			propertyTypes.put(key,type);
		}
	
		public String getContextType(String key) {
			return propertyTypes.get(key);
		}
	}
	
	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();
	// create application properties with default
	public class ContextProperties extends PropertiesWithType {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties){
			super(properties);
		}
		public ContextProperties(){
			super();
		}

		public void synchronizeContext(){
			
			if(AIRLINE_AdditionalParams != null){
				
					this.setProperty("AIRLINE_AdditionalParams", AIRLINE_AdditionalParams.toString());
				
			}
			
			if(AIRLINE_Login != null){
				
					this.setProperty("AIRLINE_Login", AIRLINE_Login.toString());
				
			}
			
			if(AIRLINE_Password != null){
				
					this.setProperty("AIRLINE_Password", AIRLINE_Password.toString());
				
			}
			
			if(AIRLINE_Port != null){
				
					this.setProperty("AIRLINE_Port", AIRLINE_Port.toString());
				
			}
			
			if(AIRLINE_Schema != null){
				
					this.setProperty("AIRLINE_Schema", AIRLINE_Schema.toString());
				
			}
			
			if(AIRLINE_Server != null){
				
					this.setProperty("AIRLINE_Server", AIRLINE_Server.toString());
				
			}
			
			if(AIRLINE_Sid != null){
				
					this.setProperty("AIRLINE_Sid", AIRLINE_Sid.toString());
				
			}
			
			if(source_path != null){
				
					this.setProperty("source_path", source_path.toString());
				
			}
			
		}
		
		//if the stored or passed value is "<TALEND_NULL>" string, it mean null
		public String getStringValue(String key) {
			String origin_value = this.getProperty(key);
			if(NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY.equals(origin_value)) {
				return null;
			}
			return origin_value;
		}

public String AIRLINE_AdditionalParams;
public String getAIRLINE_AdditionalParams(){
	return this.AIRLINE_AdditionalParams;
}
public String AIRLINE_Login;
public String getAIRLINE_Login(){
	return this.AIRLINE_Login;
}
public java.lang.String AIRLINE_Password;
public java.lang.String getAIRLINE_Password(){
	return this.AIRLINE_Password;
}
public String AIRLINE_Port;
public String getAIRLINE_Port(){
	return this.AIRLINE_Port;
}
public String AIRLINE_Schema;
public String getAIRLINE_Schema(){
	return this.AIRLINE_Schema;
}
public String AIRLINE_Server;
public String getAIRLINE_Server(){
	return this.AIRLINE_Server;
}
public String AIRLINE_Sid;
public String getAIRLINE_Sid(){
	return this.AIRLINE_Sid;
}
public String source_path;
public String getSource_path(){
	return this.source_path;
}
	}
	protected ContextProperties context = new ContextProperties(); // will be instanciated by MS.
	public ContextProperties getContext() {
		return this.context;
	}
	private final String jobVersion = "0.1";
	private final String jobName = "STG_Load";
	private final String projectName = "LOCAL_PROJECT";
	public Integer errorCode = null;
	private String currentComponent = "";
	
		private final java.util.Map<String, Object> globalMap = new java.util.HashMap<String, Object>();
        private final static java.util.Map<String, Object> junitGlobalMap = new java.util.HashMap<String, Object>();
	
		private final java.util.Map<String, Long> start_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Long> end_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Boolean> ok_Hash = new java.util.HashMap<String, Boolean>();
		public  final java.util.List<String[]> globalBuffer = new java.util.ArrayList<String[]>();
	

private RunStat runStat = new RunStat();

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";
	
	private final static String KEY_DB_DATASOURCES_RAW = "KEY_DB_DATASOURCES_RAW";

	public void setDataSources(java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources.entrySet()) {
			talendDataSources.put(dataSourceEntry.getKey(), new routines.system.TalendDataSource(dataSourceEntry.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}
	
	public void setDataSourceReferences(List serviceReferences) throws Exception{
		
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		java.util.Map<String, javax.sql.DataSource> dataSources = new java.util.HashMap<String, javax.sql.DataSource>();
		
		for (java.util.Map.Entry<String, javax.sql.DataSource> entry : BundleUtils.getServices(serviceReferences,  javax.sql.DataSource.class).entrySet()) {
                    dataSources.put(entry.getKey(), entry.getValue());
                    talendDataSources.put(entry.getKey(), new routines.system.TalendDataSource(entry.getValue()));
		}

		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}


private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(new java.io.BufferedOutputStream(baos));

public String getExceptionStackTrace() {
	if ("failure".equals(this.getStatus())) {
		errorMessagePS.flush();
		return baos.toString();
	}
	return null;
}

private Exception exception;

public Exception getException() {
	if ("failure".equals(this.getStatus())) {
		return this.exception;
	}
	return null;
}

private class TalendException extends Exception {

	private static final long serialVersionUID = 1L;

	private java.util.Map<String, Object> globalMap = null;
	private Exception e = null;
	private String currentComponent = null;
	private String virtualComponentName = null;
	
	public void setVirtualComponentName (String virtualComponentName){
		this.virtualComponentName = virtualComponentName;
	}

	private TalendException(Exception e, String errorComponent, final java.util.Map<String, Object> globalMap) {
		this.currentComponent= errorComponent;
		this.globalMap = globalMap;
		this.e = e;
	}

	public Exception getException() {
		return this.e;
	}

	public String getCurrentComponent() {
		return this.currentComponent;
	}

	
    public String getExceptionCauseMessage(Exception e){
        Throwable cause = e;
        String message = null;
        int i = 10;
        while (null != cause && 0 < i--) {
            message = cause.getMessage();
            if (null == message) {
                cause = cause.getCause();
            } else {
                break;          
            }
        }
        if (null == message) {
            message = e.getClass().getName();
        }   
        return message;
    }

	@Override
	public void printStackTrace() {
		if (!(e instanceof TalendException || e instanceof TDieException)) {
			if(virtualComponentName!=null && currentComponent.indexOf(virtualComponentName+"_")==0){
				globalMap.put(virtualComponentName+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			}
			globalMap.put(currentComponent+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			System.err.println("Exception in component " + currentComponent + " (" + jobName + ")");
		}
		if (!(e instanceof TDieException)) {
			if(e instanceof TalendException){
				e.printStackTrace();
			} else {
				e.printStackTrace();
				e.printStackTrace(errorMessagePS);
				STG_Load.this.exception = e;
			}
		}
		if (!(e instanceof TalendException)) {
		try {
			for (java.lang.reflect.Method m : this.getClass().getEnclosingClass().getMethods()) {
				if (m.getName().compareTo(currentComponent + "_error") == 0) {
					m.invoke(STG_Load.this, new Object[] { e , currentComponent, globalMap});
					break;
				}
			}

			if(!(e instanceof TDieException)){
			}
		} catch (Exception e) {
			this.e.printStackTrace();
		}
		}
	}
}

			public void tDBConnection_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBConnection_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileInputDelimited_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tUniqRow_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSchemaComplianceCheck_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileInputDelimited_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tUniqRow_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSchemaComplianceCheck_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileInputDelimited_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tUniqRow_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSchemaComplianceCheck_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_6_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileInputDelimited_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_4_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tUniqRow_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_4_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSchemaComplianceCheck_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_4_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_7_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_4_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_4_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileInputDelimited_5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_5_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tUniqRow_5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_5_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSchemaComplianceCheck_5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_5_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_8_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_5_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_5_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileInputDelimited_6_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_6_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tUniqRow_6_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_6_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSchemaComplianceCheck_6_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_6_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_9_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_6_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_6_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_6_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileInputDelimited_7_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_7_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tUniqRow_7_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_7_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSchemaComplianceCheck_7_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_7_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_10_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_7_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_7_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_7_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileInputDelimited_8_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_8_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tUniqRow_8_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_8_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSchemaComplianceCheck_8_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_8_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_8_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_8_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_8_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileInputDelimited_9_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_9_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tUniqRow_9_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_9_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSchemaComplianceCheck_9_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_9_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_9_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_9_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_9_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileInputDelimited_10_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_10_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tUniqRow_10_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_10_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSchemaComplianceCheck_10_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_10_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_10_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_10_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_10_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileInputDelimited_11_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_11_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tUniqRow_11_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_11_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSchemaComplianceCheck_11_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_11_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_12_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_11_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_11_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_11_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileInputDelimited_12_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_12_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tUniqRow_12_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_12_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSchemaComplianceCheck_12_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_12_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_13_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_12_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBOutput_12_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputDelimited_12_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBCommit_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDBCommit_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBConnection_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFileInputDelimited_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFileInputDelimited_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFileInputDelimited_3_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFileInputDelimited_4_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFileInputDelimited_5_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFileInputDelimited_6_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFileInputDelimited_7_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFileInputDelimited_8_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFileInputDelimited_9_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFileInputDelimited_10_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFileInputDelimited_11_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFileInputDelimited_12_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBCommit_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
	





public void tDBConnection_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBConnection_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tDBConnection_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBConnection_2", false);
		start_Hash.put("tDBConnection_2", System.currentTimeMillis());
		
	
	currentComponent="tDBConnection_2";

	
		int tos_count_tDBConnection_2 = 0;
		
	

	
        String url_tDBConnection_2 = "jdbc:oracle:thin:@" + context.AIRLINE_Server + ":" + context.AIRLINE_Port + ":" + context.AIRLINE_Sid;
    	globalMap.put("connectionType_" + "tDBConnection_2", "ORACLE_SID");
	String dbUser_tDBConnection_2 = context.AIRLINE_Login;
	
	
		
	final String decryptedPassword_tDBConnection_2 = context.AIRLINE_Password; 
		String dbPwd_tDBConnection_2 = decryptedPassword_tDBConnection_2;
	
	
	java.sql.Connection conn_tDBConnection_2 = null;
	
		
			String driverClass_tDBConnection_2 = "oracle.jdbc.OracleDriver";
			java.lang.Class jdbcclazz_tDBConnection_2 = java.lang.Class.forName(driverClass_tDBConnection_2);
			globalMap.put("driverClass_tDBConnection_2", driverClass_tDBConnection_2);
		
			java.util.Properties atnParamsPrope_tDBConnection_2 = new java.util.Properties();
			    atnParamsPrope_tDBConnection_2.put("user",dbUser_tDBConnection_2);
			    atnParamsPrope_tDBConnection_2.put("password",dbPwd_tDBConnection_2);
			if(context.AIRLINE_AdditionalParams != null && !"\"\"".equals(context.AIRLINE_AdditionalParams) && !"".equals(context.AIRLINE_AdditionalParams)){
                atnParamsPrope_tDBConnection_2.load(new java.io.ByteArrayInputStream(context.AIRLINE_AdditionalParams.replace("&", "\n").getBytes()));
            }
         
			conn_tDBConnection_2 = java.sql.DriverManager.getConnection(url_tDBConnection_2, atnParamsPrope_tDBConnection_2);

		globalMap.put("conn_tDBConnection_2", conn_tDBConnection_2);
	if (null != conn_tDBConnection_2) {
		
			conn_tDBConnection_2.setAutoCommit(false);
	}
        globalMap.put("host_" + "tDBConnection_2",context.AIRLINE_Server);
        globalMap.put("port_" + "tDBConnection_2",context.AIRLINE_Port);
        globalMap.put("dbname_" + "tDBConnection_2",context.AIRLINE_Sid);

	globalMap.put("dbschema_" + "tDBConnection_2", context.AIRLINE_Schema);
	globalMap.put("username_" + "tDBConnection_2",context.AIRLINE_Login);
	globalMap.put("password_" + "tDBConnection_2",dbPwd_tDBConnection_2);

 



/**
 * [tDBConnection_2 begin ] stop
 */
	
	/**
	 * [tDBConnection_2 main ] start
	 */

	

	
	
	currentComponent="tDBConnection_2";

	

 


	tos_count_tDBConnection_2++;

/**
 * [tDBConnection_2 main ] stop
 */
	
	/**
	 * [tDBConnection_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBConnection_2";

	

 



/**
 * [tDBConnection_2 process_data_begin ] stop
 */
	
	/**
	 * [tDBConnection_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBConnection_2";

	

 



/**
 * [tDBConnection_2 process_data_end ] stop
 */
	
	/**
	 * [tDBConnection_2 end ] start
	 */

	

	
	
	currentComponent="tDBConnection_2";

	

 

ok_Hash.put("tDBConnection_2", true);
end_Hash.put("tDBConnection_2", System.currentTimeMillis());




/**
 * [tDBConnection_2 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tDBConnection_2:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk1", 0, "ok");
								} 
							
							tFileInputDelimited_1Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBConnection_2 finally ] start
	 */

	

	
	
	currentComponent="tDBConnection_2";

	

 



/**
 * [tDBConnection_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBConnection_2_SUBPROCESS_STATE", 1);
	}
	


public static class out1Struct implements routines.system.IPersistableRow<out1Struct> {
    final static byte[] commonByteArrayLock_LOCAL_PROJECT_STG_Load = new byte[0];
    static byte[] commonByteArray_LOCAL_PROJECT_STG_Load = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int ID;

				public int getID () {
					return this.ID;
				}
				
			    public String SK_APPAREIL_ID;

				public String getSK_APPAREIL_ID () {
					return this.SK_APPAREIL_ID;
				}
				
			    public String MARQUE;

				public String getMARQUE () {
					return this.MARQUE;
				}
				
			    public String MODELE;

				public String getMODELE () {
					return this.MODELE;
				}
				
			    public int CAPACITE;

				public int getCAPACITE () {
					return this.CAPACITE;
				}
				
			    public int ANNEE_FABRICATION;

				public int getANNEE_FABRICATION () {
					return this.ANNEE_FABRICATION;
				}
				
			    public String STATUT;

				public String getSTATUT () {
					return this.STATUT;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.ID;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final out1Struct other = (out1Struct) obj;
		
						if (this.ID != other.ID)
							return false;
					

		return true;
    }

	public void copyDataTo(out1Struct other) {

		other.ID = this.ID;
	            other.SK_APPAREIL_ID = this.SK_APPAREIL_ID;
	            other.MARQUE = this.MARQUE;
	            other.MODELE = this.MODELE;
	            other.CAPACITE = this.CAPACITE;
	            other.ANNEE_FABRICATION = this.ANNEE_FABRICATION;
	            other.STATUT = this.STATUT;
	            
	}

	public void copyKeysDataTo(out1Struct other) {

		other.ID = this.ID;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
			        this.ID = dis.readInt();
					
					this.SK_APPAREIL_ID = readString(dis);
					
					this.MARQUE = readString(dis);
					
					this.MODELE = readString(dis);
					
			        this.CAPACITE = dis.readInt();
					
			        this.ANNEE_FABRICATION = dis.readInt();
					
					this.STATUT = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
			        this.ID = dis.readInt();
					
					this.SK_APPAREIL_ID = readString(dis);
					
					this.MARQUE = readString(dis);
					
					this.MODELE = readString(dis);
					
			        this.CAPACITE = dis.readInt();
					
			        this.ANNEE_FABRICATION = dis.readInt();
					
					this.STATUT = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.ID);
					
					// String
				
						writeString(this.SK_APPAREIL_ID,dos);
					
					// String
				
						writeString(this.MARQUE,dos);
					
					// String
				
						writeString(this.MODELE,dos);
					
					// int
				
		            	dos.writeInt(this.CAPACITE);
					
					// int
				
		            	dos.writeInt(this.ANNEE_FABRICATION);
					
					// String
				
						writeString(this.STATUT,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.ID);
					
					// String
				
						writeString(this.SK_APPAREIL_ID,dos);
					
					// String
				
						writeString(this.MARQUE,dos);
					
					// String
				
						writeString(this.MODELE,dos);
					
					// int
				
		            	dos.writeInt(this.CAPACITE);
					
					// int
				
		            	dos.writeInt(this.ANNEE_FABRICATION);
					
					// String
				
						writeString(this.STATUT,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("ID="+String.valueOf(ID));
		sb.append(",SK_APPAREIL_ID="+SK_APPAREIL_ID);
		sb.append(",MARQUE="+MARQUE);
		sb.append(",MODELE="+MODELE);
		sb.append(",CAPACITE="+String.valueOf(CAPACITE));
		sb.append(",ANNEE_FABRICATION="+String.valueOf(ANNEE_FABRICATION));
		sb.append(",STATUT="+STATUT);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(out1Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.ID, other.ID);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row3Struct implements routines.system.IPersistableRow<row3Struct> {
    final static byte[] commonByteArrayLock_LOCAL_PROJECT_STG_Load = new byte[0];
    static byte[] commonByteArray_LOCAL_PROJECT_STG_Load = new byte[0];

	
			    public String IDAppareil;

				public String getIDAppareil () {
					return this.IDAppareil;
				}
				
			    public String Marque;

				public String getMarque () {
					return this.Marque;
				}
				
			    public String Modele;

				public String getModele () {
					return this.Modele;
				}
				
			    public Integer Capacite;

				public Integer getCapacite () {
					return this.Capacite;
				}
				
			    public Integer AnneeFabrication;

				public Integer getAnneeFabrication () {
					return this.AnneeFabrication;
				}
				
			    public String Statut;

				public String getStatut () {
					return this.Statut;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
					this.IDAppareil = readString(dis);
					
					this.Marque = readString(dis);
					
					this.Modele = readString(dis);
					
						this.Capacite = readInteger(dis);
					
						this.AnneeFabrication = readInteger(dis);
					
					this.Statut = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
					this.IDAppareil = readString(dis);
					
					this.Marque = readString(dis);
					
					this.Modele = readString(dis);
					
						this.Capacite = readInteger(dis);
					
						this.AnneeFabrication = readInteger(dis);
					
					this.Statut = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.IDAppareil,dos);
					
					// String
				
						writeString(this.Marque,dos);
					
					// String
				
						writeString(this.Modele,dos);
					
					// Integer
				
						writeInteger(this.Capacite,dos);
					
					// Integer
				
						writeInteger(this.AnneeFabrication,dos);
					
					// String
				
						writeString(this.Statut,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.IDAppareil,dos);
					
					// String
				
						writeString(this.Marque,dos);
					
					// String
				
						writeString(this.Modele,dos);
					
					// Integer
				
						writeInteger(this.Capacite,dos);
					
					// Integer
				
						writeInteger(this.AnneeFabrication,dos);
					
					// String
				
						writeString(this.Statut,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("IDAppareil="+IDAppareil);
		sb.append(",Marque="+Marque);
		sb.append(",Modele="+Modele);
		sb.append(",Capacite="+String.valueOf(Capacite));
		sb.append(",AnneeFabrication="+String.valueOf(AnneeFabrication));
		sb.append(",Statut="+Statut);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row3Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row2Struct implements routines.system.IPersistableRow<row2Struct> {
    final static byte[] commonByteArrayLock_LOCAL_PROJECT_STG_Load = new byte[0];
    static byte[] commonByteArray_LOCAL_PROJECT_STG_Load = new byte[0];

	
			    public String IDAppareil;

				public String getIDAppareil () {
					return this.IDAppareil;
				}
				
			    public String Marque;

				public String getMarque () {
					return this.Marque;
				}
				
			    public String Modele;

				public String getModele () {
					return this.Modele;
				}
				
			    public Integer Capacite;

				public Integer getCapacite () {
					return this.Capacite;
				}
				
			    public Integer AnneeFabrication;

				public Integer getAnneeFabrication () {
					return this.AnneeFabrication;
				}
				
			    public String Statut;

				public String getStatut () {
					return this.Statut;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
					this.IDAppareil = readString(dis);
					
					this.Marque = readString(dis);
					
					this.Modele = readString(dis);
					
						this.Capacite = readInteger(dis);
					
						this.AnneeFabrication = readInteger(dis);
					
					this.Statut = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
					this.IDAppareil = readString(dis);
					
					this.Marque = readString(dis);
					
					this.Modele = readString(dis);
					
						this.Capacite = readInteger(dis);
					
						this.AnneeFabrication = readInteger(dis);
					
					this.Statut = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.IDAppareil,dos);
					
					// String
				
						writeString(this.Marque,dos);
					
					// String
				
						writeString(this.Modele,dos);
					
					// Integer
				
						writeInteger(this.Capacite,dos);
					
					// Integer
				
						writeInteger(this.AnneeFabrication,dos);
					
					// String
				
						writeString(this.Statut,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.IDAppareil,dos);
					
					// String
				
						writeString(this.Marque,dos);
					
					// String
				
						writeString(this.Modele,dos);
					
					// Integer
				
						writeInteger(this.Capacite,dos);
					
					// Integer
				
						writeInteger(this.AnneeFabrication,dos);
					
					// String
				
						writeString(this.Statut,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("IDAppareil="+IDAppareil);
		sb.append(",Marque="+Marque);
		sb.append(",Modele="+Modele);
		sb.append(",Capacite="+String.valueOf(Capacite));
		sb.append(",AnneeFabrication="+String.valueOf(AnneeFabrication));
		sb.append(",Statut="+Statut);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row2Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row1Struct implements routines.system.IPersistableRow<row1Struct> {
    final static byte[] commonByteArrayLock_LOCAL_PROJECT_STG_Load = new byte[0];
    static byte[] commonByteArray_LOCAL_PROJECT_STG_Load = new byte[0];

	
			    public String IDAppareil;

				public String getIDAppareil () {
					return this.IDAppareil;
				}
				
			    public String Marque;

				public String getMarque () {
					return this.Marque;
				}
				
			    public String Modele;

				public String getModele () {
					return this.Modele;
				}
				
			    public Integer Capacite;

				public Integer getCapacite () {
					return this.Capacite;
				}
				
			    public Integer AnneeFabrication;

				public Integer getAnneeFabrication () {
					return this.AnneeFabrication;
				}
				
			    public String Statut;

				public String getStatut () {
					return this.Statut;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
					this.IDAppareil = readString(dis);
					
					this.Marque = readString(dis);
					
					this.Modele = readString(dis);
					
						this.Capacite = readInteger(dis);
					
						this.AnneeFabrication = readInteger(dis);
					
					this.Statut = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
					this.IDAppareil = readString(dis);
					
					this.Marque = readString(dis);
					
					this.Modele = readString(dis);
					
						this.Capacite = readInteger(dis);
					
						this.AnneeFabrication = readInteger(dis);
					
					this.Statut = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.IDAppareil,dos);
					
					// String
				
						writeString(this.Marque,dos);
					
					// String
				
						writeString(this.Modele,dos);
					
					// Integer
				
						writeInteger(this.Capacite,dos);
					
					// Integer
				
						writeInteger(this.AnneeFabrication,dos);
					
					// String
				
						writeString(this.Statut,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.IDAppareil,dos);
					
					// String
				
						writeString(this.Marque,dos);
					
					// String
				
						writeString(this.Modele,dos);
					
					// Integer
				
						writeInteger(this.Capacite,dos);
					
					// Integer
				
						writeInteger(this.AnneeFabrication,dos);
					
					// String
				
						writeString(this.Statut,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("IDAppareil="+IDAppareil);
		sb.append(",Marque="+Marque);
		sb.append(",Modele="+Modele);
		sb.append(",Capacite="+String.valueOf(Capacite));
		sb.append(",AnneeFabrication="+String.valueOf(AnneeFabrication));
		sb.append(",Statut="+Statut);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row1Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tFileInputDelimited_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFileInputDelimited_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row1Struct row1 = new row1Struct();
row2Struct row2 = new row2Struct();
row3Struct row3 = new row3Struct();
out1Struct out1 = new out1Struct();







	
	/**
	 * [tDBOutput_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_2", false);
		start_Hash.put("tDBOutput_2", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_2";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"out1");
					}
				
		int tos_count_tDBOutput_2 = 0;
		






        int updateKeyCount_tDBOutput_2 = 1;
        if(updateKeyCount_tDBOutput_2 < 1) {
            throw new RuntimeException("For update, Schema must have a key");
        } else if (updateKeyCount_tDBOutput_2 == 7 && true) {
                    System.err.println("For update, every Schema column can not be a key");
        }
    
    int nb_line_tDBOutput_2 = 0;
    int nb_line_update_tDBOutput_2 = 0;
    int nb_line_inserted_tDBOutput_2 = 0;
    int nb_line_deleted_tDBOutput_2 = 0;
    int nb_line_rejected_tDBOutput_2 = 0;

    int tmp_batchUpdateCount_tDBOutput_2 = 0;

    int deletedCount_tDBOutput_2=0;
    int updatedCount_tDBOutput_2=0;
    int insertedCount_tDBOutput_2=0;
    int rowsToCommitCount_tDBOutput_2=0;
    int rejectedCount_tDBOutput_2=0;

    boolean whetherReject_tDBOutput_2 = false;

    java.sql.Connection conn_tDBOutput_2 = null;

    //optional table
    String dbschema_tDBOutput_2 = null;
    String tableName_tDBOutput_2 = null;
        dbschema_tDBOutput_2 = (String)globalMap.get("dbschema_tDBConnection_2");
		
        conn_tDBOutput_2 = (java.sql.Connection)globalMap.get("conn_tDBConnection_2");
        int count_tDBOutput_2=0;

        if(dbschema_tDBOutput_2 == null || dbschema_tDBOutput_2.trim().length() == 0) {
            tableName_tDBOutput_2 = ("STG_DIM_APPAREILS");
        } else {
            tableName_tDBOutput_2 = dbschema_tDBOutput_2 + "." + ("STG_DIM_APPAREILS");
        }
            try (java.sql.Statement stmtClear_tDBOutput_2 = conn_tDBOutput_2.createStatement()) {
                stmtClear_tDBOutput_2.executeUpdate("DELETE FROM " + tableName_tDBOutput_2 + "");
            }
                java.sql.PreparedStatement pstmt_tDBOutput_2 = conn_tDBOutput_2.prepareStatement("SELECT COUNT(1) FROM " + tableName_tDBOutput_2 + " WHERE ID = ?");
                resourceMap.put("pstmt_tDBOutput_2", pstmt_tDBOutput_2);
                String insert_tDBOutput_2 = "INSERT INTO " + tableName_tDBOutput_2 + " (ID,SK_APPAREIL_ID,MARQUE,MODELE,CAPACITE,ANNEE_FABRICATION,STATUT) VALUES (?,?,?,?,?,?,?)";    
                java.sql.PreparedStatement pstmtInsert_tDBOutput_2 = conn_tDBOutput_2.prepareStatement(insert_tDBOutput_2);
                resourceMap.put("pstmtInsert_tDBOutput_2", pstmtInsert_tDBOutput_2);
                String update_tDBOutput_2 = "UPDATE " + tableName_tDBOutput_2 + " SET SK_APPAREIL_ID = ?,MARQUE = ?,MODELE = ?,CAPACITE = ?,ANNEE_FABRICATION = ?,STATUT = ? WHERE ID = ?";
                java.sql.PreparedStatement pstmtUpdate_tDBOutput_2 = conn_tDBOutput_2.prepareStatement(update_tDBOutput_2);
                resourceMap.put("pstmtUpdate_tDBOutput_2", pstmtUpdate_tDBOutput_2);





 



/**
 * [tDBOutput_2 begin ] stop
 */



	
	/**
	 * [tMap_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_1", false);
		start_Hash.put("tMap_1", System.currentTimeMillis());
		
	
	currentComponent="tMap_1";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row3");
					}
				
		int tos_count_tMap_1 = 0;
		




// ###############################
// # Lookup's keys initialization
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_1__Struct  {
}
Var__tMap_1__Struct Var__tMap_1 = new Var__tMap_1__Struct();
// ###############################

// ###############################
// # Outputs initialization
out1Struct out1_tmp = new out1Struct();
// ###############################

        
        



        









 



/**
 * [tMap_1 begin ] stop
 */



	
	/**
	 * [tSchemaComplianceCheck_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tSchemaComplianceCheck_1", false);
		start_Hash.put("tSchemaComplianceCheck_1", System.currentTimeMillis());
		
	
	currentComponent="tSchemaComplianceCheck_1";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row2");
					}
				
		int tos_count_tSchemaComplianceCheck_1 = 0;
		

    class RowSetValueUtil_tSchemaComplianceCheck_1 {

        boolean ifPassedThrough = true;
        int errorCodeThrough = 0;
        String errorMessageThrough = "";
        int resultErrorCodeThrough = 0;
        String resultErrorMessageThrough = "";
        String tmpContentThrough = null;

        boolean ifPassed = true;
        int errorCode = 0;
        String errorMessage = "";

        void handleBigdecimalPrecision(String data, int iPrecision, int maxLength){
            //number of digits before the decimal point(ignoring frontend zeroes)
            int len1 = 0;
            int len2 = 0;
            ifPassed = true;
            errorCode = 0;
            errorMessage = "";
            if(data.startsWith("-")){
                data = data.substring(1);
            }
            data = org.apache.commons.lang.StringUtils.stripStart(data, "0");

            if(data.indexOf(".") >= 0){
                len1 = data.indexOf(".");
                data = org.apache.commons.lang.StringUtils.stripEnd(data, "0");
                len2 = data.length() - (len1 + 1);
            }else{
                len1 = data.length();
            }

            if (iPrecision < len2) {
                ifPassed = false;
                errorCode += 8;
                errorMessage += "|precision Non-matches";
            } else if (maxLength < len1 + iPrecision) {
                ifPassed = false;
                errorCode += 8;
                errorMessage += "|invalid Length setting is unsuitable for Precision";
            }
        }

        int handleErrorCode(int errorCode, int resultErrorCode){
            if (errorCode > 0) {
                if (resultErrorCode > 0) {
                    resultErrorCode = 16;
                } else {
                    resultErrorCode = errorCode;
                }
            }
            return resultErrorCode;
        }

        String handleErrorMessage(String errorMessage, String resultErrorMessage, String columnLabel){
            if (errorMessage.length() > 0) {
                if (resultErrorMessage.length() > 0) {
                    resultErrorMessage += ";"+ errorMessage.replaceFirst("\\|", columnLabel);
                } else {
                    resultErrorMessage = errorMessage.replaceFirst("\\|", columnLabel);
                }
            }
            return resultErrorMessage;
        }

        void reset(){
            ifPassedThrough = true;
            errorCodeThrough = 0;
            errorMessageThrough = "";
            resultErrorCodeThrough = 0;
            resultErrorMessageThrough = "";
            tmpContentThrough = null;

            ifPassed = true;
            errorCode = 0;
            errorMessage = "";
        }

        void setRowValue_0(row2Struct row2) {
    // validate nullable
    if (row2.IDAppareil == null) {
        ifPassedThrough = false;
        errorCodeThrough += 4;
        errorMessageThrough += "|empty or null";
    }    try {
        if(
        row2.IDAppareil != null
        ) {
            String tester_tSchemaComplianceCheck_1 = String.valueOf(row2.IDAppareil);
        }
    } catch(java.lang.Exception e) {
globalMap.put("tSchemaComplianceCheck_1_ERROR_MESSAGE",e.getMessage());
        ifPassedThrough = false;
        errorCodeThrough += 2;
        errorMessageThrough += "|wrong type";
    }
            resultErrorCodeThrough = handleErrorCode(errorCodeThrough,resultErrorCodeThrough);
            errorCodeThrough = 0;
            resultErrorMessageThrough = handleErrorMessage(errorMessageThrough,resultErrorMessageThrough,"IDAppareil:");
            errorMessageThrough = "";
    // validate nullable
    if (row2.Marque == null) {
        ifPassedThrough = false;
        errorCodeThrough += 4;
        errorMessageThrough += "|empty or null";
    }    try {
        if(
        row2.Marque != null
        ) {
            String tester_tSchemaComplianceCheck_1 = String.valueOf(row2.Marque);
        }
    } catch(java.lang.Exception e) {
globalMap.put("tSchemaComplianceCheck_1_ERROR_MESSAGE",e.getMessage());
        ifPassedThrough = false;
        errorCodeThrough += 2;
        errorMessageThrough += "|wrong type";
    }
            resultErrorCodeThrough = handleErrorCode(errorCodeThrough,resultErrorCodeThrough);
            errorCodeThrough = 0;
            resultErrorMessageThrough = handleErrorMessage(errorMessageThrough,resultErrorMessageThrough,"Marque:");
            errorMessageThrough = "";    try {
        if(
        row2.Modele != null
        ) {
            String tester_tSchemaComplianceCheck_1 = String.valueOf(row2.Modele);
        }
    } catch(java.lang.Exception e) {
globalMap.put("tSchemaComplianceCheck_1_ERROR_MESSAGE",e.getMessage());
        ifPassedThrough = false;
        errorCodeThrough += 2;
        errorMessageThrough += "|wrong type";
    }
            resultErrorCodeThrough = handleErrorCode(errorCodeThrough,resultErrorCodeThrough);
            errorCodeThrough = 0;
            resultErrorMessageThrough = handleErrorMessage(errorMessageThrough,resultErrorMessageThrough,"Modele:");
            errorMessageThrough = "";
    // validate nullable
    if (row2.Capacite == null) {
        ifPassedThrough = false;
        errorCodeThrough += 4;
        errorMessageThrough += "|empty or null";
    }
            resultErrorCodeThrough = handleErrorCode(errorCodeThrough,resultErrorCodeThrough);
            errorCodeThrough = 0;
            resultErrorMessageThrough = handleErrorMessage(errorMessageThrough,resultErrorMessageThrough,"Capacite:");
            errorMessageThrough = "";
            resultErrorCodeThrough = handleErrorCode(errorCodeThrough,resultErrorCodeThrough);
            errorCodeThrough = 0;
            resultErrorMessageThrough = handleErrorMessage(errorMessageThrough,resultErrorMessageThrough,"AnneeFabrication:");
            errorMessageThrough = "";
    // validate nullable
    if (row2.Statut == null) {
        ifPassedThrough = false;
        errorCodeThrough += 4;
        errorMessageThrough += "|empty or null";
    }    try {
        if(
        row2.Statut != null
        ) {
            String tester_tSchemaComplianceCheck_1 = String.valueOf(row2.Statut);
        }
    } catch(java.lang.Exception e) {
globalMap.put("tSchemaComplianceCheck_1_ERROR_MESSAGE",e.getMessage());
        ifPassedThrough = false;
        errorCodeThrough += 2;
        errorMessageThrough += "|wrong type";
    }
            resultErrorCodeThrough = handleErrorCode(errorCodeThrough,resultErrorCodeThrough);
            errorCodeThrough = 0;
            resultErrorMessageThrough = handleErrorMessage(errorMessageThrough,resultErrorMessageThrough,"Statut:");
            errorMessageThrough = "";
        }
    }
    RowSetValueUtil_tSchemaComplianceCheck_1 rsvUtil_tSchemaComplianceCheck_1 = new RowSetValueUtil_tSchemaComplianceCheck_1();

 



/**
 * [tSchemaComplianceCheck_1 begin ] stop
 */



	
	/**
	 * [tUniqRow_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tUniqRow_1", false);
		start_Hash.put("tUniqRow_1", System.currentTimeMillis());
		
	
	currentComponent="tUniqRow_1";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row1");
					}
				
		int tos_count_tUniqRow_1 = 0;
		

	
		class KeyStruct_tUniqRow_1 {
	
			private static final int DEFAULT_HASHCODE = 1;
		    private static final int PRIME = 31;
		    private int hashCode = DEFAULT_HASHCODE;
		    public boolean hashCodeDirty = true;
	
	        
					String IDAppareil;        
	        
		    @Override
			public int hashCode() {
				if (this.hashCodeDirty) {
					final int prime = PRIME;
					int result = DEFAULT_HASHCODE;
			
								result = prime * result + ((this.IDAppareil == null) ? 0 : this.IDAppareil.hashCode());
								
		    		this.hashCode = result;
		    		this.hashCodeDirty = false;		
				}
				return this.hashCode;
			}
			
			@Override
			public boolean equals(Object obj) {
				if (this == obj) return true;
				if (obj == null) return false;
				if (getClass() != obj.getClass()) return false;
				final KeyStruct_tUniqRow_1 other = (KeyStruct_tUniqRow_1) obj;
				
									if (this.IDAppareil == null) {
										if (other.IDAppareil != null) 
											return false;
								
									} else if (!this.IDAppareil.equals(other.IDAppareil))
								 
										return false;
								
				
				return true;
			}
	  
	        
		}

	
int nb_uniques_tUniqRow_1 = 0;
int nb_duplicates_tUniqRow_1 = 0;
KeyStruct_tUniqRow_1 finder_tUniqRow_1 = new KeyStruct_tUniqRow_1();
java.util.Set<KeyStruct_tUniqRow_1> keystUniqRow_1 = new java.util.HashSet<KeyStruct_tUniqRow_1>(); 

 



/**
 * [tUniqRow_1 begin ] stop
 */



	
	/**
	 * [tFileInputDelimited_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileInputDelimited_1", false);
		start_Hash.put("tFileInputDelimited_1", System.currentTimeMillis());
		
	
	currentComponent="tFileInputDelimited_1";

	
		int tos_count_tFileInputDelimited_1 = 0;
		
	
	
	
 
	
	
	final routines.system.RowState rowstate_tFileInputDelimited_1 = new routines.system.RowState();
	
	
				int nb_line_tFileInputDelimited_1 = 0;
				org.talend.fileprocess.FileInputDelimited fid_tFileInputDelimited_1 = null;
				int limit_tFileInputDelimited_1 = -1;
				try{
					
						Object filename_tFileInputDelimited_1 = context.source_path+"appareil.csv";
						if(filename_tFileInputDelimited_1 instanceof java.io.InputStream){
							
			int footer_value_tFileInputDelimited_1 = 0, random_value_tFileInputDelimited_1 = -1;
			if(footer_value_tFileInputDelimited_1 >0 || random_value_tFileInputDelimited_1 > 0){
				throw new java.lang.Exception("When the input source is a stream,footer and random shouldn't be bigger than 0.");				
			}
		
						}
						try {
							fid_tFileInputDelimited_1 = new org.talend.fileprocess.FileInputDelimited(context.source_path+"appareil.csv", "UTF-8",",","\n",false,1,0,
									limit_tFileInputDelimited_1
								,-1, false);
						} catch(java.lang.Exception e) {
globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",e.getMessage());
							
								
								System.err.println(e.getMessage());
							
						}
					
				    
					while (fid_tFileInputDelimited_1!=null && fid_tFileInputDelimited_1.nextRecord()) {
						rowstate_tFileInputDelimited_1.reset();
						
			    						row1 = null;			
												
									boolean whetherReject_tFileInputDelimited_1 = false;
									row1 = new row1Struct();
									try {
										
				int columnIndexWithD_tFileInputDelimited_1 = 0;
				
					String temp = ""; 
				
					columnIndexWithD_tFileInputDelimited_1 = 0;
					
							row1.IDAppareil = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 1;
					
							row1.Marque = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 2;
					
							row1.Modele = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
					columnIndexWithD_tFileInputDelimited_1 = 3;
					
						temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						if(temp.length() > 0) {
							
								try {
								
    								row1.Capacite = ParserUtils.parseTo_Integer(temp);
    							
    							} catch(java.lang.Exception ex_tFileInputDelimited_1) {
globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
										"Capacite", "row1", temp, ex_tFileInputDelimited_1), ex_tFileInputDelimited_1));
								}
    							
						} else {						
							
								
									row1.Capacite = null;
								
							
						}
					
				
					columnIndexWithD_tFileInputDelimited_1 = 4;
					
						temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						if(temp.length() > 0) {
							
								try {
								
    								row1.AnneeFabrication = ParserUtils.parseTo_Integer(temp);
    							
    							} catch(java.lang.Exception ex_tFileInputDelimited_1) {
globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
										"AnneeFabrication", "row1", temp, ex_tFileInputDelimited_1), ex_tFileInputDelimited_1));
								}
    							
						} else {						
							
								
									row1.AnneeFabrication = null;
								
							
						}
					
				
					columnIndexWithD_tFileInputDelimited_1 = 5;
					
							row1.Statut = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
						
				
				
										
										if(rowstate_tFileInputDelimited_1.getException()!=null) {
											throw rowstate_tFileInputDelimited_1.getException();
										}
										
										
							
			    					} catch (java.lang.Exception e) {
globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",e.getMessage());
			        					whetherReject_tFileInputDelimited_1 = true;
			        					
			                					System.err.println(e.getMessage());
			                					row1 = null;
			                				
										
			    					}
								

 



/**
 * [tFileInputDelimited_1 begin ] stop
 */
	
	/**
	 * [tFileInputDelimited_1 main ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_1";

	

 


	tos_count_tFileInputDelimited_1++;

/**
 * [tFileInputDelimited_1 main ] stop
 */
	
	/**
	 * [tFileInputDelimited_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_1";

	

 



/**
 * [tFileInputDelimited_1 process_data_begin ] stop
 */
// Start of branch "row1"
if(row1 != null) { 



	
	/**
	 * [tUniqRow_1 main ] start
	 */

	

	
	
	currentComponent="tUniqRow_1";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row1"
						
						);
					}
					
row2 = null;			
if(row1.IDAppareil == null){
	finder_tUniqRow_1.IDAppareil = null;
}else{
	finder_tUniqRow_1.IDAppareil = row1.IDAppareil.toLowerCase();
}	
finder_tUniqRow_1.hashCodeDirty = true;
if (!keystUniqRow_1.contains(finder_tUniqRow_1)) {
		KeyStruct_tUniqRow_1 new_tUniqRow_1 = new KeyStruct_tUniqRow_1();

		
if(row1.IDAppareil == null){
	new_tUniqRow_1.IDAppareil = null;
}else{
	new_tUniqRow_1.IDAppareil = row1.IDAppareil.toLowerCase();
}
		
		keystUniqRow_1.add(new_tUniqRow_1);if(row2 == null){ 
	
	row2 = new row2Struct();
}row2.IDAppareil = row1.IDAppareil;			row2.Marque = row1.Marque;			row2.Modele = row1.Modele;			row2.Capacite = row1.Capacite;			row2.AnneeFabrication = row1.AnneeFabrication;			row2.Statut = row1.Statut;					
		nb_uniques_tUniqRow_1++;
	} else {
	  nb_duplicates_tUniqRow_1++;
	}

 


	tos_count_tUniqRow_1++;

/**
 * [tUniqRow_1 main ] stop
 */
	
	/**
	 * [tUniqRow_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tUniqRow_1";

	

 



/**
 * [tUniqRow_1 process_data_begin ] stop
 */
// Start of branch "row2"
if(row2 != null) { 



	
	/**
	 * [tSchemaComplianceCheck_1 main ] start
	 */

	

	
	
	currentComponent="tSchemaComplianceCheck_1";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row2"
						
						);
					}
					
	row3 = null;
	rsvUtil_tSchemaComplianceCheck_1.setRowValue_0(row2);
	if (rsvUtil_tSchemaComplianceCheck_1.ifPassedThrough) {
		row3 = new row3Struct();
		row3.IDAppareil = row2.IDAppareil;
		row3.Marque = row2.Marque;
		row3.Modele = row2.Modele;
		row3.Capacite = row2.Capacite;
		row3.AnneeFabrication = row2.AnneeFabrication;
		row3.Statut = row2.Statut;
	}
	rsvUtil_tSchemaComplianceCheck_1.reset();

 


	tos_count_tSchemaComplianceCheck_1++;

/**
 * [tSchemaComplianceCheck_1 main ] stop
 */
	
	/**
	 * [tSchemaComplianceCheck_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tSchemaComplianceCheck_1";

	

 



/**
 * [tSchemaComplianceCheck_1 process_data_begin ] stop
 */
// Start of branch "row3"
if(row3 != null) { 



	
	/**
	 * [tMap_1 main ] start
	 */

	

	
	
	currentComponent="tMap_1";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row3"
						
						);
					}
					

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_1 = false;
		

        // ###############################
        // # Input tables (lookups)
		  boolean rejectedInnerJoin_tMap_1 = false;
		  boolean mainRowRejected_tMap_1 = false;
            				    								  
		// ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_1__Struct Var = Var__tMap_1;// ###############################
        // ###############################
        // # Output tables

out1 = null;


// # Output table : 'out1'
out1_tmp.ID = Numeric.sequence("s1",1,1) ;
out1_tmp.SK_APPAREIL_ID = routines.Clean.nettoie(row3.IDAppareil) ;
out1_tmp.MARQUE = routines.Clean.nettoie(row3.Marque) ;
out1_tmp.MODELE = routines.Clean.nettoie(row3.Modele) ;
out1_tmp.CAPACITE = row3.Capacite ;
out1_tmp.ANNEE_FABRICATION = row3.AnneeFabrication ;
out1_tmp.STATUT = routines.Clean.nettoie(row3.Statut) ;
out1 = out1_tmp;
// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_1 = false;










 


	tos_count_tMap_1++;

/**
 * [tMap_1 main ] stop
 */
	
	/**
	 * [tMap_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tMap_1";

	

 



/**
 * [tMap_1 process_data_begin ] stop
 */
// Start of branch "out1"
if(out1 != null) { 



	
	/**
	 * [tDBOutput_2 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"out1"
						
						);
					}
					



        whetherReject_tDBOutput_2 = false;
                    pstmt_tDBOutput_2.setInt(1, out1.ID);

            int checkCount_tDBOutput_2 = -1;
            try (java.sql.ResultSet rs_tDBOutput_2 = pstmt_tDBOutput_2.executeQuery()) {
                while(rs_tDBOutput_2.next()) {
                    checkCount_tDBOutput_2 = rs_tDBOutput_2.getInt(1);
                }
            }
            if(checkCount_tDBOutput_2 > 0) {
                        if(out1.SK_APPAREIL_ID == null) {
pstmtUpdate_tDBOutput_2.setNull(1, java.sql.Types.VARCHAR);
} else {pstmtUpdate_tDBOutput_2.setString(1, out1.SK_APPAREIL_ID);
}

                        if(out1.MARQUE == null) {
pstmtUpdate_tDBOutput_2.setNull(2, java.sql.Types.VARCHAR);
} else {pstmtUpdate_tDBOutput_2.setString(2, out1.MARQUE);
}

                        if(out1.MODELE == null) {
pstmtUpdate_tDBOutput_2.setNull(3, java.sql.Types.VARCHAR);
} else {pstmtUpdate_tDBOutput_2.setString(3, out1.MODELE);
}

                        pstmtUpdate_tDBOutput_2.setInt(4, out1.CAPACITE);

                        pstmtUpdate_tDBOutput_2.setInt(5, out1.ANNEE_FABRICATION);

                        if(out1.STATUT == null) {
pstmtUpdate_tDBOutput_2.setNull(6, java.sql.Types.VARCHAR);
} else {pstmtUpdate_tDBOutput_2.setString(6, out1.STATUT);
}

                        pstmtUpdate_tDBOutput_2.setInt(7 + count_tDBOutput_2, out1.ID);

                try {
                    int processedCount_tDBOutput_2 = pstmtUpdate_tDBOutput_2.executeUpdate();
                    updatedCount_tDBOutput_2 += processedCount_tDBOutput_2;
                    rowsToCommitCount_tDBOutput_2 += processedCount_tDBOutput_2;
                    nb_line_tDBOutput_2++;
                } catch(java.lang.Exception e_tDBOutput_2) {
globalMap.put("tDBOutput_2_ERROR_MESSAGE",e_tDBOutput_2.getMessage());
                    whetherReject_tDBOutput_2 = true;
                        nb_line_tDBOutput_2++;
                            System.err.print(e_tDBOutput_2.getMessage());
                }
            } else {
                        pstmtInsert_tDBOutput_2.setInt(1, out1.ID);

                        if(out1.SK_APPAREIL_ID == null) {
pstmtInsert_tDBOutput_2.setNull(2, java.sql.Types.VARCHAR);
} else {pstmtInsert_tDBOutput_2.setString(2, out1.SK_APPAREIL_ID);
}

                        if(out1.MARQUE == null) {
pstmtInsert_tDBOutput_2.setNull(3, java.sql.Types.VARCHAR);
} else {pstmtInsert_tDBOutput_2.setString(3, out1.MARQUE);
}

                        if(out1.MODELE == null) {
pstmtInsert_tDBOutput_2.setNull(4, java.sql.Types.VARCHAR);
} else {pstmtInsert_tDBOutput_2.setString(4, out1.MODELE);
}

                        pstmtInsert_tDBOutput_2.setInt(5, out1.CAPACITE);

                        pstmtInsert_tDBOutput_2.setInt(6, out1.ANNEE_FABRICATION);

                        if(out1.STATUT == null) {
pstmtInsert_tDBOutput_2.setNull(7, java.sql.Types.VARCHAR);
} else {pstmtInsert_tDBOutput_2.setString(7, out1.STATUT);
}

                try {
                    int processedCount_tDBOutput_2 = pstmtInsert_tDBOutput_2.executeUpdate();
                    insertedCount_tDBOutput_2 += processedCount_tDBOutput_2;
                    rowsToCommitCount_tDBOutput_2 += processedCount_tDBOutput_2;
                    nb_line_tDBOutput_2++;
                } catch(java.lang.Exception e_tDBOutput_2) {
globalMap.put("tDBOutput_2_ERROR_MESSAGE",e_tDBOutput_2.getMessage());
                    whetherReject_tDBOutput_2 = true;
                        nb_line_tDBOutput_2++;
                            System.err.print(e_tDBOutput_2.getMessage());
                }
            }

 


	tos_count_tDBOutput_2++;

/**
 * [tDBOutput_2 main ] stop
 */
	
	/**
	 * [tDBOutput_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";

	

 



/**
 * [tDBOutput_2 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";

	

 



/**
 * [tDBOutput_2 process_data_end ] stop
 */

} // End of branch "out1"




	
	/**
	 * [tMap_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tMap_1";

	

 



/**
 * [tMap_1 process_data_end ] stop
 */

} // End of branch "row3"




	
	/**
	 * [tSchemaComplianceCheck_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tSchemaComplianceCheck_1";

	

 



/**
 * [tSchemaComplianceCheck_1 process_data_end ] stop
 */

} // End of branch "row2"




	
	/**
	 * [tUniqRow_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tUniqRow_1";

	

 



/**
 * [tUniqRow_1 process_data_end ] stop
 */

} // End of branch "row1"




	
	/**
	 * [tFileInputDelimited_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_1";

	

 



/**
 * [tFileInputDelimited_1 process_data_end ] stop
 */
	
	/**
	 * [tFileInputDelimited_1 end ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_1";

	



            }
            }finally{
                if(!((Object)(context.source_path+"appareil.csv") instanceof java.io.InputStream)){
                	if(fid_tFileInputDelimited_1!=null){
                		fid_tFileInputDelimited_1.close();
                	}
                }
                if(fid_tFileInputDelimited_1!=null){
                	globalMap.put("tFileInputDelimited_1_NB_LINE", fid_tFileInputDelimited_1.getRowNumber());
					
                }
			}
			  

 

ok_Hash.put("tFileInputDelimited_1", true);
end_Hash.put("tFileInputDelimited_1", System.currentTimeMillis());




/**
 * [tFileInputDelimited_1 end ] stop
 */

	
	/**
	 * [tUniqRow_1 end ] start
	 */

	

	
	
	currentComponent="tUniqRow_1";

	

globalMap.put("tUniqRow_1_NB_UNIQUES",nb_uniques_tUniqRow_1);
globalMap.put("tUniqRow_1_NB_DUPLICATES",nb_duplicates_tUniqRow_1);

				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row1");
			  	}
			  	
 

ok_Hash.put("tUniqRow_1", true);
end_Hash.put("tUniqRow_1", System.currentTimeMillis());




/**
 * [tUniqRow_1 end ] stop
 */

	
	/**
	 * [tSchemaComplianceCheck_1 end ] start
	 */

	

	
	
	currentComponent="tSchemaComplianceCheck_1";

	

				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row2");
			  	}
			  	
 

ok_Hash.put("tSchemaComplianceCheck_1", true);
end_Hash.put("tSchemaComplianceCheck_1", System.currentTimeMillis());




/**
 * [tSchemaComplianceCheck_1 end ] stop
 */

	
	/**
	 * [tMap_1 end ] start
	 */

	

	
	
	currentComponent="tMap_1";

	


// ###############################
// # Lookup hashes releasing
// ###############################      





				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row3");
			  	}
			  	
 

ok_Hash.put("tMap_1", true);
end_Hash.put("tMap_1", System.currentTimeMillis());




/**
 * [tMap_1 end ] stop
 */

	
	/**
	 * [tDBOutput_2 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";

	
	



	
        if(pstmtUpdate_tDBOutput_2 != null){
            pstmtUpdate_tDBOutput_2.close();
            resourceMap.remove("pstmtUpdate_tDBOutput_2");
        }
        if(pstmtInsert_tDBOutput_2 != null){
            pstmtInsert_tDBOutput_2.close();
            resourceMap.remove("pstmtInsert_tDBOutput_2");
        }
        if(pstmt_tDBOutput_2 != null) {
            pstmt_tDBOutput_2.close();
            resourceMap.remove("pstmt_tDBOutput_2");
        }
    resourceMap.put("statementClosed_tDBOutput_2", true);

	
	nb_line_deleted_tDBOutput_2=nb_line_deleted_tDBOutput_2+ deletedCount_tDBOutput_2;
	nb_line_update_tDBOutput_2=nb_line_update_tDBOutput_2 + updatedCount_tDBOutput_2;
	nb_line_inserted_tDBOutput_2=nb_line_inserted_tDBOutput_2 + insertedCount_tDBOutput_2;
	nb_line_rejected_tDBOutput_2=nb_line_rejected_tDBOutput_2 + rejectedCount_tDBOutput_2;
	
        globalMap.put("tDBOutput_2_NB_LINE",nb_line_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_UPDATED",nb_line_update_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_DELETED",nb_line_deleted_tDBOutput_2);
        globalMap.put("tDBOutput_2_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_2);
    

	



				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"out1");
			  	}
			  	
 

ok_Hash.put("tDBOutput_2", true);
end_Hash.put("tDBOutput_2", System.currentTimeMillis());




/**
 * [tDBOutput_2 end ] stop
 */












				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tFileInputDelimited_1:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk2", 0, "ok");
								} 
							
							tFileInputDelimited_2Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFileInputDelimited_1 finally ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_1";

	

 



/**
 * [tFileInputDelimited_1 finally ] stop
 */

	
	/**
	 * [tUniqRow_1 finally ] start
	 */

	

	
	
	currentComponent="tUniqRow_1";

	

 



/**
 * [tUniqRow_1 finally ] stop
 */

	
	/**
	 * [tSchemaComplianceCheck_1 finally ] start
	 */

	

	
	
	currentComponent="tSchemaComplianceCheck_1";

	

 



/**
 * [tSchemaComplianceCheck_1 finally ] stop
 */

	
	/**
	 * [tMap_1 finally ] start
	 */

	

	
	
	currentComponent="tMap_1";

	

 



/**
 * [tMap_1 finally ] stop
 */

	
	/**
	 * [tDBOutput_2 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_2";

	



    if (resourceMap.get("statementClosed_tDBOutput_2") == null) {
                java.sql.PreparedStatement pstmtUpdateToClose_tDBOutput_2 = null;
                if ((pstmtUpdateToClose_tDBOutput_2 = (java.sql.PreparedStatement) resourceMap.remove("pstmtUpdate_tDBOutput_2")) != null) {
                    pstmtUpdateToClose_tDBOutput_2.close();
                }
                java.sql.PreparedStatement pstmtInsertToClose_tDBOutput_2 = null;
                if ((pstmtInsertToClose_tDBOutput_2 = (java.sql.PreparedStatement) resourceMap.remove("pstmtInsert_tDBOutput_2")) != null) {
                    pstmtInsertToClose_tDBOutput_2.close();
                }
                java.sql.PreparedStatement pstmtToClose_tDBOutput_2 = null;
                if ((pstmtToClose_tDBOutput_2 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_2")) != null) {
                    pstmtToClose_tDBOutput_2.close();
                }
    }
 



/**
 * [tDBOutput_2 finally ] stop
 */












				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFileInputDelimited_1_SUBPROCESS_STATE", 1);
	}
	


public static class outputStruct implements routines.system.IPersistableRow<outputStruct> {
    final static byte[] commonByteArrayLock_LOCAL_PROJECT_STG_Load = new byte[0];
    static byte[] commonByteArray_LOCAL_PROJECT_STG_Load = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int ID;

				public int getID () {
					return this.ID;
				}
				
			    public String SK_VOL_ID;

				public String getSK_VOL_ID () {
					return this.SK_VOL_ID;
				}
				
			    public String SK_APPAREIL_ID;

				public String getSK_APPAREIL_ID () {
					return this.SK_APPAREIL_ID;
				}
				
			    public java.util.Date DATE_VOL;

				public java.util.Date getDATE_VOL () {
					return this.DATE_VOL;
				}
				
			    public String VILLE_DEPART;

				public String getVILLE_DEPART () {
					return this.VILLE_DEPART;
				}
				
			    public String VILLE_ARRIVEE;

				public String getVILLE_ARRIVEE () {
					return this.VILLE_ARRIVEE;
				}
				
			    public float DISTANCE_VOL;

				public float getDISTANCE_VOL () {
					return this.DISTANCE_VOL;
				}
				
			    public float DUREE_VOL;

				public float getDUREE_VOL () {
					return this.DUREE_VOL;
				}
				
			    public String STATUT;

				public String getSTATUT () {
					return this.STATUT;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.ID;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final outputStruct other = (outputStruct) obj;
		
						if (this.ID != other.ID)
							return false;
					

		return true;
    }

	public void copyDataTo(outputStruct other) {

		other.ID = this.ID;
	            other.SK_VOL_ID = this.SK_VOL_ID;
	            other.SK_APPAREIL_ID = this.SK_APPAREIL_ID;
	            other.DATE_VOL = this.DATE_VOL;
	            other.VILLE_DEPART = this.VILLE_DEPART;
	            other.VILLE_ARRIVEE = this.VILLE_ARRIVEE;
	            other.DISTANCE_VOL = this.DISTANCE_VOL;
	            other.DUREE_VOL = this.DUREE_VOL;
	            other.STATUT = this.STATUT;
	            
	}

	public void copyKeysDataTo(outputStruct other) {

		other.ID = this.ID;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
			        this.ID = dis.readInt();
					
					this.SK_VOL_ID = readString(dis);
					
					this.SK_APPAREIL_ID = readString(dis);
					
					this.DATE_VOL = readDate(dis);
					
					this.VILLE_DEPART = readString(dis);
					
					this.VILLE_ARRIVEE = readString(dis);
					
			        this.DISTANCE_VOL = dis.readFloat();
					
			        this.DUREE_VOL = dis.readFloat();
					
					this.STATUT = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
			        this.ID = dis.readInt();
					
					this.SK_VOL_ID = readString(dis);
					
					this.SK_APPAREIL_ID = readString(dis);
					
					this.DATE_VOL = readDate(dis);
					
					this.VILLE_DEPART = readString(dis);
					
					this.VILLE_ARRIVEE = readString(dis);
					
			        this.DISTANCE_VOL = dis.readFloat();
					
			        this.DUREE_VOL = dis.readFloat();
					
					this.STATUT = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.ID);
					
					// String
				
						writeString(this.SK_VOL_ID,dos);
					
					// String
				
						writeString(this.SK_APPAREIL_ID,dos);
					
					// java.util.Date
				
						writeDate(this.DATE_VOL,dos);
					
					// String
				
						writeString(this.VILLE_DEPART,dos);
					
					// String
				
						writeString(this.VILLE_ARRIVEE,dos);
					
					// float
				
		            	dos.writeFloat(this.DISTANCE_VOL);
					
					// float
				
		            	dos.writeFloat(this.DUREE_VOL);
					
					// String
				
						writeString(this.STATUT,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.ID);
					
					// String
				
						writeString(this.SK_VOL_ID,dos);
					
					// String
				
						writeString(this.SK_APPAREIL_ID,dos);
					
					// java.util.Date
				
						writeDate(this.DATE_VOL,dos);
					
					// String
				
						writeString(this.VILLE_DEPART,dos);
					
					// String
				
						writeString(this.VILLE_ARRIVEE,dos);
					
					// float
				
		            	dos.writeFloat(this.DISTANCE_VOL);
					
					// float
				
		            	dos.writeFloat(this.DUREE_VOL);
					
					// String
				
						writeString(this.STATUT,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("ID="+String.valueOf(ID));
		sb.append(",SK_VOL_ID="+SK_VOL_ID);
		sb.append(",SK_APPAREIL_ID="+SK_APPAREIL_ID);
		sb.append(",DATE_VOL="+String.valueOf(DATE_VOL));
		sb.append(",VILLE_DEPART="+VILLE_DEPART);
		sb.append(",VILLE_ARRIVEE="+VILLE_ARRIVEE);
		sb.append(",DISTANCE_VOL="+String.valueOf(DISTANCE_VOL));
		sb.append(",DUREE_VOL="+String.valueOf(DUREE_VOL));
		sb.append(",STATUT="+STATUT);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(outputStruct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.ID, other.ID);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row6Struct implements routines.system.IPersistableRow<row6Struct> {
    final static byte[] commonByteArrayLock_LOCAL_PROJECT_STG_Load = new byte[0];
    static byte[] commonByteArray_LOCAL_PROJECT_STG_Load = new byte[0];

	
			    public String IDVol;

				public String getIDVol () {
					return this.IDVol;
				}
				
			    public String DateVol;

				public String getDateVol () {
					return this.DateVol;
				}
				
			    public String VilleDepart;

				public String getVilleDepart () {
					return this.VilleDepart;
				}
				
			    public String VilleArrivee;

				public String getVilleArrivee () {
					return this.VilleArrivee;
				}
				
			    public Float DistanceVol;

				public Float getDistanceVol () {
					return this.DistanceVol;
				}
				
			    public Float DureeVol;

				public Float getDureeVol () {
					return this.DureeVol;
				}
				
			    public String Statut;

				public String getStatut () {
					return this.Statut;
				}
				
			    public String IDAppareil;

				public String getIDAppareil () {
					return this.IDAppareil;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
					this.IDVol = readString(dis);
					
					this.DateVol = readString(dis);
					
					this.VilleDepart = readString(dis);
					
					this.VilleArrivee = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.DistanceVol = null;
           				} else {
           			    	this.DistanceVol = dis.readFloat();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.DureeVol = null;
           				} else {
           			    	this.DureeVol = dis.readFloat();
           				}
					
					this.Statut = readString(dis);
					
					this.IDAppareil = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
					this.IDVol = readString(dis);
					
					this.DateVol = readString(dis);
					
					this.VilleDepart = readString(dis);
					
					this.VilleArrivee = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.DistanceVol = null;
           				} else {
           			    	this.DistanceVol = dis.readFloat();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.DureeVol = null;
           				} else {
           			    	this.DureeVol = dis.readFloat();
           				}
					
					this.Statut = readString(dis);
					
					this.IDAppareil = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.IDVol,dos);
					
					// String
				
						writeString(this.DateVol,dos);
					
					// String
				
						writeString(this.VilleDepart,dos);
					
					// String
				
						writeString(this.VilleArrivee,dos);
					
					// Float
				
						if(this.DistanceVol == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.DistanceVol);
		            	}
					
					// Float
				
						if(this.DureeVol == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.DureeVol);
		            	}
					
					// String
				
						writeString(this.Statut,dos);
					
					// String
				
						writeString(this.IDAppareil,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.IDVol,dos);
					
					// String
				
						writeString(this.DateVol,dos);
					
					// String
				
						writeString(this.VilleDepart,dos);
					
					// String
				
						writeString(this.VilleArrivee,dos);
					
					// Float
				
						if(this.DistanceVol == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.DistanceVol);
		            	}
					
					// Float
				
						if(this.DureeVol == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.DureeVol);
		            	}
					
					// String
				
						writeString(this.Statut,dos);
					
					// String
				
						writeString(this.IDAppareil,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("IDVol="+IDVol);
		sb.append(",DateVol="+DateVol);
		sb.append(",VilleDepart="+VilleDepart);
		sb.append(",VilleArrivee="+VilleArrivee);
		sb.append(",DistanceVol="+String.valueOf(DistanceVol));
		sb.append(",DureeVol="+String.valueOf(DureeVol));
		sb.append(",Statut="+Statut);
		sb.append(",IDAppareil="+IDAppareil);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row6Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row5Struct implements routines.system.IPersistableRow<row5Struct> {
    final static byte[] commonByteArrayLock_LOCAL_PROJECT_STG_Load = new byte[0];
    static byte[] commonByteArray_LOCAL_PROJECT_STG_Load = new byte[0];

	
			    public String IDVol;

				public String getIDVol () {
					return this.IDVol;
				}
				
			    public String DateVol;

				public String getDateVol () {
					return this.DateVol;
				}
				
			    public String VilleDepart;

				public String getVilleDepart () {
					return this.VilleDepart;
				}
				
			    public String VilleArrivee;

				public String getVilleArrivee () {
					return this.VilleArrivee;
				}
				
			    public Float DistanceVol;

				public Float getDistanceVol () {
					return this.DistanceVol;
				}
				
			    public Float DureeVol;

				public Float getDureeVol () {
					return this.DureeVol;
				}
				
			    public String Statut;

				public String getStatut () {
					return this.Statut;
				}
				
			    public String IDAppareil;

				public String getIDAppareil () {
					return this.IDAppareil;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
					this.IDVol = readString(dis);
					
					this.DateVol = readString(dis);
					
					this.VilleDepart = readString(dis);
					
					this.VilleArrivee = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.DistanceVol = null;
           				} else {
           			    	this.DistanceVol = dis.readFloat();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.DureeVol = null;
           				} else {
           			    	this.DureeVol = dis.readFloat();
           				}
					
					this.Statut = readString(dis);
					
					this.IDAppareil = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
					this.IDVol = readString(dis);
					
					this.DateVol = readString(dis);
					
					this.VilleDepart = readString(dis);
					
					this.VilleArrivee = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.DistanceVol = null;
           				} else {
           			    	this.DistanceVol = dis.readFloat();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.DureeVol = null;
           				} else {
           			    	this.DureeVol = dis.readFloat();
           				}
					
					this.Statut = readString(dis);
					
					this.IDAppareil = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.IDVol,dos);
					
					// String
				
						writeString(this.DateVol,dos);
					
					// String
				
						writeString(this.VilleDepart,dos);
					
					// String
				
						writeString(this.VilleArrivee,dos);
					
					// Float
				
						if(this.DistanceVol == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.DistanceVol);
		            	}
					
					// Float
				
						if(this.DureeVol == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.DureeVol);
		            	}
					
					// String
				
						writeString(this.Statut,dos);
					
					// String
				
						writeString(this.IDAppareil,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.IDVol,dos);
					
					// String
				
						writeString(this.DateVol,dos);
					
					// String
				
						writeString(this.VilleDepart,dos);
					
					// String
				
						writeString(this.VilleArrivee,dos);
					
					// Float
				
						if(this.DistanceVol == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.DistanceVol);
		            	}
					
					// Float
				
						if(this.DureeVol == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.DureeVol);
		            	}
					
					// String
				
						writeString(this.Statut,dos);
					
					// String
				
						writeString(this.IDAppareil,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("IDVol="+IDVol);
		sb.append(",DateVol="+DateVol);
		sb.append(",VilleDepart="+VilleDepart);
		sb.append(",VilleArrivee="+VilleArrivee);
		sb.append(",DistanceVol="+String.valueOf(DistanceVol));
		sb.append(",DureeVol="+String.valueOf(DureeVol));
		sb.append(",Statut="+Statut);
		sb.append(",IDAppareil="+IDAppareil);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row5Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row4Struct implements routines.system.IPersistableRow<row4Struct> {
    final static byte[] commonByteArrayLock_LOCAL_PROJECT_STG_Load = new byte[0];
    static byte[] commonByteArray_LOCAL_PROJECT_STG_Load = new byte[0];

	
			    public String IDVol;

				public String getIDVol () {
					return this.IDVol;
				}
				
			    public String DateVol;

				public String getDateVol () {
					return this.DateVol;
				}
				
			    public String VilleDepart;

				public String getVilleDepart () {
					return this.VilleDepart;
				}
				
			    public String VilleArrivee;

				public String getVilleArrivee () {
					return this.VilleArrivee;
				}
				
			    public Float DistanceVol;

				public Float getDistanceVol () {
					return this.DistanceVol;
				}
				
			    public Float DureeVol;

				public Float getDureeVol () {
					return this.DureeVol;
				}
				
			    public String Statut;

				public String getStatut () {
					return this.Statut;
				}
				
			    public String IDAppareil;

				public String getIDAppareil () {
					return this.IDAppareil;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
					this.IDVol = readString(dis);
					
					this.DateVol = readString(dis);
					
					this.VilleDepart = readString(dis);
					
					this.VilleArrivee = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.DistanceVol = null;
           				} else {
           			    	this.DistanceVol = dis.readFloat();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.DureeVol = null;
           				} else {
           			    	this.DureeVol = dis.readFloat();
           				}
					
					this.Statut = readString(dis);
					
					this.IDAppareil = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
					this.IDVol = readString(dis);
					
					this.DateVol = readString(dis);
					
					this.VilleDepart = readString(dis);
					
					this.VilleArrivee = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.DistanceVol = null;
           				} else {
           			    	this.DistanceVol = dis.readFloat();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.DureeVol = null;
           				} else {
           			    	this.DureeVol = dis.readFloat();
           				}
					
					this.Statut = readString(dis);
					
					this.IDAppareil = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.IDVol,dos);
					
					// String
				
						writeString(this.DateVol,dos);
					
					// String
				
						writeString(this.VilleDepart,dos);
					
					// String
				
						writeString(this.VilleArrivee,dos);
					
					// Float
				
						if(this.DistanceVol == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.DistanceVol);
		            	}
					
					// Float
				
						if(this.DureeVol == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.DureeVol);
		            	}
					
					// String
				
						writeString(this.Statut,dos);
					
					// String
				
						writeString(this.IDAppareil,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// String
				
						writeString(this.IDVol,dos);
					
					// String
				
						writeString(this.DateVol,dos);
					
					// String
				
						writeString(this.VilleDepart,dos);
					
					// String
				
						writeString(this.VilleArrivee,dos);
					
					// Float
				
						if(this.DistanceVol == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.DistanceVol);
		            	}
					
					// Float
				
						if(this.DureeVol == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.DureeVol);
		            	}
					
					// String
				
						writeString(this.Statut,dos);
					
					// String
				
						writeString(this.IDAppareil,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("IDVol="+IDVol);
		sb.append(",DateVol="+DateVol);
		sb.append(",VilleDepart="+VilleDepart);
		sb.append(",VilleArrivee="+VilleArrivee);
		sb.append(",DistanceVol="+String.valueOf(DistanceVol));
		sb.append(",DureeVol="+String.valueOf(DureeVol));
		sb.append(",Statut="+Statut);
		sb.append(",IDAppareil="+IDAppareil);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row4Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tFileInputDelimited_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFileInputDelimited_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row4Struct row4 = new row4Struct();
row5Struct row5 = new row5Struct();
row6Struct row6 = new row6Struct();
outputStruct output = new outputStruct();







	
	/**
	 * [tDBOutput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_1", false);
		start_Hash.put("tDBOutput_1", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_1";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"output");
					}
				
		int tos_count_tDBOutput_1 = 0;
		






        int updateKeyCount_tDBOutput_1 = 1;
        if(updateKeyCount_tDBOutput_1 < 1) {
            throw new RuntimeException("For update, Schema must have a key");
        } else if (updateKeyCount_tDBOutput_1 == 9 && true) {
                    System.err.println("For update, every Schema column can not be a key");
        }
    
    int nb_line_tDBOutput_1 = 0;
    int nb_line_update_tDBOutput_1 = 0;
    int nb_line_inserted_tDBOutput_1 = 0;
    int nb_line_deleted_tDBOutput_1 = 0;
    int nb_line_rejected_tDBOutput_1 = 0;

    int tmp_batchUpdateCount_tDBOutput_1 = 0;

    int deletedCount_tDBOutput_1=0;
    int updatedCount_tDBOutput_1=0;
    int insertedCount_tDBOutput_1=0;
    int rowsToCommitCount_tDBOutput_1=0;
    int rejectedCount_tDBOutput_1=0;

    boolean whetherReject_tDBOutput_1 = false;

    java.sql.Connection conn_tDBOutput_1 = null;

    //optional table
    String dbschema_tDBOutput_1 = null;
    String tableName_tDBOutput_1 = null;
        dbschema_tDBOutput_1 = (String)globalMap.get("dbschema_tDBConnection_2");
		
        conn_tDBOutput_1 = (java.sql.Connection)globalMap.get("conn_tDBConnection_2");
        int count_tDBOutput_1=0;

        if(dbschema_tDBOutput_1 == null || dbschema_tDBOutput_1.trim().length() == 0) {
            tableName_tDBOutput_1 = ("STG_DIM_VOLS");
        } else {
            tableName_tDBOutput_1 = dbschema_tDBOutput_1 + "." + ("STG_DIM_VOLS");
        }
            try (java.sql.Statement stmtClear_tDBOutput_1 = conn_tDBOutput_1.createStatement()) {
                stmtClear_tDBOutput_1.executeUpdate("DELETE FROM " + tableName_tDBOutput_1 + "");
            }
                java.sql.PreparedStatement pstmt_tDBOutput_1 = conn_tDBOutput_1.prepareStatement("SELECT COUNT(1) FROM " + tableName_tDBOutput_1 + " WHERE ID = ?");
                resourceMap.put("pstmt_tDBOutput_1", pstmt_tDBOutput_1);
                String insert_tDBOutput_1 = "INSERT INTO " + tableName_tDBOutput_1 + " (ID,SK_VOL_ID,SK_APPAREIL_ID,DATE_VOL,VILLE_DEPART,VILLE_ARRIVEE,DISTANCE_VOL,DUREE_VOL,STATUT) VALUES (?,?,?,?,?,?,?,?,?)";    
                java.sql.PreparedStatement pstmtInsert_tDBOutput_1 = conn_tDBOutput_1.prepareStatement(insert_tDBOutput_1);
                resourceMap.put("pstmtInsert_tDBOutput_1", pstmtInsert_tDBOutput_1);
                String update_tDBOutput_1 = "UPDATE " + tableName_tDBOutput_1 + " SET SK_VOL_ID = ?,SK_APPAREIL_ID = ?,DATE_VOL = ?,VILLE_DEPART = ?,VILLE_ARRIVEE = ?,DISTANCE_VOL = ?,DUREE_VOL = ?,STATUT = ? WHERE ID = ?";
                java.sql.PreparedStatement pstmtUpdate_tDBOutput_1 = conn_tDBOutput_1.prepareStatement(update_tDBOutput_1);
                resourceMap.put("pstmtUpdate_tDBOutput_1", pstmtUpdate_tDBOutput_1);





 



/**
 * [tDBOutput_1 begin ] stop
 */



	
	/**
	 * [tMap_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_2", false);
		start_Hash.put("tMap_2", System.currentTimeMillis());
		
	
	currentComponent="tMap_2";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row6");
					}
				
		int tos_count_tMap_2 = 0;
		




// ###############################
// # Lookup's keys initialization
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_2__Struct  {
}
Var__tMap_2__Struct Var__tMap_2 = new Var__tMap_2__Struct();
// ###############################

// ###############################
// # Outputs initialization
outputStruct output_tmp = new outputStruct();
// ###############################

        
        



        









 



/**
 * [tMap_2 begin ] stop
 */



	
	/**
	 * [tSchemaComplianceCheck_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tSchemaComplianceCheck_2", false);
		start_Hash.put("tSchemaComplianceCheck_2", System.currentTimeMillis());
		
	
	currentComponent="tSchemaComplianceCheck_2";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row5");
					}
				
		int tos_count_tSchemaComplianceCheck_2 = 0;
		

    class RowSetValueUtil_tSchemaComplianceCheck_2 {

        boolean ifPassedThrough = true;
        int errorCodeThrough = 0;
        String errorMessageThrough = "";
        int resultErrorCodeThrough = 0;
        String resultErrorMessageThrough = "";
        String tmpContentThrough = null;

        boolean ifPassed = true;
        int errorCode = 0;
        String errorMessage = "";

        void handleBigdecimalPrecision(String data, int iPrecision, int maxLength){
            //number of digits before the decimal point(ignoring frontend zeroes)
            int len1 = 0;
            int len2 = 0;
            ifPassed = true;
            errorCode = 0;
            errorMessage = "";
            if(data.startsWith("-")){
                data = data.substring(1);
            }
            data = org.apache.commons.lang.StringUtils.stripStart(data, "0");

            if(data.indexOf(".") >= 0){
                len1 = data.indexOf(".");
                data = org.apache.commons.lang.StringUtils.stripEnd(data, "0");
                len2 = data.length() - (len1 + 1);
            }else{
                len1 = data.length();
            }

            if (iPrecision < len2) {
                ifPassed = false;
                errorCode += 8;
                errorMessage += "|precision Non-matches";
            } else if (maxLength < len1 + iPrecision) {
                ifPassed = false;
                errorCode += 8;
                errorMessage += "|invalid Length setting is unsuitable for Precision";
            }
        }

        int handleErrorCode(int errorCode, int resultErrorCode){
            if (errorCode > 0) {
                if (resultErrorCode > 0) {
                    resultErrorCode = 16;
                } else {
                    resultErrorCode = errorCode;
                }
            }
            return resultErrorCode;
        }

        String handleErrorMessage(String errorMessage, String resultErrorMessage, String columnLabel){
            if (errorMessage.length() > 0) {
                if (resultErrorMessage.length() > 0) {
                    resultErrorMessage += ";"+ errorMessage.replaceFirst("\\|", columnLabel);
                } else {
                    resultErrorMessage = errorMessage.replaceFirst("\\|", columnLabel);
                }
            }
            return resultErrorMessage;
        }

        void reset(){
            ifPassedThrough = true;
            errorCodeThrough = 0;
            errorMessageThrough = "";
            resultErrorCodeThrough = 0;
            resultErrorMessageThrough = "";
            tmpContentThrough = null;

            ifPassed = true;
            errorCode = 0;
            errorMessage = "";
        }

        void setRowValue_0(row5Struct row5) {
    // validate nullable
    if (row5.IDVol == null) {
        ifPassedThrough = false;
        errorCodeThrough += 4;
        errorMessageThrough += "|empty or null";
    }    try {
        if(
        row5.IDVol != null
        ) {
            String tester_tSchemaComplianceCheck_2 = String.valueOf(row5.IDVol);
        }
    } catch(java.lang.Exception e) {
globalMap.put("tSchemaComplianceCheck_2_ERROR_MESSAGE",e.getMessage());
        ifPassedThrough = false;
        errorCodeThrough += 2;
        errorMessageThrough += "|wrong type";
    }
            resultErrorCodeThrough = handleErrorCode(errorCodeThrough,resultErrorCodeThrough);
            errorCodeThrough = 0;
            resultErrorMessageThrough = handleErrorMessage(errorMessageThrough,resultErrorMessageThrough,"IDVol:");
            errorMessageThrough = "";
    // validate nullable
    if (row5.DateVol == null) {
        ifPassedThrough = false;
        errorCodeThrough += 4;
        errorMessageThrough += "|empty or null";
    }    try {
        if(
        row5.DateVol != null
        ) {
            String tester_tSchemaComplianceCheck_2 = String.valueOf(row5.DateVol);
        }
    } catch(java.lang.Exception e) {
globalMap.put("tSchemaComplianceCheck_2_ERROR_MESSAGE",e.getMessage());
        ifPassedThrough = false;
        errorCodeThrough += 2;
        errorMessageThrough += "|wrong type";
    }
            resultErrorCodeThrough = handleErrorCode(errorCodeThrough,resultErrorCodeThrough);
            errorCodeThrough = 0;
            resultErrorMessageThrough = handleErrorMessage(errorMessageThrough,resultErrorMessageThrough,"DateVol:");
            errorMessageThrough = "";
    // validate nullable
    if (row5.VilleDepart == null) {
        ifPassedThrough = false;
        errorCodeThrough += 4;
        errorMessageThrough += "|empty or null";
    }    try {
        if(
        row5.VilleDepart != null
        ) {
            String tester_tSchemaComplianceCheck_2 = String.valueOf(row5.VilleDepart);
        }
    } catch(java.lang.Exception e) {
globalMap.put("tSchemaComplianceCheck_2_ERROR_MESSAGE",e.getMessage());
        ifPassedThrough = false;
        errorCodeThrough += 2;
        errorMessageThrough += "|wrong type";
    }
            resultErrorCodeThrough = handleErrorCode(errorCodeThrough,resultErrorCodeThrough);
            errorCodeThrough = 0;
            resultErrorMessageThrough = handleErrorMessage(errorMessageThrough,resultErrorMessageThrough,"VilleDepart:");
            errorMessageThrough = "";
    // validate nullable
    if (row5.VilleArrivee == null) {
        ifPassedThrough = false;
        errorCodeThrough += 4;
        errorMessageThrough += "|empty or null";
    }    try {
        if(
        row5.VilleArrivee != null
        ) {
            String tester_tSchemaComplianceCheck_2 = String.valueOf(row5.VilleArrivee);
        }
    } catch(java.lang.Exception e) {
globalMap.put("tSchemaComplianceCheck_2_ERROR_MESSAGE",e.getMessage());
        ifPassedThrough = false;
        errorCodeThrough += 2;
        errorMessageThrough += "|wrong type";
    }
            resultErrorCodeThrough = handleErrorCode(errorCodeThrough,resultErrorCodeThrough);
            errorCodeThrough = 0;
            resultErrorMessageThrough = handleErrorMessage(errorMessageThrough,resultErrorMessageThrough,"VilleArrivee:");
            errorMessageThrough = "";
    // validate nullable
    if (row5.DistanceVol == null) {
        ifPassedThrough = false;
        errorCodeThrough += 4;
        errorMessageThrough += "|empty or null";
    }
            resultErrorCodeThrough = handleErrorCode(errorCodeThrough,resultErrorCodeThrough);
            errorCodeThrough = 0;
            resultErrorMessageThrough = handleErrorMessage(errorMessageThrough,resultErrorMessageThrough,"DistanceVol:");
            errorMessageThrough = "";
    // validate nullable
    if (row5.DureeVol == null) {
        ifPassedThrough = false;
        errorCodeThrough += 4;
        errorMessageThrough += "|empty or null";
    }
            resultErrorCodeThrough = handleErrorCode(errorCodeThrough,resultErrorCodeThrough);
            errorCodeThrough = 0;
            resultErrorMessageThrough = handleErrorMessage(errorMessageThrough,resultErrorMessageThrough,"DureeVol:");
            errorMessageThrough = "";
    // validate nullable
    if (row5.Statut == null) {
        ifPassedThrough = false;
        errorCodeThrough += 4;
        errorMessageThrough += "|empty or null";
    }    try {
        if(
        row5.Statut != null
        ) {
            String tester_tSchemaComplianceCheck_2 = String.valueOf(row5.Statut);
        }
    } catch(java.lang.Exception e) {
globalMap.put("tSchemaComplianceCheck_2_ERROR_MESSAGE",e.getMessage());
        ifPassedThrough = false;
        errorCodeThrough += 2;
        errorMessageThrough += "|wrong type";
    }
            resultErrorCodeThrough = handleErrorCode(errorCodeThrough,resultErrorCodeThrough);
            errorCodeThrough = 0;
            resultErrorMessageThrough = handleErrorMessage(errorMessageThrough,resultErrorMessageThrough,"Statut:");
            errorMessageThrough = "";
    // validate nullable
    if (row5.IDAppareil == null) {
        ifPassedThrough = false;
        errorCodeThrough += 4;
        errorMessageThrough += "|empty or null";
    }    try {
        if(
        row5.IDAppareil != null
        ) {
            String tester_tSchemaComplianceCheck_2 = String.valueOf(row5.IDAppareil);
        }
    } catch(java.lang.Exception e) {
globalMap.put("tSchemaComplianceCheck_2_ERROR_MESSAGE",e.getMessage());
        ifPassedThrough = false;
        errorCodeThrough += 2;
        errorMessageThrough += "|wrong type";
    }
            resultErrorCodeThrough = handleErrorCode(errorCodeThrough,resultErrorCodeThrough);
            errorCodeThrough = 0;
            resultErrorMessageThrough = handleErrorMessage(errorMessageThrough,resultErrorMessageThrough,"IDAppareil:");
            errorMessageThrough = "";
        }
    }
    RowSetValueUtil_tSchemaComplianceCheck_2 rsvUtil_tSchemaComplianceCheck_2 = new RowSetValueUtil_tSchemaComplianceCheck_2();

 



/**
 * [tSchemaComplianceCheck_2 begin ] stop
 */



	
	/**
	 * [tUniqRow_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tUniqRow_2", false);
		start_Hash.put("tUniqRow_2", System.currentTimeMillis());
		
	
	currentComponent="tUniqRow_2";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row4");
					}
				
		int tos_count_tUniqRow_2 = 0;
		

	
		class KeyStruct_tUniqRow_2 {
	
			private static final int DEFAULT_HASHCODE = 1;
		    private static final int PRIME = 31;
		    private int hashCode = DEFAULT_HASHCODE;
		    public boolean hashCodeDirty = true;
	
	        
					String IDVol;        
	        
		    @Override
			public int hashCode() {
				if (this.hashCodeDirty) {
					final int prime = PRIME;
					int result = DEFAULT_HASHCODE;
			
								result = prime * result + ((this.IDVol == null) ? 0 : this.IDVol.hashCode());
								
		    		this.hashCode = result;
		    		this.hashCodeDirty = false;		
				}
				return this.hashCode;
			}
			
			@Override
			public boolean equals(Object obj) {
				if (this == obj) return true;
				if (obj == null) return false;
				if (getClass() != obj.getClass()) return false;
				final KeyStruct_tUniqRow_2 other = (KeyStruct_tUniqRow_2) obj;
				
									if (this.IDVol == null) {
										if (other.IDVol != null) 
											return false;
								
									} else if (!this.IDVol.equals(other.IDVol))
								 
										return false;
								
				
				return true;
			}
	  
	        
		}

	
int nb_uniques_tUniqRow_2 = 0;
int nb_duplicates_tUniqRow_2 = 0;
KeyStruct_tUniqRow_2 finder_tUniqRow_2 = new KeyStruct_tUniqRow_2();
java.util.Set<KeyStruct_tUniqRow_2> keystUniqRow_2 = new java.util.HashSet<KeyStruct_tUniqRow_2>(); 

 



/**
 * [tUniqRow_2 begin ] stop
 */



	
	/**
	 * [tFileInputDelimited_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileInputDelimited_2", false);
		start_Hash.put("tFileInputDelimited_2", System.currentTimeMillis());
		
	
	currentComponent="tFileInputDelimited_2";

	
		int tos_count_tFileInputDelimited_2 = 0;
		
	
	
	
 
	
	
	final routines.system.RowState rowstate_tFileInputDelimited_2 = new routines.system.RowState();
	
	
				int nb_line_tFileInputDelimited_2 = 0;
				org.talend.fileprocess.FileInputDelimited fid_tFileInputDelimited_2 = null;
				int limit_tFileInputDelimited_2 = -1;
				try{
					
						Object filename_tFileInputDelimited_2 = context.source_path+"vol.csv";
						if(filename_tFileInputDelimited_2 instanceof java.io.InputStream){
							
			int footer_value_tFileInputDelimited_2 = 0, random_value_tFileInputDelimited_2 = -1;
			if(footer_value_tFileInputDelimited_2 >0 || random_value_tFileInputDelimited_2 > 0){
				throw new java.lang.Exception("When the input source is a stream,footer and random shouldn't be bigger than 0.");				
			}
		
						}
						try {
							fid_tFileInputDelimited_2 = new org.talend.fileprocess.FileInputDelimited(context.source_path+"vol.csv", "UTF-8",",","\n",false,1,0,
									limit_tFileInputDelimited_2
								,-1, false);
						} catch(java.lang.Exception e) {
globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE",e.getMessage());
							
								
								System.err.println(e.getMessage());
							
						}
					
				    
					while (fid_tFileInputDelimited_2!=null && fid_tFileInputDelimited_2.nextRecord()) {
						rowstate_tFileInputDelimited_2.reset();
						
			    						row4 = null;			
												
									boolean whetherReject_tFileInputDelimited_2 = false;
									row4 = new row4Struct();
									try {
										
				int columnIndexWithD_tFileInputDelimited_2 = 0;
				
					String temp = ""; 
				
					columnIndexWithD_tFileInputDelimited_2 = 0;
					
							row4.IDVol = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
						
				
					columnIndexWithD_tFileInputDelimited_2 = 1;
					
							row4.DateVol = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
						
				
					columnIndexWithD_tFileInputDelimited_2 = 2;
					
							row4.VilleDepart = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
						
				
					columnIndexWithD_tFileInputDelimited_2 = 3;
					
							row4.VilleArrivee = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
						
				
					columnIndexWithD_tFileInputDelimited_2 = 4;
					
						temp = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
						if(temp.length() > 0) {
							
								try {
								
    								row4.DistanceVol = ParserUtils.parseTo_Float(temp);
    							
    							} catch(java.lang.Exception ex_tFileInputDelimited_2) {
globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE",ex_tFileInputDelimited_2.getMessage());
									rowstate_tFileInputDelimited_2.setException(new RuntimeException(String.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
										"DistanceVol", "row4", temp, ex_tFileInputDelimited_2), ex_tFileInputDelimited_2));
								}
    							
						} else {						
							
								
									row4.DistanceVol = null;
								
							
						}
					
				
					columnIndexWithD_tFileInputDelimited_2 = 5;
					
						temp = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
						if(temp.length() > 0) {
							
								try {
								
    								row4.DureeVol = ParserUtils.parseTo_Float(temp);
    							
    							} catch(java.lang.Exception ex_tFileInputDelimited_2) {
globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE",ex_tFileInputDelimited_2.getMessage());
									rowstate_tFileInputDelimited_2.setException(new RuntimeException(String.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
										"DureeVol", "row4", temp, ex_tFileInputDelimited_2), ex_tFileInputDelimited_2));
								}
    							
						} else {						
							
								
									row4.DureeVol = null;
								
							
						}
					
				
					columnIndexWithD_tFileInputDelimited_2 = 6;
					
							row4.Statut = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
						
				
					columnIndexWithD_tFileInputDelimited_2 = 7;
					
							row4.IDAppareil = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
						
				
				
										
										if(rowstate_tFileInputDelimited_2.getException()!=null) {
											throw rowstate_tFileInputDelimited_2.getException();
										}
										
										
							
			    					} catch (java.lang.Exception e) {
globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE",e.getMessage());
			        					whetherReject_tFileInputDelimited_2 = true;
			        					
			                					System.err.println(e.getMessage());
			                					row4 = null;
			                				
										
			    					}
								

 



/**
 * [tFileInputDelimited_2 begin ] stop
 */
	
	/**
	 * [tFileInputDelimited_2 main ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_2";

	

 


	tos_count_tFileInputDelimited_2++;

/**
 * [tFileInputDelimited_2 main ] stop
 */
	
	/**
	 * [tFileInputDelimited_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_2";

	

 



/**
 * [tFileInputDelimited_2 process_data_begin ] stop
 */
// Start of branch "row4"
if(row4 != null) { 



	
	/**
	 * [tUniqRow_2 main ] start
	 */

	

	
	
	currentComponent="tUniqRow_2";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row4"
						
						);
					}
					
row5 = null;			
if(row4.IDVol == null){
	finder_tUniqRow_2.IDVol = null;
}else{
	finder_tUniqRow_2.IDVol = row4.IDVol.toLowerCase();
}	
finder_tUniqRow_2.hashCodeDirty = true;
if (!keystUniqRow_2.contains(finder_tUniqRow_2)) {
		KeyStruct_tUniqRow_2 new_tUniqRow_2 = new KeyStruct_tUniqRow_2();

		
if(row4.IDVol == null){
	new_tUniqRow_2.IDVol = null;
}else{
	new_tUniqRow_2.IDVol = row4.IDVol.toLowerCase();
}
		
		keystUniqRow_2.add(new_tUniqRow_2);if(row5 == null){ 
	
	row5 = new row5Struct();
}row5.IDVol = row4.IDVol;			row5.DateVol = row4.DateVol;			row5.VilleDepart = row4.VilleDepart;			row5.VilleArrivee = row4.VilleArrivee;			row5.DistanceVol = row4.DistanceVol;			row5.DureeVol = row4.DureeVol;			row5.Statut = row4.Statut;			row5.IDAppareil = row4.IDAppareil;					
		nb_uniques_tUniqRow_2++;
	} else {
	  nb_duplicates_tUniqRow_2++;
	}

 


	tos_count_tUniqRow_2++;

/**
 * [tUniqRow_2 main ] stop
 */
	
	/**
	 * [tUniqRow_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tUniqRow_2";

	

 



/**
 * [tUniqRow_2 process_data_begin ] stop
 */
// Start of branch "row5"
if(row5 != null) { 



	
	/**
	 * [tSchemaComplianceCheck_2 main ] start
	 */

	

	
	
	currentComponent="tSchemaComplianceCheck_2";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row5"
						
						);
					}
					
	row6 = null;
	rsvUtil_tSchemaComplianceCheck_2.setRowValue_0(row5);
	if (rsvUtil_tSchemaComplianceCheck_2.ifPassedThrough) {
		row6 = new row6Struct();
		row6.IDVol = row5.IDVol;
		row6.DateVol = row5.DateVol;
		row6.VilleDepart = row5.VilleDepart;
		row6.VilleArrivee = row5.VilleArrivee;
		row6.DistanceVol = row5.DistanceVol;
		row6.DureeVol = row5.DureeVol;
		row6.Statut = row5.Statut;
		row6.IDAppareil = row5.IDAppareil;
	}
	rsvUtil_tSchemaComplianceCheck_2.reset();

 


	tos_count_tSchemaComplianceCheck_2++;

/**
 * [tSchemaComplianceCheck_2 main ] stop
 */
	
	/**
	 * [tSchemaComplianceCheck_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tSchemaComplianceCheck_2";

	

 



/**
 * [tSchemaComplianceCheck_2 process_data_begin ] stop
 */
// Start of branch "row6"
if(row6 != null) { 



	
	/**
	 * [tMap_2 main ] start
	 */

	

	
	
	currentComponent="tMap_2";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row6"
						
						);
					}
					

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_2 = false;
		

        // ###############################
        // # Input tables (lookups)
		  boolean rejectedInnerJoin_tMap_2 = false;
		  boolean mainRowRejected_tMap_2 = false;
            				    								  
		// ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_2__Struct Var = Var__tMap_2;// ###############################
        // ###############################
        // # Output tables

output = null;


// # Output table : 'output'
output_tmp.ID = Numeric.sequence("s3",1,1) ;
output_tmp.SK_VOL_ID = routines.Clean.nettoie(row6.IDVol);
output_tmp.SK_APPAREIL_ID = routines.Clean.nettoie(row6.IDAppareil);
output_tmp.DATE_VOL = TalendDate.parseDate("YYYYMMDD",row6.DateVol) ;
output_tmp.VILLE_DEPART = routines.Clean.nettoie(row6.VilleDepart);
output_tmp.VILLE_ARRIVEE = routines.Clean.nettoie(row6.VilleArrivee);
output_tmp.DISTANCE_VOL = row6.DistanceVol;
output_tmp.DUREE_VOL = row6.DureeVol ;
output_tmp.STATUT = routines.Clean.nettoie(row6.Statut);
output = output_tmp;
// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_2 = false;










 


	tos_count_tMap_2++;

/**
 * [tMap_2 main ] stop
 */
	
	/**
	 * [tMap_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tMap_2";

	

 



/**
 * [tMap_2 process_data_begin ] stop
 */
// Start of branch "output"
if(output != null) { 



	
	/**
	 * [tDBOutput_1 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"output"
						
						);
					}
					



        whetherReject_tDBOutput_1 = false;
                    pstmt_tDBOutput_1.setInt(1, output.ID);

            int checkCount_tDBOutput_1 = -1;
            try (java.sql.ResultSet rs_tDBOutput_1 = pstmt_tDBOutput_1.executeQuery()) {
                while(rs_tDBOutput_1.next()) {
                    checkCount_tDBOutput_1 = rs_tDBOutput_1.getInt(1);
                }
            }
            if(checkCount_tDBOutput_1 > 0) {
                        if(output.SK_VOL_ID == null) {
pstmtUpdate_tDBOutput_1.setNull(1, java.sql.Types.VARCHAR);
} else {pstmtUpdate_tDBOutput_1.setString(1, output.SK_VOL_ID);
}

                        if(output.SK_APPAREIL_ID == null) {
pstmtUpdate_tDBOutput_1.setNull(2, java.sql.Types.VARCHAR);
} else {pstmtUpdate_tDBOutput_1.setString(2, output.SK_APPAREIL_ID);
}

                        if(output.DATE_VOL != null) {
pstmtUpdate_tDBOutput_1.setObject(3, new java.sql.Timestamp(output.DATE_VOL.getTime()),java.sql.Types.DATE);
} else {
pstmtUpdate_tDBOutput_1.setNull(3, java.sql.Types.DATE);
}

                        if(output.VILLE_DEPART == null) {
pstmtUpdate_tDBOutput_1.setNull(4, java.sql.Types.VARCHAR);
} else {pstmtUpdate_tDBOutput_1.setString(4, output.VILLE_DEPART);
}

                        if(output.VILLE_ARRIVEE == null) {
pstmtUpdate_tDBOutput_1.setNull(5, java.sql.Types.VARCHAR);
} else {pstmtUpdate_tDBOutput_1.setString(5, output.VILLE_ARRIVEE);
}

                        pstmtUpdate_tDBOutput_1.setFloat(6, output.DISTANCE_VOL);

                        pstmtUpdate_tDBOutput_1.setFloat(7, output.DUREE_VOL);

                        if(output.STATUT == null) {
pstmtUpdate_tDBOutput_1.setNull(8, java.sql.Types.VARCHAR);
} else {pstmtUpdate_tDBOutput_1.setString(8, output.STATUT);
}

                        pstmtUpdate_tDBOutput_1.setInt(9 + count_tDBOutput_1, output.ID);

                try {
                    int processedCount_tDBOutput_1 = pstmtUpdate_tDBOutput_1.executeUpdate();
                    updatedCount_tDBOutput_1 += processedCount_tDBOutput_1;
                    rowsToCommitCount_tDBOutput_1 += processedCount_tDBOutput_1;
                    nb_line_tDBOutput_1++;
                } catch(java.lang.Exception e_tDBOutput_1) {
globalMap.put("tDBOutput_1_ERROR_MESSAGE",e_tDBOutput_1.getMessage());
                    whetherReject_tDBOutput_1 = true;
                        nb_line_tDBOutput_1++;
                            System.err.print(e_tDBOutput_1.getMessage());
                }
            } else {
                        pstmtInsert_tDBOutput_1.setInt(1, output.ID);

                        if(output.SK_VOL_ID == null) {
pstmtInsert_tDBOutput_1.setNull(2, java.sql.Types.VARCHAR);
} else {pstmtInsert_tDBOutput_1.setString(2, output.SK_VOL_ID);
}

                        if(output.SK_APPAREIL_ID == null) {
pstmtInsert_tDBOutput_1.setNull(3, java.sql.Types.VARCHAR);
} else {pstmtInsert_tDBOutput_1.setString(3, output.SK_APPAREIL_ID);
}

                        if(output.DATE_VOL != null) {
pstmtInsert_tDBOutput_1.setObject(4, new java.sql.Timestamp(output.DATE_VOL.getTime()),java.sql.Types.DATE);
} else {
pstmtInsert_tDBOutput_1.setNull(4, java.sql.Types.DATE);
}

                        if(output.VILLE_DEPART == null) {
pstmtInsert_tDBOutput_1.setNull(5, java.sql.Types.VARCHAR);
} else {pstmtInsert_tDBOutput_1.setString(5, output.VILLE_DEPART);
}

                        if(output.VILLE_ARRIVEE == null) {
pstmtInsert_tDBOutput_1.setNull(6, java.sql.Types.VARCHAR);
} else {pstmtInsert_tDBOutput_1.setString(6, output.VILLE_ARRIVEE);
}

                        pstmtInsert_tDBOutput_1.setFloat(7, output.DISTANCE_VOL);

                        pstmtInsert_tDBOutput_1.setFloat(8, output.DUREE_VOL);

                        if(output.STATUT == null) {
pstmtInsert_tDBOutput_1.setNull(9, java.sql.Types.VARCHAR);
} else {pstmtInsert_tDBOutput_1.setString(9, output.STATUT);
}

                try {
                    int processedCount_tDBOutput_1 = pstmtInsert_tDBOutput_1.executeUpdate();
                    insertedCount_tDBOutput_1 += processedCount_tDBOutput_1;
                    rowsToCommitCount_tDBOutput_1 += processedCount_tDBOutput_1;
                    nb_line_tDBOutput_1++;
                } catch(java.lang.Exception e_tDBOutput_1) {
globalMap.put("tDBOutput_1_ERROR_MESSAGE",e_tDBOutput_1.getMessage());
                    whetherReject_tDBOutput_1 = true;
                        nb_line_tDBOutput_1++;
                            System.err.print(e_tDBOutput_1.getMessage());
                }
            }

 


	tos_count_tDBOutput_1++;

/**
 * [tDBOutput_1 main ] stop
 */
	
	/**
	 * [tDBOutput_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";

	

 



/**
 * [tDBOutput_1 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";

	

 



/**
 * [tDBOutput_1 process_data_end ] stop
 */

} // End of branch "output"




	
	/**
	 * [tMap_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tMap_2";

	

 



/**
 * [tMap_2 process_data_end ] stop
 */

} // End of branch "row6"




	
	/**
	 * [tSchemaComplianceCheck_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tSchemaComplianceCheck_2";

	

 



/**
 * [tSchemaComplianceCheck_2 process_data_end ] stop
 */

} // End of branch "row5"




	
	/**
	 * [tUniqRow_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tUniqRow_2";

	

 



/**
 * [tUniqRow_2 process_data_end ] stop
 */

} // End of branch "row4"




	
	/**
	 * [tFileInputDelimited_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_2";

	

 



/**
 * [tFileInputDelimited_2 process_data_end ] stop
 */
	
	/**
	 * [tFileInputDelimited_2 end ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_2";

	



            }
            }finally{
                if(!((Object)(context.source_path+"vol.csv") instanceof java.io.InputStream)){
                	if(fid_tFileInputDelimited_2!=null){
                		fid_tFileInputDelimited_2.close();
                	}
                }
                if(fid_tFileInputDelimited_2!=null){
                	globalMap.put("tFileInputDelimited_2_NB_LINE", fid_tFileInputDelimited_2.getRowNumber());
					
                }
			}
			  

 

ok_Hash.put("tFileInputDelimited_2", true);
end_Hash.put("tFileInputDelimited_2", System.currentTimeMillis());




/**
 * [tFileInputDelimited_2 end ] stop
 */

	
	/**
	 * [tUniqRow_2 end ] start
	 */

	

	
	
	currentComponent="tUniqRow_2";

	

globalMap.put("tUniqRow_2_NB_UNIQUES",nb_uniques_tUniqRow_2);
globalMap.put("tUniqRow_2_NB_DUPLICATES",nb_duplicates_tUniqRow_2);

				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row4");
			  	}
			  	
 

ok_Hash.put("tUniqRow_2", true);
end_Hash.put("tUniqRow_2", System.currentTimeMillis());




/**
 * [tUniqRow_2 end ] stop
 */

	
	/**
	 * [tSchemaComplianceCheck_2 end ] start
	 */

	

	
	
	currentComponent="tSchemaComplianceCheck_2";

	

				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row5");
			  	}
			  	
 

ok_Hash.put("tSchemaComplianceCheck_2", true);
end_Hash.put("tSchemaComplianceCheck_2", System.currentTimeMillis());




/**
 * [tSchemaComplianceCheck_2 end ] stop
 */

	
	/**
	 * [tMap_2 end ] start
	 */

	

	
	
	currentComponent="tMap_2";

	


// ###############################
// # Lookup hashes releasing
// ###############################      





				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row6");
			  	}
			  	
 

ok_Hash.put("tMap_2", true);
end_Hash.put("tMap_2", System.currentTimeMillis());




/**
 * [tMap_2 end ] stop
 */

	
	/**
	 * [tDBOutput_1 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";

	
	



	
        if(pstmtUpdate_tDBOutput_1 != null){
            pstmtUpdate_tDBOutput_1.close();
            resourceMap.remove("pstmtUpdate_tDBOutput_1");
        }
        if(pstmtInsert_tDBOutput_1 != null){
            pstmtInsert_tDBOutput_1.close();
            resourceMap.remove("pstmtInsert_tDBOutput_1");
        }
        if(pstmt_tDBOutput_1 != null) {
            pstmt_tDBOutput_1.close();
            resourceMap.remove("pstmt_tDBOutput_1");
        }
    resourceMap.put("statementClosed_tDBOutput_1", true);

	
	nb_line_deleted_tDBOutput_1=nb_line_deleted_tDBOutput_1+ deletedCount_tDBOutput_1;
	nb_line_update_tDBOutput_1=nb_line_update_tDBOutput_1 + updatedCount_tDBOutput_1;
	nb_line_inserted_tDBOutput_1=nb_line_inserted_tDBOutput_1 + insertedCount_tDBOutput_1;
	nb_line_rejected_tDBOutput_1=nb_line_rejected_tDBOutput_1 + rejectedCount_tDBOutput_1;
	
        globalMap.put("tDBOutput_1_NB_LINE",nb_line_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_UPDATED",nb_line_update_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_DELETED",nb_line_deleted_tDBOutput_1);
        globalMap.put("tDBOutput_1_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_1);
    

	



				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"output");
			  	}
			  	
 

ok_Hash.put("tDBOutput_1", true);
end_Hash.put("tDBOutput_1", System.currentTimeMillis());




/**
 * [tDBOutput_1 end ] stop
 */












				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tFileInputDelimited_2:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk4", 0, "ok");
								} 
							
							tFileInputDelimited_3Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFileInputDelimited_2 finally ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_2";

	

 



/**
 * [tFileInputDelimited_2 finally ] stop
 */

	
	/**
	 * [tUniqRow_2 finally ] start
	 */

	

	
	
	currentComponent="tUniqRow_2";

	

 



/**
 * [tUniqRow_2 finally ] stop
 */

	
	/**
	 * [tSchemaComplianceCheck_2 finally ] start
	 */

	

	
	
	currentComponent="tSchemaComplianceCheck_2";

	

 



/**
 * [tSchemaComplianceCheck_2 finally ] stop
 */

	
	/**
	 * [tMap_2 finally ] start
	 */

	

	
	
	currentComponent="tMap_2";

	

 



/**
 * [tMap_2 finally ] stop
 */

	
	/**
	 * [tDBOutput_1 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_1";

	



    if (resourceMap.get("statementClosed_tDBOutput_1") == null) {
                java.sql.PreparedStatement pstmtUpdateToClose_tDBOutput_1 = null;
                if ((pstmtUpdateToClose_tDBOutput_1 = (java.sql.PreparedStatement) resourceMap.remove("pstmtUpdate_tDBOutput_1")) != null) {
                    pstmtUpdateToClose_tDBOutput_1.close();
                }
                java.sql.PreparedStatement pstmtInsertToClose_tDBOutput_1 = null;
                if ((pstmtInsertToClose_tDBOutput_1 = (java.sql.PreparedStatement) resourceMap.remove("pstmtInsert_tDBOutput_1")) != null) {
                    pstmtInsertToClose_tDBOutput_1.close();
                }
                java.sql.PreparedStatement pstmtToClose_tDBOutput_1 = null;
                if ((pstmtToClose_tDBOutput_1 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_1")) != null) {
                    pstmtToClose_tDBOutput_1.close();
                }
    }
 



/**
 * [tDBOutput_1 finally ] stop
 */












				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFileInputDelimited_2_SUBPROCESS_STATE", 1);
	}
	


public static class out4Struct implements routines.system.IPersistableRow<out4Struct> {
    final static byte[] commonByteArrayLock_LOCAL_PROJECT_STG_Load = new byte[0];
    static byte[] commonByteArray_LOCAL_PROJECT_STG_Load = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int PARTICIPANT_ID;

				public int getPARTICIPANT_ID () {
					return this.PARTICIPANT_ID;
				}
				
			    public String NOM;

				public String getNOM () {
					return this.NOM;
				}
				
			    public String PRENOM;

				public String getPRENOM () {
					return this.PRENOM;
				}
				
			    public Integer MILES_ACCUMULES;

				public Integer getMILES_ACCUMULES () {
					return this.MILES_ACCUMULES;
				}
				
			    public String STATUT_FIDELITE;

				public String getSTATUT_FIDELITE () {
					return this.STATUT_FIDELITE;
				}
				
			    public int AGE;

				public int getAGE () {
					return this.AGE;
				}
				
			    public String GENRE;

				public String getGENRE () {
					return this.GENRE;
				}
				
			    public String EMAIL;

				public String getEMAIL () {
					return this.EMAIL;
				}
				
			    public String TELEPHONE;

				public String getTELEPHONE () {
					return this.TELEPHONE;
				}
				
			    public String ADRESSE;

				public String getADRESSE () {
					return this.ADRESSE;
				}
				
			    public String VILLE;

				public String getVILLE () {
					return this.VILLE;
				}
				
			    public String PAYS;

				public String getPAYS () {
					return this.PAYS;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.PARTICIPANT_ID;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final out4Struct other = (out4Struct) obj;
		
						if (this.PARTICIPANT_ID != other.PARTICIPANT_ID)
							return false;
					

		return true;
    }

	public void copyDataTo(out4Struct other) {

		other.PARTICIPANT_ID = this.PARTICIPANT_ID;
	            other.NOM = this.NOM;
	            other.PRENOM = this.PRENOM;
	            other.MILES_ACCUMULES = this.MILES_ACCUMULES;
	            other.STATUT_FIDELITE = this.STATUT_FIDELITE;
	            other.AGE = this.AGE;
	            other.GENRE = this.GENRE;
	            other.EMAIL = this.EMAIL;
	            other.TELEPHONE = this.TELEPHONE;
	            other.ADRESSE = this.ADRESSE;
	            other.VILLE = this.VILLE;
	            other.PAYS = this.PAYS;
	            
	}

	public void copyKeysDataTo(out4Struct other) {

		other.PARTICIPANT_ID = this.PARTICIPANT_ID;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
			        this.PARTICIPANT_ID = dis.readInt();
					
					this.NOM = readString(dis);
					
					this.PRENOM = readString(dis);
					
						this.MILES_ACCUMULES = readInteger(dis);
					
					this.STATUT_FIDELITE = readString(dis);
					
			        this.AGE = dis.readInt();
					
					this.GENRE = readString(dis);
					
					this.EMAIL = readString(dis);
					
					this.TELEPHONE = readString(dis);
					
					this.ADRESSE = readString(dis);
					
					this.VILLE = readString(dis);
					
					this.PAYS = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
			        this.PARTICIPANT_ID = dis.readInt();
					
					this.NOM = readString(dis);
					
					this.PRENOM = readString(dis);
					
						this.MILES_ACCUMULES = readInteger(dis);
					
					this.STATUT_FIDELITE = readString(dis);
					
			        this.AGE = dis.readInt();
					
					this.GENRE = readString(dis);
					
					this.EMAIL = readString(dis);
					
					this.TELEPHONE = readString(dis);
					
					this.ADRESSE = readString(dis);
					
					this.VILLE = readString(dis);
					
					this.PAYS = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.PARTICIPANT_ID);
					
					// String
				
						writeString(this.NOM,dos);
					
					// String
				
						writeString(this.PRENOM,dos);
					
					// Integer
				
						writeInteger(this.MILES_ACCUMULES,dos);
					
					// String
				
						writeString(this.STATUT_FIDELITE,dos);
					
					// int
				
		            	dos.writeInt(this.AGE);
					
					// String
				
						writeString(this.GENRE,dos);
					
					// String
				
						writeString(this.EMAIL,dos);
					
					// String
				
						writeString(this.TELEPHONE,dos);
					
					// String
				
						writeString(this.ADRESSE,dos);
					
					// String
				
						writeString(this.VILLE,dos);
					
					// String
				
						writeString(this.PAYS,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.PARTICIPANT_ID);
					
					// String
				
						writeString(this.NOM,dos);
					
					// String
				
						writeString(this.PRENOM,dos);
					
					// Integer
				
						writeInteger(this.MILES_ACCUMULES,dos);
					
					// String
				
						writeString(this.STATUT_FIDELITE,dos);
					
					// int
				
		            	dos.writeInt(this.AGE);
					
					// String
				
						writeString(this.GENRE,dos);
					
					// String
				
						writeString(this.EMAIL,dos);
					
					// String
				
						writeString(this.TELEPHONE,dos);
					
					// String
				
						writeString(this.ADRESSE,dos);
					
					// String
				
						writeString(this.VILLE,dos);
					
					// String
				
						writeString(this.PAYS,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("PARTICIPANT_ID="+String.valueOf(PARTICIPANT_ID));
		sb.append(",NOM="+NOM);
		sb.append(",PRENOM="+PRENOM);
		sb.append(",MILES_ACCUMULES="+String.valueOf(MILES_ACCUMULES));
		sb.append(",STATUT_FIDELITE="+STATUT_FIDELITE);
		sb.append(",AGE="+String.valueOf(AGE));
		sb.append(",GENRE="+GENRE);
		sb.append(",EMAIL="+EMAIL);
		sb.append(",TELEPHONE="+TELEPHONE);
		sb.append(",ADRESSE="+ADRESSE);
		sb.append(",VILLE="+VILLE);
		sb.append(",PAYS="+PAYS);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(out4Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.PARTICIPANT_ID, other.PARTICIPANT_ID);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row9Struct implements routines.system.IPersistableRow<row9Struct> {
    final static byte[] commonByteArrayLock_LOCAL_PROJECT_STG_Load = new byte[0];
    static byte[] commonByteArray_LOCAL_PROJECT_STG_Load = new byte[0];

	
			    public Integer id;

				public Integer getId () {
					return this.id;
				}
				
			    public String nom;

				public String getNom () {
					return this.nom;
				}
				
			    public String prenom;

				public String getPrenom () {
					return this.prenom;
				}
				
			    public String milesAccumules;

				public String getMilesAccumules () {
					return this.milesAccumules;
				}
				
			    public String statutFidelite;

				public String getStatutFidelite () {
					return this.statutFidelite;
				}
				
			    public Integer age;

				public Integer getAge () {
					return this.age;
				}
				
			    public String genre;

				public String getGenre () {
					return this.genre;
				}
				
			    public String email;

				public String getEmail () {
					return this.email;
				}
				
			    public String telephone;

				public String getTelephone () {
					return this.telephone;
				}
				
			    public String adresse;

				public String getAdresse () {
					return this.adresse;
				}
				
			    public String ville;

				public String getVille () {
					return this.ville;
				}
				
			    public String pays;

				public String getPays () {
					return this.pays;
				}
				


	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
						this.id = readInteger(dis);
					
					this.nom = readString(dis);
					
					this.prenom = readString(dis);
					
					this.milesAccumules = readString(dis);
					
					this.statutFidelite = readString(dis);
					
						this.age = readInteger(dis);
					
					this.genre = readString(dis);
					
					this.email = readString(dis);
					
					this.telephone = readString(dis);
					
					this.adresse = readString(dis);
					
					this.ville = readString(dis);
					
					this.pays = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
						this.id = readInteger(dis);
					
					this.nom = readString(dis);
					
					this.prenom = readString(dis);
					
					this.milesAccumules = readString(dis);
					
					this.statutFidelite = readString(dis);
					
						this.age = readInteger(dis);
					
					this.genre = readString(dis);
					
					this.email = readString(dis);
					
					this.telephone = readString(dis);
					
					this.adresse = readString(dis);
					
					this.ville = readString(dis);
					
					this.pays = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.id,dos);
					
					// String
				
						writeString(this.nom,dos);
					
					// String
				
						writeString(this.prenom,dos);
					
					// String
				
						writeString(this.milesAccumules,dos);
					
					// String
				
						writeString(this.statutFidelite,dos);
					
					// Integer
				
						writeInteger(this.age,dos);
					
					// String
				
						writeString(this.genre,dos);
					
					// String
				
						writeString(this.email,dos);
					
					// String
				
						writeString(this.telephone,dos);
					
					// String
				
						writeString(this.adresse,dos);
					
					// String
				
						writeString(this.ville,dos);
					
					// String
				
						writeString(this.pays,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// Integer
				
						writeInteger(this.id,dos);
					
					// String
				
						writeString(this.nom,dos);
					
					// String
				
						writeString(this.prenom,dos);
					
					// String
				
						writeString(this.milesAccumules,dos);
					
					// String
				
						writeString(this.statutFidelite,dos);
					
					// Integer
				
						writeInteger(this.age,dos);
					
					// String
				
						writeString(this.genre,dos);
					
					// String
				
						writeString(this.email,dos);
					
					// String
				
						writeString(this.telephone,dos);
					
					// String
				
						writeString(this.adresse,dos);
					
					// String
				
						writeString(this.ville,dos);
					
					// String
				
						writeString(this.pays,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id="+String.valueOf(id));
		sb.append(",nom="+nom);
		sb.append(",prenom="+prenom);
		sb.append(",milesAccumules="+milesAccumules);
		sb.append(",statutFidelite="+statutFidelite);
		sb.append(",age="+String.valueOf(age));
		sb.append(",genre="+genre);
		sb.append(",email="+email);
		sb.append(",telephone="+telephone);
		sb.append(",adresse="+adresse);
		sb.append(",ville="+ville);
		sb.append(",pays="+pays);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row9Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row8Struct implements routines.system.IPersistableRow<row8Struct> {
    final static byte[] commonByteArrayLock_LOCAL_PROJECT_STG_Load = new byte[0];
    static byte[] commonByteArray_LOCAL_PROJECT_STG_Load = new byte[0];

	
			    public Integer id;

				public Integer getId () {
					return this.id;
				}
				
			    public String nom;

				public String getNom () {
					return this.nom;
				}
				
			    public String prenom;

				public String getPrenom () {
					return this.prenom;
				}
				
			    public String milesAccumules;

				public String getMilesAccumules () {
					return this.milesAccumules;
				}
				
			    public String statutFidelite;

				public String getStatutFidelite () {
					return this.statutFidelite;
				}
				
			    public Integer age;

				public Integer getAge () {
					return this.age;
				}
				
			    public String genre;

				public String getGenre () {
					return this.genre;
				}
				
			    public String email;

				public String getEmail () {
					return this.email;
				}
				
			    public String telephone;

				public String getTelephone () {
					return this.telephone;
				}
				
			    public String adresse;

				public String getAdresse () {
					return this.adresse;
				}
				
			    public String ville;

				public String getVille () {
					return this.ville;
				}
				
			    public String pays;

				public String getPays () {
					return this.pays;
				}
				


	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
						this.id = readInteger(dis);
					
					this.nom = readString(dis);
					
					this.prenom = readString(dis);
					
					this.milesAccumules = readString(dis);
					
					this.statutFidelite = readString(dis);
					
						this.age = readInteger(dis);
					
					this.genre = readString(dis);
					
					this.email = readString(dis);
					
					this.telephone = readString(dis);
					
					this.adresse = readString(dis);
					
					this.ville = readString(dis);
					
					this.pays = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
						this.id = readInteger(dis);
					
					this.nom = readString(dis);
					
					this.prenom = readString(dis);
					
					this.milesAccumules = readString(dis);
					
					this.statutFidelite = readString(dis);
					
						this.age = readInteger(dis);
					
					this.genre = readString(dis);
					
					this.email = readString(dis);
					
					this.telephone = readString(dis);
					
					this.adresse = readString(dis);
					
					this.ville = readString(dis);
					
					this.pays = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.id,dos);
					
					// String
				
						writeString(this.nom,dos);
					
					// String
				
						writeString(this.prenom,dos);
					
					// String
				
						writeString(this.milesAccumules,dos);
					
					// String
				
						writeString(this.statutFidelite,dos);
					
					// Integer
				
						writeInteger(this.age,dos);
					
					// String
				
						writeString(this.genre,dos);
					
					// String
				
						writeString(this.email,dos);
					
					// String
				
						writeString(this.telephone,dos);
					
					// String
				
						writeString(this.adresse,dos);
					
					// String
				
						writeString(this.ville,dos);
					
					// String
				
						writeString(this.pays,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// Integer
				
						writeInteger(this.id,dos);
					
					// String
				
						writeString(this.nom,dos);
					
					// String
				
						writeString(this.prenom,dos);
					
					// String
				
						writeString(this.milesAccumules,dos);
					
					// String
				
						writeString(this.statutFidelite,dos);
					
					// Integer
				
						writeInteger(this.age,dos);
					
					// String
				
						writeString(this.genre,dos);
					
					// String
				
						writeString(this.email,dos);
					
					// String
				
						writeString(this.telephone,dos);
					
					// String
				
						writeString(this.adresse,dos);
					
					// String
				
						writeString(this.ville,dos);
					
					// String
				
						writeString(this.pays,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id="+String.valueOf(id));
		sb.append(",nom="+nom);
		sb.append(",prenom="+prenom);
		sb.append(",milesAccumules="+milesAccumules);
		sb.append(",statutFidelite="+statutFidelite);
		sb.append(",age="+String.valueOf(age));
		sb.append(",genre="+genre);
		sb.append(",email="+email);
		sb.append(",telephone="+telephone);
		sb.append(",adresse="+adresse);
		sb.append(",ville="+ville);
		sb.append(",pays="+pays);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row8Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row7Struct implements routines.system.IPersistableRow<row7Struct> {
    final static byte[] commonByteArrayLock_LOCAL_PROJECT_STG_Load = new byte[0];
    static byte[] commonByteArray_LOCAL_PROJECT_STG_Load = new byte[0];

	
			    public Integer id;

				public Integer getId () {
					return this.id;
				}
				
			    public String nom;

				public String getNom () {
					return this.nom;
				}
				
			    public String prenom;

				public String getPrenom () {
					return this.prenom;
				}
				
			    public String milesAccumules;

				public String getMilesAccumules () {
					return this.milesAccumules;
				}
				
			    public String statutFidelite;

				public String getStatutFidelite () {
					return this.statutFidelite;
				}
				
			    public Integer age;

				public Integer getAge () {
					return this.age;
				}
				
			    public String genre;

				public String getGenre () {
					return this.genre;
				}
				
			    public String email;

				public String getEmail () {
					return this.email;
				}
				
			    public String telephone;

				public String getTelephone () {
					return this.telephone;
				}
				
			    public String adresse;

				public String getAdresse () {
					return this.adresse;
				}
				
			    public String ville;

				public String getVille () {
					return this.ville;
				}
				
			    public String pays;

				public String getPays () {
					return this.pays;
				}
				


	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
						this.id = readInteger(dis);
					
					this.nom = readString(dis);
					
					this.prenom = readString(dis);
					
					this.milesAccumules = readString(dis);
					
					this.statutFidelite = readString(dis);
					
						this.age = readInteger(dis);
					
					this.genre = readString(dis);
					
					this.email = readString(dis);
					
					this.telephone = readString(dis);
					
					this.adresse = readString(dis);
					
					this.ville = readString(dis);
					
					this.pays = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
						this.id = readInteger(dis);
					
					this.nom = readString(dis);
					
					this.prenom = readString(dis);
					
					this.milesAccumules = readString(dis);
					
					this.statutFidelite = readString(dis);
					
						this.age = readInteger(dis);
					
					this.genre = readString(dis);
					
					this.email = readString(dis);
					
					this.telephone = readString(dis);
					
					this.adresse = readString(dis);
					
					this.ville = readString(dis);
					
					this.pays = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.id,dos);
					
					// String
				
						writeString(this.nom,dos);
					
					// String
				
						writeString(this.prenom,dos);
					
					// String
				
						writeString(this.milesAccumules,dos);
					
					// String
				
						writeString(this.statutFidelite,dos);
					
					// Integer
				
						writeInteger(this.age,dos);
					
					// String
				
						writeString(this.genre,dos);
					
					// String
				
						writeString(this.email,dos);
					
					// String
				
						writeString(this.telephone,dos);
					
					// String
				
						writeString(this.adresse,dos);
					
					// String
				
						writeString(this.ville,dos);
					
					// String
				
						writeString(this.pays,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// Integer
				
						writeInteger(this.id,dos);
					
					// String
				
						writeString(this.nom,dos);
					
					// String
				
						writeString(this.prenom,dos);
					
					// String
				
						writeString(this.milesAccumules,dos);
					
					// String
				
						writeString(this.statutFidelite,dos);
					
					// Integer
				
						writeInteger(this.age,dos);
					
					// String
				
						writeString(this.genre,dos);
					
					// String
				
						writeString(this.email,dos);
					
					// String
				
						writeString(this.telephone,dos);
					
					// String
				
						writeString(this.adresse,dos);
					
					// String
				
						writeString(this.ville,dos);
					
					// String
				
						writeString(this.pays,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id="+String.valueOf(id));
		sb.append(",nom="+nom);
		sb.append(",prenom="+prenom);
		sb.append(",milesAccumules="+milesAccumules);
		sb.append(",statutFidelite="+statutFidelite);
		sb.append(",age="+String.valueOf(age));
		sb.append(",genre="+genre);
		sb.append(",email="+email);
		sb.append(",telephone="+telephone);
		sb.append(",adresse="+adresse);
		sb.append(",ville="+ville);
		sb.append(",pays="+pays);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row7Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tFileInputDelimited_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFileInputDelimited_3_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row7Struct row7 = new row7Struct();
row8Struct row8 = new row8Struct();
row9Struct row9 = new row9Struct();
out4Struct out4 = new out4Struct();







	
	/**
	 * [tDBOutput_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_3", false);
		start_Hash.put("tDBOutput_3", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_3";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"out4");
					}
				
		int tos_count_tDBOutput_3 = 0;
		






        int updateKeyCount_tDBOutput_3 = 1;
        if(updateKeyCount_tDBOutput_3 < 1) {
            throw new RuntimeException("For update, Schema must have a key");
        } else if (updateKeyCount_tDBOutput_3 == 12 && true) {
                    System.err.println("For update, every Schema column can not be a key");
        }
    
    int nb_line_tDBOutput_3 = 0;
    int nb_line_update_tDBOutput_3 = 0;
    int nb_line_inserted_tDBOutput_3 = 0;
    int nb_line_deleted_tDBOutput_3 = 0;
    int nb_line_rejected_tDBOutput_3 = 0;

    int tmp_batchUpdateCount_tDBOutput_3 = 0;

    int deletedCount_tDBOutput_3=0;
    int updatedCount_tDBOutput_3=0;
    int insertedCount_tDBOutput_3=0;
    int rowsToCommitCount_tDBOutput_3=0;
    int rejectedCount_tDBOutput_3=0;

    boolean whetherReject_tDBOutput_3 = false;

    java.sql.Connection conn_tDBOutput_3 = null;

    //optional table
    String dbschema_tDBOutput_3 = null;
    String tableName_tDBOutput_3 = null;
        dbschema_tDBOutput_3 = (String)globalMap.get("dbschema_tDBConnection_2");
		
        conn_tDBOutput_3 = (java.sql.Connection)globalMap.get("conn_tDBConnection_2");
        int count_tDBOutput_3=0;

        if(dbschema_tDBOutput_3 == null || dbschema_tDBOutput_3.trim().length() == 0) {
            tableName_tDBOutput_3 = ("STG_DIM_PARTICIPANTS");
        } else {
            tableName_tDBOutput_3 = dbschema_tDBOutput_3 + "." + ("STG_DIM_PARTICIPANTS");
        }
            try (java.sql.Statement stmtClear_tDBOutput_3 = conn_tDBOutput_3.createStatement()) {
                stmtClear_tDBOutput_3.executeUpdate("DELETE FROM " + tableName_tDBOutput_3 + "");
            }
                java.sql.PreparedStatement pstmt_tDBOutput_3 = conn_tDBOutput_3.prepareStatement("SELECT COUNT(1) FROM " + tableName_tDBOutput_3 + " WHERE PARTICIPANT_ID = ?");
                resourceMap.put("pstmt_tDBOutput_3", pstmt_tDBOutput_3);
                String insert_tDBOutput_3 = "INSERT INTO " + tableName_tDBOutput_3 + " (PARTICIPANT_ID,NOM,PRENOM,MILES_ACCUMULES,STATUT_FIDELITE,AGE,GENRE,EMAIL,TELEPHONE,ADRESSE,VILLE,PAYS) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)";    
                java.sql.PreparedStatement pstmtInsert_tDBOutput_3 = conn_tDBOutput_3.prepareStatement(insert_tDBOutput_3);
                resourceMap.put("pstmtInsert_tDBOutput_3", pstmtInsert_tDBOutput_3);
                String update_tDBOutput_3 = "UPDATE " + tableName_tDBOutput_3 + " SET NOM = ?,PRENOM = ?,MILES_ACCUMULES = ?,STATUT_FIDELITE = ?,AGE = ?,GENRE = ?,EMAIL = ?,TELEPHONE = ?,ADRESSE = ?,VILLE = ?,PAYS = ? WHERE PARTICIPANT_ID = ?";
                java.sql.PreparedStatement pstmtUpdate_tDBOutput_3 = conn_tDBOutput_3.prepareStatement(update_tDBOutput_3);
                resourceMap.put("pstmtUpdate_tDBOutput_3", pstmtUpdate_tDBOutput_3);





 



/**
 * [tDBOutput_3 begin ] stop
 */



	
	/**
	 * [tMap_6 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_6", false);
		start_Hash.put("tMap_6", System.currentTimeMillis());
		
	
	currentComponent="tMap_6";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row9");
					}
				
		int tos_count_tMap_6 = 0;
		




// ###############################
// # Lookup's keys initialization
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_6__Struct  {
}
Var__tMap_6__Struct Var__tMap_6 = new Var__tMap_6__Struct();
// ###############################

// ###############################
// # Outputs initialization
out4Struct out4_tmp = new out4Struct();
// ###############################

        
        



        









 



/**
 * [tMap_6 begin ] stop
 */



	
	/**
	 * [tSchemaComplianceCheck_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tSchemaComplianceCheck_3", false);
		start_Hash.put("tSchemaComplianceCheck_3", System.currentTimeMillis());
		
	
	currentComponent="tSchemaComplianceCheck_3";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row8");
					}
				
		int tos_count_tSchemaComplianceCheck_3 = 0;
		

    class RowSetValueUtil_tSchemaComplianceCheck_3 {

        boolean ifPassedThrough = true;
        int errorCodeThrough = 0;
        String errorMessageThrough = "";
        int resultErrorCodeThrough = 0;
        String resultErrorMessageThrough = "";
        String tmpContentThrough = null;

        boolean ifPassed = true;
        int errorCode = 0;
        String errorMessage = "";

        void handleBigdecimalPrecision(String data, int iPrecision, int maxLength){
            //number of digits before the decimal point(ignoring frontend zeroes)
            int len1 = 0;
            int len2 = 0;
            ifPassed = true;
            errorCode = 0;
            errorMessage = "";
            if(data.startsWith("-")){
                data = data.substring(1);
            }
            data = org.apache.commons.lang.StringUtils.stripStart(data, "0");

            if(data.indexOf(".") >= 0){
                len1 = data.indexOf(".");
                data = org.apache.commons.lang.StringUtils.stripEnd(data, "0");
                len2 = data.length() - (len1 + 1);
            }else{
                len1 = data.length();
            }

            if (iPrecision < len2) {
                ifPassed = false;
                errorCode += 8;
                errorMessage += "|precision Non-matches";
            } else if (maxLength < len1 + iPrecision) {
                ifPassed = false;
                errorCode += 8;
                errorMessage += "|invalid Length setting is unsuitable for Precision";
            }
        }

        int handleErrorCode(int errorCode, int resultErrorCode){
            if (errorCode > 0) {
                if (resultErrorCode > 0) {
                    resultErrorCode = 16;
                } else {
                    resultErrorCode = errorCode;
                }
            }
            return resultErrorCode;
        }

        String handleErrorMessage(String errorMessage, String resultErrorMessage, String columnLabel){
            if (errorMessage.length() > 0) {
                if (resultErrorMessage.length() > 0) {
                    resultErrorMessage += ";"+ errorMessage.replaceFirst("\\|", columnLabel);
                } else {
                    resultErrorMessage = errorMessage.replaceFirst("\\|", columnLabel);
                }
            }
            return resultErrorMessage;
        }

        void reset(){
            ifPassedThrough = true;
            errorCodeThrough = 0;
            errorMessageThrough = "";
            resultErrorCodeThrough = 0;
            resultErrorMessageThrough = "";
            tmpContentThrough = null;

            ifPassed = true;
            errorCode = 0;
            errorMessage = "";
        }

        void setRowValue_0(row8Struct row8) {
    // validate nullable
    if (row8.id == null) {
        ifPassedThrough = false;
        errorCodeThrough += 4;
        errorMessageThrough += "|empty or null";
    }
            resultErrorCodeThrough = handleErrorCode(errorCodeThrough,resultErrorCodeThrough);
            errorCodeThrough = 0;
            resultErrorMessageThrough = handleErrorMessage(errorMessageThrough,resultErrorMessageThrough,"id:");
            errorMessageThrough = "";
    // validate nullable
    if (row8.nom == null) {
        ifPassedThrough = false;
        errorCodeThrough += 4;
        errorMessageThrough += "|empty or null";
    }    try {
        if(
        row8.nom != null
        ) {
            String tester_tSchemaComplianceCheck_3 = String.valueOf(row8.nom);
        }
    } catch(java.lang.Exception e) {
globalMap.put("tSchemaComplianceCheck_3_ERROR_MESSAGE",e.getMessage());
        ifPassedThrough = false;
        errorCodeThrough += 2;
        errorMessageThrough += "|wrong type";
    }
            resultErrorCodeThrough = handleErrorCode(errorCodeThrough,resultErrorCodeThrough);
            errorCodeThrough = 0;
            resultErrorMessageThrough = handleErrorMessage(errorMessageThrough,resultErrorMessageThrough,"nom:");
            errorMessageThrough = "";
    // validate nullable
    if (row8.prenom == null) {
        ifPassedThrough = false;
        errorCodeThrough += 4;
        errorMessageThrough += "|empty or null";
    }    try {
        if(
        row8.prenom != null
        ) {
            String tester_tSchemaComplianceCheck_3 = String.valueOf(row8.prenom);
        }
    } catch(java.lang.Exception e) {
globalMap.put("tSchemaComplianceCheck_3_ERROR_MESSAGE",e.getMessage());
        ifPassedThrough = false;
        errorCodeThrough += 2;
        errorMessageThrough += "|wrong type";
    }
            resultErrorCodeThrough = handleErrorCode(errorCodeThrough,resultErrorCodeThrough);
            errorCodeThrough = 0;
            resultErrorMessageThrough = handleErrorMessage(errorMessageThrough,resultErrorMessageThrough,"prenom:");
            errorMessageThrough = "";
    // validate nullable
    if (row8.milesAccumules == null) {
        ifPassedThrough = false;
        errorCodeThrough += 4;
        errorMessageThrough += "|empty or null";
    }    try {
        if(
        row8.milesAccumules != null
        ) {
            String tester_tSchemaComplianceCheck_3 = String.valueOf(row8.milesAccumules);
        }
    } catch(java.lang.Exception e) {
globalMap.put("tSchemaComplianceCheck_3_ERROR_MESSAGE",e.getMessage());
        ifPassedThrough = false;
        errorCodeThrough += 2;
        errorMessageThrough += "|wrong type";
    }
            resultErrorCodeThrough = handleErrorCode(errorCodeThrough,resultErrorCodeThrough);
            errorCodeThrough = 0;
            resultErrorMessageThrough = handleErrorMessage(errorMessageThrough,resultErrorMessageThrough,"milesAccumules:");
            errorMessageThrough = "";
    // validate nullable
    if (row8.statutFidelite == null) {
        ifPassedThrough = false;
        errorCodeThrough += 4;
        errorMessageThrough += "|empty or null";
    }    try {
        if(
        row8.statutFidelite != null
        ) {
            String tester_tSchemaComplianceCheck_3 = String.valueOf(row8.statutFidelite);
        }
    } catch(java.lang.Exception e) {
globalMap.put("tSchemaComplianceCheck_3_ERROR_MESSAGE",e.getMessage());
        ifPassedThrough = false;
        errorCodeThrough += 2;
        errorMessageThrough += "|wrong type";
    }
            resultErrorCodeThrough = handleErrorCode(errorCodeThrough,resultErrorCodeThrough);
            errorCodeThrough = 0;
            resultErrorMessageThrough = handleErrorMessage(errorMessageThrough,resultErrorMessageThrough,"statutFidelite:");
            errorMessageThrough = "";
    // validate nullable
    if (row8.age == null) {
        ifPassedThrough = false;
        errorCodeThrough += 4;
        errorMessageThrough += "|empty or null";
    }
            resultErrorCodeThrough = handleErrorCode(errorCodeThrough,resultErrorCodeThrough);
            errorCodeThrough = 0;
            resultErrorMessageThrough = handleErrorMessage(errorMessageThrough,resultErrorMessageThrough,"age:");
            errorMessageThrough = "";
    // validate nullable
    if (row8.genre == null) {
        ifPassedThrough = false;
        errorCodeThrough += 4;
        errorMessageThrough += "|empty or null";
    }    try {
        if(
        row8.genre != null
        ) {
            String tester_tSchemaComplianceCheck_3 = String.valueOf(row8.genre);
        }
    } catch(java.lang.Exception e) {
globalMap.put("tSchemaComplianceCheck_3_ERROR_MESSAGE",e.getMessage());
        ifPassedThrough = false;
        errorCodeThrough += 2;
        errorMessageThrough += "|wrong type";
    }
            resultErrorCodeThrough = handleErrorCode(errorCodeThrough,resultErrorCodeThrough);
            errorCodeThrough = 0;
            resultErrorMessageThrough = handleErrorMessage(errorMessageThrough,resultErrorMessageThrough,"genre:");
            errorMessageThrough = "";    try {
        if(
        row8.email != null
        ) {
            String tester_tSchemaComplianceCheck_3 = String.valueOf(row8.email);
        }
    } catch(java.lang.Exception e) {
globalMap.put("tSchemaComplianceCheck_3_ERROR_MESSAGE",e.getMessage());
        ifPassedThrough = false;
        errorCodeThrough += 2;
        errorMessageThrough += "|wrong type";
    }
            resultErrorCodeThrough = handleErrorCode(errorCodeThrough,resultErrorCodeThrough);
            errorCodeThrough = 0;
            resultErrorMessageThrough = handleErrorMessage(errorMessageThrough,resultErrorMessageThrough,"email:");
            errorMessageThrough = "";    try {
        if(
        row8.telephone != null
        ) {
            String tester_tSchemaComplianceCheck_3 = String.valueOf(row8.telephone);
        }
    } catch(java.lang.Exception e) {
globalMap.put("tSchemaComplianceCheck_3_ERROR_MESSAGE",e.getMessage());
        ifPassedThrough = false;
        errorCodeThrough += 2;
        errorMessageThrough += "|wrong type";
    }
            resultErrorCodeThrough = handleErrorCode(errorCodeThrough,resultErrorCodeThrough);
            errorCodeThrough = 0;
            resultErrorMessageThrough = handleErrorMessage(errorMessageThrough,resultErrorMessageThrough,"telephone:");
            errorMessageThrough = "";
    // validate nullable
    if (row8.adresse == null) {
        ifPassedThrough = false;
        errorCodeThrough += 4;
        errorMessageThrough += "|empty or null";
    }    try {
        if(
        row8.adresse != null
        ) {
            String tester_tSchemaComplianceCheck_3 = String.valueOf(row8.adresse);
        }
    } catch(java.lang.Exception e) {
globalMap.put("tSchemaComplianceCheck_3_ERROR_MESSAGE",e.getMessage());
        ifPassedThrough = false;
        errorCodeThrough += 2;
        errorMessageThrough += "|wrong type";
    }
            resultErrorCodeThrough = handleErrorCode(errorCodeThrough,resultErrorCodeThrough);
            errorCodeThrough = 0;
            resultErrorMessageThrough = handleErrorMessage(errorMessageThrough,resultErrorMessageThrough,"adresse:");
            errorMessageThrough = "";
    // validate nullable
    if (row8.ville == null) {
        ifPassedThrough = false;
        errorCodeThrough += 4;
        errorMessageThrough += "|empty or null";
    }    try {
        if(
        row8.ville != null
        ) {
            String tester_tSchemaComplianceCheck_3 = String.valueOf(row8.ville);
        }
    } catch(java.lang.Exception e) {
globalMap.put("tSchemaComplianceCheck_3_ERROR_MESSAGE",e.getMessage());
        ifPassedThrough = false;
        errorCodeThrough += 2;
        errorMessageThrough += "|wrong type";
    }
            resultErrorCodeThrough = handleErrorCode(errorCodeThrough,resultErrorCodeThrough);
            errorCodeThrough = 0;
            resultErrorMessageThrough = handleErrorMessage(errorMessageThrough,resultErrorMessageThrough,"ville:");
            errorMessageThrough = "";
    // validate nullable
    if (row8.pays == null) {
        ifPassedThrough = false;
        errorCodeThrough += 4;
        errorMessageThrough += "|empty or null";
    }    try {
        if(
        row8.pays != null
        ) {
            String tester_tSchemaComplianceCheck_3 = String.valueOf(row8.pays);
        }
    } catch(java.lang.Exception e) {
globalMap.put("tSchemaComplianceCheck_3_ERROR_MESSAGE",e.getMessage());
        ifPassedThrough = false;
        errorCodeThrough += 2;
        errorMessageThrough += "|wrong type";
    }
            resultErrorCodeThrough = handleErrorCode(errorCodeThrough,resultErrorCodeThrough);
            errorCodeThrough = 0;
            resultErrorMessageThrough = handleErrorMessage(errorMessageThrough,resultErrorMessageThrough,"pays:");
            errorMessageThrough = "";
        }
    }
    RowSetValueUtil_tSchemaComplianceCheck_3 rsvUtil_tSchemaComplianceCheck_3 = new RowSetValueUtil_tSchemaComplianceCheck_3();

 



/**
 * [tSchemaComplianceCheck_3 begin ] stop
 */



	
	/**
	 * [tUniqRow_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tUniqRow_3", false);
		start_Hash.put("tUniqRow_3", System.currentTimeMillis());
		
	
	currentComponent="tUniqRow_3";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row7");
					}
				
		int tos_count_tUniqRow_3 = 0;
		

	
		class KeyStruct_tUniqRow_3 {
	
			private static final int DEFAULT_HASHCODE = 1;
		    private static final int PRIME = 31;
		    private int hashCode = DEFAULT_HASHCODE;
		    public boolean hashCodeDirty = true;
	
	        
					Integer id;        
	        
		    @Override
			public int hashCode() {
				if (this.hashCodeDirty) {
					final int prime = PRIME;
					int result = DEFAULT_HASHCODE;
			
								result = prime * result + ((this.id == null) ? 0 : this.id.hashCode());
								
		    		this.hashCode = result;
		    		this.hashCodeDirty = false;		
				}
				return this.hashCode;
			}
			
			@Override
			public boolean equals(Object obj) {
				if (this == obj) return true;
				if (obj == null) return false;
				if (getClass() != obj.getClass()) return false;
				final KeyStruct_tUniqRow_3 other = (KeyStruct_tUniqRow_3) obj;
				
									if (this.id == null) {
										if (other.id != null) 
											return false;
								
									} else if (!this.id.equals(other.id))
								 
										return false;
								
				
				return true;
			}
	  
	        
		}

	
int nb_uniques_tUniqRow_3 = 0;
int nb_duplicates_tUniqRow_3 = 0;
KeyStruct_tUniqRow_3 finder_tUniqRow_3 = new KeyStruct_tUniqRow_3();
java.util.Set<KeyStruct_tUniqRow_3> keystUniqRow_3 = new java.util.HashSet<KeyStruct_tUniqRow_3>(); 

 



/**
 * [tUniqRow_3 begin ] stop
 */



	
	/**
	 * [tFileInputDelimited_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileInputDelimited_3", false);
		start_Hash.put("tFileInputDelimited_3", System.currentTimeMillis());
		
	
	currentComponent="tFileInputDelimited_3";

	
		int tos_count_tFileInputDelimited_3 = 0;
		
	
	
	
 
	
	
	final routines.system.RowState rowstate_tFileInputDelimited_3 = new routines.system.RowState();
	
	
				int nb_line_tFileInputDelimited_3 = 0;
				org.talend.fileprocess.FileInputDelimited fid_tFileInputDelimited_3 = null;
				int limit_tFileInputDelimited_3 = -1;
				try{
					
						Object filename_tFileInputDelimited_3 = context.source_path+"participant.csv";
						if(filename_tFileInputDelimited_3 instanceof java.io.InputStream){
							
			int footer_value_tFileInputDelimited_3 = 0, random_value_tFileInputDelimited_3 = -1;
			if(footer_value_tFileInputDelimited_3 >0 || random_value_tFileInputDelimited_3 > 0){
				throw new java.lang.Exception("When the input source is a stream,footer and random shouldn't be bigger than 0.");				
			}
		
						}
						try {
							fid_tFileInputDelimited_3 = new org.talend.fileprocess.FileInputDelimited(context.source_path+"participant.csv", "UTF-8",",","\n",false,1,0,
									limit_tFileInputDelimited_3
								,-1, false);
						} catch(java.lang.Exception e) {
globalMap.put("tFileInputDelimited_3_ERROR_MESSAGE",e.getMessage());
							
								
								System.err.println(e.getMessage());
							
						}
					
				    
					while (fid_tFileInputDelimited_3!=null && fid_tFileInputDelimited_3.nextRecord()) {
						rowstate_tFileInputDelimited_3.reset();
						
			    						row7 = null;			
												
									boolean whetherReject_tFileInputDelimited_3 = false;
									row7 = new row7Struct();
									try {
										
				int columnIndexWithD_tFileInputDelimited_3 = 0;
				
					String temp = ""; 
				
					columnIndexWithD_tFileInputDelimited_3 = 0;
					
						temp = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
						if(temp.length() > 0) {
							
								try {
								
    								row7.id = ParserUtils.parseTo_Integer(temp);
    							
    							} catch(java.lang.Exception ex_tFileInputDelimited_3) {
globalMap.put("tFileInputDelimited_3_ERROR_MESSAGE",ex_tFileInputDelimited_3.getMessage());
									rowstate_tFileInputDelimited_3.setException(new RuntimeException(String.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
										"id", "row7", temp, ex_tFileInputDelimited_3), ex_tFileInputDelimited_3));
								}
    							
						} else {						
							
								
									row7.id = null;
								
							
						}
					
				
					columnIndexWithD_tFileInputDelimited_3 = 1;
					
							row7.nom = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
						
				
					columnIndexWithD_tFileInputDelimited_3 = 2;
					
							row7.prenom = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
						
				
					columnIndexWithD_tFileInputDelimited_3 = 3;
					
							row7.milesAccumules = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
						
				
					columnIndexWithD_tFileInputDelimited_3 = 4;
					
							row7.statutFidelite = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
						
				
					columnIndexWithD_tFileInputDelimited_3 = 5;
					
						temp = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
						if(temp.length() > 0) {
							
								try {
								
    								row7.age = ParserUtils.parseTo_Integer(temp);
    							
    							} catch(java.lang.Exception ex_tFileInputDelimited_3) {
globalMap.put("tFileInputDelimited_3_ERROR_MESSAGE",ex_tFileInputDelimited_3.getMessage());
									rowstate_tFileInputDelimited_3.setException(new RuntimeException(String.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
										"age", "row7", temp, ex_tFileInputDelimited_3), ex_tFileInputDelimited_3));
								}
    							
						} else {						
							
								
									row7.age = null;
								
							
						}
					
				
					columnIndexWithD_tFileInputDelimited_3 = 6;
					
							row7.genre = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
						
				
					columnIndexWithD_tFileInputDelimited_3 = 7;
					
							row7.email = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
						
				
					columnIndexWithD_tFileInputDelimited_3 = 8;
					
							row7.telephone = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
						
				
					columnIndexWithD_tFileInputDelimited_3 = 9;
					
							row7.adresse = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
						
				
					columnIndexWithD_tFileInputDelimited_3 = 10;
					
							row7.ville = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
						
				
					columnIndexWithD_tFileInputDelimited_3 = 11;
					
							row7.pays = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
						
				
				
										
										if(rowstate_tFileInputDelimited_3.getException()!=null) {
											throw rowstate_tFileInputDelimited_3.getException();
										}
										
										
							
			    					} catch (java.lang.Exception e) {
globalMap.put("tFileInputDelimited_3_ERROR_MESSAGE",e.getMessage());
			        					whetherReject_tFileInputDelimited_3 = true;
			        					
			                					System.err.println(e.getMessage());
			                					row7 = null;
			                				
										
			    					}
								

 



/**
 * [tFileInputDelimited_3 begin ] stop
 */
	
	/**
	 * [tFileInputDelimited_3 main ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_3";

	

 


	tos_count_tFileInputDelimited_3++;

/**
 * [tFileInputDelimited_3 main ] stop
 */
	
	/**
	 * [tFileInputDelimited_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_3";

	

 



/**
 * [tFileInputDelimited_3 process_data_begin ] stop
 */
// Start of branch "row7"
if(row7 != null) { 



	
	/**
	 * [tUniqRow_3 main ] start
	 */

	

	
	
	currentComponent="tUniqRow_3";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row7"
						
						);
					}
					
row8 = null;			
finder_tUniqRow_3.id = row7.id;	
finder_tUniqRow_3.hashCodeDirty = true;
if (!keystUniqRow_3.contains(finder_tUniqRow_3)) {
		KeyStruct_tUniqRow_3 new_tUniqRow_3 = new KeyStruct_tUniqRow_3();

		
new_tUniqRow_3.id = row7.id;
		
		keystUniqRow_3.add(new_tUniqRow_3);if(row8 == null){ 
	
	row8 = new row8Struct();
}row8.id = row7.id;			row8.nom = row7.nom;			row8.prenom = row7.prenom;			row8.milesAccumules = row7.milesAccumules;			row8.statutFidelite = row7.statutFidelite;			row8.age = row7.age;			row8.genre = row7.genre;			row8.email = row7.email;			row8.telephone = row7.telephone;			row8.adresse = row7.adresse;			row8.ville = row7.ville;			row8.pays = row7.pays;					
		nb_uniques_tUniqRow_3++;
	} else {
	  nb_duplicates_tUniqRow_3++;
	}

 


	tos_count_tUniqRow_3++;

/**
 * [tUniqRow_3 main ] stop
 */
	
	/**
	 * [tUniqRow_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tUniqRow_3";

	

 



/**
 * [tUniqRow_3 process_data_begin ] stop
 */
// Start of branch "row8"
if(row8 != null) { 



	
	/**
	 * [tSchemaComplianceCheck_3 main ] start
	 */

	

	
	
	currentComponent="tSchemaComplianceCheck_3";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row8"
						
						);
					}
					
	row9 = null;
	rsvUtil_tSchemaComplianceCheck_3.setRowValue_0(row8);
	if (rsvUtil_tSchemaComplianceCheck_3.ifPassedThrough) {
		row9 = new row9Struct();
		row9.id = row8.id;
		row9.nom = row8.nom;
		row9.prenom = row8.prenom;
		row9.milesAccumules = row8.milesAccumules;
		row9.statutFidelite = row8.statutFidelite;
		row9.age = row8.age;
		row9.genre = row8.genre;
		row9.email = row8.email;
		row9.telephone = row8.telephone;
		row9.adresse = row8.adresse;
		row9.ville = row8.ville;
		row9.pays = row8.pays;
	}
	rsvUtil_tSchemaComplianceCheck_3.reset();

 


	tos_count_tSchemaComplianceCheck_3++;

/**
 * [tSchemaComplianceCheck_3 main ] stop
 */
	
	/**
	 * [tSchemaComplianceCheck_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tSchemaComplianceCheck_3";

	

 



/**
 * [tSchemaComplianceCheck_3 process_data_begin ] stop
 */
// Start of branch "row9"
if(row9 != null) { 



	
	/**
	 * [tMap_6 main ] start
	 */

	

	
	
	currentComponent="tMap_6";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row9"
						
						);
					}
					

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_6 = false;
		

        // ###############################
        // # Input tables (lookups)
		  boolean rejectedInnerJoin_tMap_6 = false;
		  boolean mainRowRejected_tMap_6 = false;
            				    								  
		// ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_6__Struct Var = Var__tMap_6;// ###############################
        // ###############################
        // # Output tables

out4 = null;


// # Output table : 'out4'
out4_tmp.PARTICIPANT_ID = row9.id ;
out4_tmp.NOM = routines.Clean.nettoie(row9.nom) ;
out4_tmp.PRENOM = routines.Clean.nettoie(row9.prenom);
out4_tmp.MILES_ACCUMULES = 0;
out4_tmp.STATUT_FIDELITE = routines.Clean.nettoie(row9.statutFidelite);
out4_tmp.AGE = row9.age ;
out4_tmp.GENRE = routines.Clean.nettoie(row9.genre).equals("Female") ? "Femme" : "Homme" ;
out4_tmp.EMAIL = row9.email;
out4_tmp.TELEPHONE = row9.telephone;
out4_tmp.ADRESSE = routines.Clean.nettoie(row9.adresse);
out4_tmp.VILLE = routines.Clean.nettoie(row9.ville);
out4_tmp.PAYS = routines.Clean.nettoie(row9.pays);
out4 = out4_tmp;
// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_6 = false;










 


	tos_count_tMap_6++;

/**
 * [tMap_6 main ] stop
 */
	
	/**
	 * [tMap_6 process_data_begin ] start
	 */

	

	
	
	currentComponent="tMap_6";

	

 



/**
 * [tMap_6 process_data_begin ] stop
 */
// Start of branch "out4"
if(out4 != null) { 



	
	/**
	 * [tDBOutput_3 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"out4"
						
						);
					}
					



        whetherReject_tDBOutput_3 = false;
                    pstmt_tDBOutput_3.setInt(1, out4.PARTICIPANT_ID);

            int checkCount_tDBOutput_3 = -1;
            try (java.sql.ResultSet rs_tDBOutput_3 = pstmt_tDBOutput_3.executeQuery()) {
                while(rs_tDBOutput_3.next()) {
                    checkCount_tDBOutput_3 = rs_tDBOutput_3.getInt(1);
                }
            }
            if(checkCount_tDBOutput_3 > 0) {
                        if(out4.NOM == null) {
pstmtUpdate_tDBOutput_3.setNull(1, java.sql.Types.VARCHAR);
} else {pstmtUpdate_tDBOutput_3.setString(1, out4.NOM);
}

                        if(out4.PRENOM == null) {
pstmtUpdate_tDBOutput_3.setNull(2, java.sql.Types.VARCHAR);
} else {pstmtUpdate_tDBOutput_3.setString(2, out4.PRENOM);
}

                        if(out4.MILES_ACCUMULES == null) {
pstmtUpdate_tDBOutput_3.setNull(3, java.sql.Types.INTEGER);
} else {pstmtUpdate_tDBOutput_3.setInt(3, out4.MILES_ACCUMULES);
}

                        if(out4.STATUT_FIDELITE == null) {
pstmtUpdate_tDBOutput_3.setNull(4, java.sql.Types.VARCHAR);
} else {pstmtUpdate_tDBOutput_3.setString(4, out4.STATUT_FIDELITE);
}

                        pstmtUpdate_tDBOutput_3.setInt(5, out4.AGE);

                        if(out4.GENRE == null) {
pstmtUpdate_tDBOutput_3.setNull(6, java.sql.Types.VARCHAR);
} else {pstmtUpdate_tDBOutput_3.setString(6, out4.GENRE);
}

                        if(out4.EMAIL == null) {
pstmtUpdate_tDBOutput_3.setNull(7, java.sql.Types.VARCHAR);
} else {pstmtUpdate_tDBOutput_3.setString(7, out4.EMAIL);
}

                        if(out4.TELEPHONE == null) {
pstmtUpdate_tDBOutput_3.setNull(8, java.sql.Types.VARCHAR);
} else {pstmtUpdate_tDBOutput_3.setString(8, out4.TELEPHONE);
}

                        if(out4.ADRESSE == null) {
pstmtUpdate_tDBOutput_3.setNull(9, java.sql.Types.VARCHAR);
} else {pstmtUpdate_tDBOutput_3.setString(9, out4.ADRESSE);
}

                        if(out4.VILLE == null) {
pstmtUpdate_tDBOutput_3.setNull(10, java.sql.Types.VARCHAR);
} else {pstmtUpdate_tDBOutput_3.setString(10, out4.VILLE);
}

                        if(out4.PAYS == null) {
pstmtUpdate_tDBOutput_3.setNull(11, java.sql.Types.VARCHAR);
} else {pstmtUpdate_tDBOutput_3.setString(11, out4.PAYS);
}

                        pstmtUpdate_tDBOutput_3.setInt(12 + count_tDBOutput_3, out4.PARTICIPANT_ID);

                try {
                    int processedCount_tDBOutput_3 = pstmtUpdate_tDBOutput_3.executeUpdate();
                    updatedCount_tDBOutput_3 += processedCount_tDBOutput_3;
                    rowsToCommitCount_tDBOutput_3 += processedCount_tDBOutput_3;
                    nb_line_tDBOutput_3++;
                } catch(java.lang.Exception e_tDBOutput_3) {
globalMap.put("tDBOutput_3_ERROR_MESSAGE",e_tDBOutput_3.getMessage());
                    whetherReject_tDBOutput_3 = true;
                        nb_line_tDBOutput_3++;
                            System.err.print(e_tDBOutput_3.getMessage());
                }
            } else {
                        pstmtInsert_tDBOutput_3.setInt(1, out4.PARTICIPANT_ID);

                        if(out4.NOM == null) {
pstmtInsert_tDBOutput_3.setNull(2, java.sql.Types.VARCHAR);
} else {pstmtInsert_tDBOutput_3.setString(2, out4.NOM);
}

                        if(out4.PRENOM == null) {
pstmtInsert_tDBOutput_3.setNull(3, java.sql.Types.VARCHAR);
} else {pstmtInsert_tDBOutput_3.setString(3, out4.PRENOM);
}

                        if(out4.MILES_ACCUMULES == null) {
pstmtInsert_tDBOutput_3.setNull(4, java.sql.Types.INTEGER);
} else {pstmtInsert_tDBOutput_3.setInt(4, out4.MILES_ACCUMULES);
}

                        if(out4.STATUT_FIDELITE == null) {
pstmtInsert_tDBOutput_3.setNull(5, java.sql.Types.VARCHAR);
} else {pstmtInsert_tDBOutput_3.setString(5, out4.STATUT_FIDELITE);
}

                        pstmtInsert_tDBOutput_3.setInt(6, out4.AGE);

                        if(out4.GENRE == null) {
pstmtInsert_tDBOutput_3.setNull(7, java.sql.Types.VARCHAR);
} else {pstmtInsert_tDBOutput_3.setString(7, out4.GENRE);
}

                        if(out4.EMAIL == null) {
pstmtInsert_tDBOutput_3.setNull(8, java.sql.Types.VARCHAR);
} else {pstmtInsert_tDBOutput_3.setString(8, out4.EMAIL);
}

                        if(out4.TELEPHONE == null) {
pstmtInsert_tDBOutput_3.setNull(9, java.sql.Types.VARCHAR);
} else {pstmtInsert_tDBOutput_3.setString(9, out4.TELEPHONE);
}

                        if(out4.ADRESSE == null) {
pstmtInsert_tDBOutput_3.setNull(10, java.sql.Types.VARCHAR);
} else {pstmtInsert_tDBOutput_3.setString(10, out4.ADRESSE);
}

                        if(out4.VILLE == null) {
pstmtInsert_tDBOutput_3.setNull(11, java.sql.Types.VARCHAR);
} else {pstmtInsert_tDBOutput_3.setString(11, out4.VILLE);
}

                        if(out4.PAYS == null) {
pstmtInsert_tDBOutput_3.setNull(12, java.sql.Types.VARCHAR);
} else {pstmtInsert_tDBOutput_3.setString(12, out4.PAYS);
}

                try {
                    int processedCount_tDBOutput_3 = pstmtInsert_tDBOutput_3.executeUpdate();
                    insertedCount_tDBOutput_3 += processedCount_tDBOutput_3;
                    rowsToCommitCount_tDBOutput_3 += processedCount_tDBOutput_3;
                    nb_line_tDBOutput_3++;
                } catch(java.lang.Exception e_tDBOutput_3) {
globalMap.put("tDBOutput_3_ERROR_MESSAGE",e_tDBOutput_3.getMessage());
                    whetherReject_tDBOutput_3 = true;
                        nb_line_tDBOutput_3++;
                            System.err.print(e_tDBOutput_3.getMessage());
                }
            }

 


	tos_count_tDBOutput_3++;

/**
 * [tDBOutput_3 main ] stop
 */
	
	/**
	 * [tDBOutput_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";

	

 



/**
 * [tDBOutput_3 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";

	

 



/**
 * [tDBOutput_3 process_data_end ] stop
 */

} // End of branch "out4"




	
	/**
	 * [tMap_6 process_data_end ] start
	 */

	

	
	
	currentComponent="tMap_6";

	

 



/**
 * [tMap_6 process_data_end ] stop
 */

} // End of branch "row9"




	
	/**
	 * [tSchemaComplianceCheck_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tSchemaComplianceCheck_3";

	

 



/**
 * [tSchemaComplianceCheck_3 process_data_end ] stop
 */

} // End of branch "row8"




	
	/**
	 * [tUniqRow_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tUniqRow_3";

	

 



/**
 * [tUniqRow_3 process_data_end ] stop
 */

} // End of branch "row7"




	
	/**
	 * [tFileInputDelimited_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_3";

	

 



/**
 * [tFileInputDelimited_3 process_data_end ] stop
 */
	
	/**
	 * [tFileInputDelimited_3 end ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_3";

	



            }
            }finally{
                if(!((Object)(context.source_path+"participant.csv") instanceof java.io.InputStream)){
                	if(fid_tFileInputDelimited_3!=null){
                		fid_tFileInputDelimited_3.close();
                	}
                }
                if(fid_tFileInputDelimited_3!=null){
                	globalMap.put("tFileInputDelimited_3_NB_LINE", fid_tFileInputDelimited_3.getRowNumber());
					
                }
			}
			  

 

ok_Hash.put("tFileInputDelimited_3", true);
end_Hash.put("tFileInputDelimited_3", System.currentTimeMillis());




/**
 * [tFileInputDelimited_3 end ] stop
 */

	
	/**
	 * [tUniqRow_3 end ] start
	 */

	

	
	
	currentComponent="tUniqRow_3";

	

globalMap.put("tUniqRow_3_NB_UNIQUES",nb_uniques_tUniqRow_3);
globalMap.put("tUniqRow_3_NB_DUPLICATES",nb_duplicates_tUniqRow_3);

				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row7");
			  	}
			  	
 

ok_Hash.put("tUniqRow_3", true);
end_Hash.put("tUniqRow_3", System.currentTimeMillis());




/**
 * [tUniqRow_3 end ] stop
 */

	
	/**
	 * [tSchemaComplianceCheck_3 end ] start
	 */

	

	
	
	currentComponent="tSchemaComplianceCheck_3";

	

				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row8");
			  	}
			  	
 

ok_Hash.put("tSchemaComplianceCheck_3", true);
end_Hash.put("tSchemaComplianceCheck_3", System.currentTimeMillis());




/**
 * [tSchemaComplianceCheck_3 end ] stop
 */

	
	/**
	 * [tMap_6 end ] start
	 */

	

	
	
	currentComponent="tMap_6";

	


// ###############################
// # Lookup hashes releasing
// ###############################      





				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row9");
			  	}
			  	
 

ok_Hash.put("tMap_6", true);
end_Hash.put("tMap_6", System.currentTimeMillis());




/**
 * [tMap_6 end ] stop
 */

	
	/**
	 * [tDBOutput_3 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";

	
	



	
        if(pstmtUpdate_tDBOutput_3 != null){
            pstmtUpdate_tDBOutput_3.close();
            resourceMap.remove("pstmtUpdate_tDBOutput_3");
        }
        if(pstmtInsert_tDBOutput_3 != null){
            pstmtInsert_tDBOutput_3.close();
            resourceMap.remove("pstmtInsert_tDBOutput_3");
        }
        if(pstmt_tDBOutput_3 != null) {
            pstmt_tDBOutput_3.close();
            resourceMap.remove("pstmt_tDBOutput_3");
        }
    resourceMap.put("statementClosed_tDBOutput_3", true);

	
	nb_line_deleted_tDBOutput_3=nb_line_deleted_tDBOutput_3+ deletedCount_tDBOutput_3;
	nb_line_update_tDBOutput_3=nb_line_update_tDBOutput_3 + updatedCount_tDBOutput_3;
	nb_line_inserted_tDBOutput_3=nb_line_inserted_tDBOutput_3 + insertedCount_tDBOutput_3;
	nb_line_rejected_tDBOutput_3=nb_line_rejected_tDBOutput_3 + rejectedCount_tDBOutput_3;
	
        globalMap.put("tDBOutput_3_NB_LINE",nb_line_tDBOutput_3);
        globalMap.put("tDBOutput_3_NB_LINE_UPDATED",nb_line_update_tDBOutput_3);
        globalMap.put("tDBOutput_3_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_3);
        globalMap.put("tDBOutput_3_NB_LINE_DELETED",nb_line_deleted_tDBOutput_3);
        globalMap.put("tDBOutput_3_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_3);
    

	



				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"out4");
			  	}
			  	
 

ok_Hash.put("tDBOutput_3", true);
end_Hash.put("tDBOutput_3", System.currentTimeMillis());




/**
 * [tDBOutput_3 end ] stop
 */












				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tFileInputDelimited_3:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk5", 0, "ok");
								} 
							
							tFileInputDelimited_4Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFileInputDelimited_3 finally ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_3";

	

 



/**
 * [tFileInputDelimited_3 finally ] stop
 */

	
	/**
	 * [tUniqRow_3 finally ] start
	 */

	

	
	
	currentComponent="tUniqRow_3";

	

 



/**
 * [tUniqRow_3 finally ] stop
 */

	
	/**
	 * [tSchemaComplianceCheck_3 finally ] start
	 */

	

	
	
	currentComponent="tSchemaComplianceCheck_3";

	

 



/**
 * [tSchemaComplianceCheck_3 finally ] stop
 */

	
	/**
	 * [tMap_6 finally ] start
	 */

	

	
	
	currentComponent="tMap_6";

	

 



/**
 * [tMap_6 finally ] stop
 */

	
	/**
	 * [tDBOutput_3 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_3";

	



    if (resourceMap.get("statementClosed_tDBOutput_3") == null) {
                java.sql.PreparedStatement pstmtUpdateToClose_tDBOutput_3 = null;
                if ((pstmtUpdateToClose_tDBOutput_3 = (java.sql.PreparedStatement) resourceMap.remove("pstmtUpdate_tDBOutput_3")) != null) {
                    pstmtUpdateToClose_tDBOutput_3.close();
                }
                java.sql.PreparedStatement pstmtInsertToClose_tDBOutput_3 = null;
                if ((pstmtInsertToClose_tDBOutput_3 = (java.sql.PreparedStatement) resourceMap.remove("pstmtInsert_tDBOutput_3")) != null) {
                    pstmtInsertToClose_tDBOutput_3.close();
                }
                java.sql.PreparedStatement pstmtToClose_tDBOutput_3 = null;
                if ((pstmtToClose_tDBOutput_3 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_3")) != null) {
                    pstmtToClose_tDBOutput_3.close();
                }
    }
 



/**
 * [tDBOutput_3 finally ] stop
 */












				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFileInputDelimited_3_SUBPROCESS_STATE", 1);
	}
	


public static class out5Struct implements routines.system.IPersistableRow<out5Struct> {
    final static byte[] commonByteArrayLock_LOCAL_PROJECT_STG_Load = new byte[0];
    static byte[] commonByteArray_LOCAL_PROJECT_STG_Load = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int ID_CANAL;

				public int getID_CANAL () {
					return this.ID_CANAL;
				}
				
			    public String NOM_CANAL;

				public String getNOM_CANAL () {
					return this.NOM_CANAL;
				}
				
			    public String TYPE_CANAL;

				public String getTYPE_CANAL () {
					return this.TYPE_CANAL;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.ID_CANAL;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final out5Struct other = (out5Struct) obj;
		
						if (this.ID_CANAL != other.ID_CANAL)
							return false;
					

		return true;
    }

	public void copyDataTo(out5Struct other) {

		other.ID_CANAL = this.ID_CANAL;
	            other.NOM_CANAL = this.NOM_CANAL;
	            other.TYPE_CANAL = this.TYPE_CANAL;
	            
	}

	public void copyKeysDataTo(out5Struct other) {

		other.ID_CANAL = this.ID_CANAL;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
			        this.ID_CANAL = dis.readInt();
					
					this.NOM_CANAL = readString(dis);
					
					this.TYPE_CANAL = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
			        this.ID_CANAL = dis.readInt();
					
					this.NOM_CANAL = readString(dis);
					
					this.TYPE_CANAL = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.ID_CANAL);
					
					// String
				
						writeString(this.NOM_CANAL,dos);
					
					// String
				
						writeString(this.TYPE_CANAL,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.ID_CANAL);
					
					// String
				
						writeString(this.NOM_CANAL,dos);
					
					// String
				
						writeString(this.TYPE_CANAL,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("ID_CANAL="+String.valueOf(ID_CANAL));
		sb.append(",NOM_CANAL="+NOM_CANAL);
		sb.append(",TYPE_CANAL="+TYPE_CANAL);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(out5Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.ID_CANAL, other.ID_CANAL);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row12Struct implements routines.system.IPersistableRow<row12Struct> {
    final static byte[] commonByteArrayLock_LOCAL_PROJECT_STG_Load = new byte[0];
    static byte[] commonByteArray_LOCAL_PROJECT_STG_Load = new byte[0];

	
			    public Integer idCanal;

				public Integer getIdCanal () {
					return this.idCanal;
				}
				
			    public String nomCanal;

				public String getNomCanal () {
					return this.nomCanal;
				}
				
			    public String typeCanal;

				public String getTypeCanal () {
					return this.typeCanal;
				}
				


	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
						this.idCanal = readInteger(dis);
					
					this.nomCanal = readString(dis);
					
					this.typeCanal = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
						this.idCanal = readInteger(dis);
					
					this.nomCanal = readString(dis);
					
					this.typeCanal = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.idCanal,dos);
					
					// String
				
						writeString(this.nomCanal,dos);
					
					// String
				
						writeString(this.typeCanal,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// Integer
				
						writeInteger(this.idCanal,dos);
					
					// String
				
						writeString(this.nomCanal,dos);
					
					// String
				
						writeString(this.typeCanal,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("idCanal="+String.valueOf(idCanal));
		sb.append(",nomCanal="+nomCanal);
		sb.append(",typeCanal="+typeCanal);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row12Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row11Struct implements routines.system.IPersistableRow<row11Struct> {
    final static byte[] commonByteArrayLock_LOCAL_PROJECT_STG_Load = new byte[0];
    static byte[] commonByteArray_LOCAL_PROJECT_STG_Load = new byte[0];

	
			    public Integer idCanal;

				public Integer getIdCanal () {
					return this.idCanal;
				}
				
			    public String nomCanal;

				public String getNomCanal () {
					return this.nomCanal;
				}
				
			    public String typeCanal;

				public String getTypeCanal () {
					return this.typeCanal;
				}
				


	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
						this.idCanal = readInteger(dis);
					
					this.nomCanal = readString(dis);
					
					this.typeCanal = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
						this.idCanal = readInteger(dis);
					
					this.nomCanal = readString(dis);
					
					this.typeCanal = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.idCanal,dos);
					
					// String
				
						writeString(this.nomCanal,dos);
					
					// String
				
						writeString(this.typeCanal,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// Integer
				
						writeInteger(this.idCanal,dos);
					
					// String
				
						writeString(this.nomCanal,dos);
					
					// String
				
						writeString(this.typeCanal,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("idCanal="+String.valueOf(idCanal));
		sb.append(",nomCanal="+nomCanal);
		sb.append(",typeCanal="+typeCanal);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row11Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row10Struct implements routines.system.IPersistableRow<row10Struct> {
    final static byte[] commonByteArrayLock_LOCAL_PROJECT_STG_Load = new byte[0];
    static byte[] commonByteArray_LOCAL_PROJECT_STG_Load = new byte[0];

	
			    public Integer idCanal;

				public Integer getIdCanal () {
					return this.idCanal;
				}
				
			    public String nomCanal;

				public String getNomCanal () {
					return this.nomCanal;
				}
				
			    public String typeCanal;

				public String getTypeCanal () {
					return this.typeCanal;
				}
				


	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
						this.idCanal = readInteger(dis);
					
					this.nomCanal = readString(dis);
					
					this.typeCanal = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
						this.idCanal = readInteger(dis);
					
					this.nomCanal = readString(dis);
					
					this.typeCanal = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.idCanal,dos);
					
					// String
				
						writeString(this.nomCanal,dos);
					
					// String
				
						writeString(this.typeCanal,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// Integer
				
						writeInteger(this.idCanal,dos);
					
					// String
				
						writeString(this.nomCanal,dos);
					
					// String
				
						writeString(this.typeCanal,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("idCanal="+String.valueOf(idCanal));
		sb.append(",nomCanal="+nomCanal);
		sb.append(",typeCanal="+typeCanal);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row10Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tFileInputDelimited_4Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFileInputDelimited_4_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row10Struct row10 = new row10Struct();
row11Struct row11 = new row11Struct();
row12Struct row12 = new row12Struct();
out5Struct out5 = new out5Struct();







	
	/**
	 * [tDBOutput_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_4", false);
		start_Hash.put("tDBOutput_4", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_4";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"out5");
					}
				
		int tos_count_tDBOutput_4 = 0;
		






        int updateKeyCount_tDBOutput_4 = 1;
        if(updateKeyCount_tDBOutput_4 < 1) {
            throw new RuntimeException("For update, Schema must have a key");
        } else if (updateKeyCount_tDBOutput_4 == 3 && true) {
                    System.err.println("For update, every Schema column can not be a key");
        }
    
    int nb_line_tDBOutput_4 = 0;
    int nb_line_update_tDBOutput_4 = 0;
    int nb_line_inserted_tDBOutput_4 = 0;
    int nb_line_deleted_tDBOutput_4 = 0;
    int nb_line_rejected_tDBOutput_4 = 0;

    int tmp_batchUpdateCount_tDBOutput_4 = 0;

    int deletedCount_tDBOutput_4=0;
    int updatedCount_tDBOutput_4=0;
    int insertedCount_tDBOutput_4=0;
    int rowsToCommitCount_tDBOutput_4=0;
    int rejectedCount_tDBOutput_4=0;

    boolean whetherReject_tDBOutput_4 = false;

    java.sql.Connection conn_tDBOutput_4 = null;

    //optional table
    String dbschema_tDBOutput_4 = null;
    String tableName_tDBOutput_4 = null;
        dbschema_tDBOutput_4 = (String)globalMap.get("dbschema_tDBConnection_2");
		
        conn_tDBOutput_4 = (java.sql.Connection)globalMap.get("conn_tDBConnection_2");
        int count_tDBOutput_4=0;

        if(dbschema_tDBOutput_4 == null || dbschema_tDBOutput_4.trim().length() == 0) {
            tableName_tDBOutput_4 = ("STG_DIM_CANALDISTRIBUTION");
        } else {
            tableName_tDBOutput_4 = dbschema_tDBOutput_4 + "." + ("STG_DIM_CANALDISTRIBUTION");
        }
            try (java.sql.Statement stmtClear_tDBOutput_4 = conn_tDBOutput_4.createStatement()) {
                stmtClear_tDBOutput_4.executeUpdate("DELETE FROM " + tableName_tDBOutput_4 + "");
            }
                java.sql.PreparedStatement pstmt_tDBOutput_4 = conn_tDBOutput_4.prepareStatement("SELECT COUNT(1) FROM " + tableName_tDBOutput_4 + " WHERE ID_CANAL = ?");
                resourceMap.put("pstmt_tDBOutput_4", pstmt_tDBOutput_4);
                String insert_tDBOutput_4 = "INSERT INTO " + tableName_tDBOutput_4 + " (ID_CANAL,NOM_CANAL,TYPE_CANAL) VALUES (?,?,?)";    
                java.sql.PreparedStatement pstmtInsert_tDBOutput_4 = conn_tDBOutput_4.prepareStatement(insert_tDBOutput_4);
                resourceMap.put("pstmtInsert_tDBOutput_4", pstmtInsert_tDBOutput_4);
                String update_tDBOutput_4 = "UPDATE " + tableName_tDBOutput_4 + " SET NOM_CANAL = ?,TYPE_CANAL = ? WHERE ID_CANAL = ?";
                java.sql.PreparedStatement pstmtUpdate_tDBOutput_4 = conn_tDBOutput_4.prepareStatement(update_tDBOutput_4);
                resourceMap.put("pstmtUpdate_tDBOutput_4", pstmtUpdate_tDBOutput_4);





 



/**
 * [tDBOutput_4 begin ] stop
 */



	
	/**
	 * [tMap_7 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_7", false);
		start_Hash.put("tMap_7", System.currentTimeMillis());
		
	
	currentComponent="tMap_7";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row12");
					}
				
		int tos_count_tMap_7 = 0;
		




// ###############################
// # Lookup's keys initialization
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_7__Struct  {
}
Var__tMap_7__Struct Var__tMap_7 = new Var__tMap_7__Struct();
// ###############################

// ###############################
// # Outputs initialization
out5Struct out5_tmp = new out5Struct();
// ###############################

        
        



        









 



/**
 * [tMap_7 begin ] stop
 */



	
	/**
	 * [tSchemaComplianceCheck_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tSchemaComplianceCheck_4", false);
		start_Hash.put("tSchemaComplianceCheck_4", System.currentTimeMillis());
		
	
	currentComponent="tSchemaComplianceCheck_4";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row11");
					}
				
		int tos_count_tSchemaComplianceCheck_4 = 0;
		

    class RowSetValueUtil_tSchemaComplianceCheck_4 {

        boolean ifPassedThrough = true;
        int errorCodeThrough = 0;
        String errorMessageThrough = "";
        int resultErrorCodeThrough = 0;
        String resultErrorMessageThrough = "";
        String tmpContentThrough = null;

        boolean ifPassed = true;
        int errorCode = 0;
        String errorMessage = "";

        void handleBigdecimalPrecision(String data, int iPrecision, int maxLength){
            //number of digits before the decimal point(ignoring frontend zeroes)
            int len1 = 0;
            int len2 = 0;
            ifPassed = true;
            errorCode = 0;
            errorMessage = "";
            if(data.startsWith("-")){
                data = data.substring(1);
            }
            data = org.apache.commons.lang.StringUtils.stripStart(data, "0");

            if(data.indexOf(".") >= 0){
                len1 = data.indexOf(".");
                data = org.apache.commons.lang.StringUtils.stripEnd(data, "0");
                len2 = data.length() - (len1 + 1);
            }else{
                len1 = data.length();
            }

            if (iPrecision < len2) {
                ifPassed = false;
                errorCode += 8;
                errorMessage += "|precision Non-matches";
            } else if (maxLength < len1 + iPrecision) {
                ifPassed = false;
                errorCode += 8;
                errorMessage += "|invalid Length setting is unsuitable for Precision";
            }
        }

        int handleErrorCode(int errorCode, int resultErrorCode){
            if (errorCode > 0) {
                if (resultErrorCode > 0) {
                    resultErrorCode = 16;
                } else {
                    resultErrorCode = errorCode;
                }
            }
            return resultErrorCode;
        }

        String handleErrorMessage(String errorMessage, String resultErrorMessage, String columnLabel){
            if (errorMessage.length() > 0) {
                if (resultErrorMessage.length() > 0) {
                    resultErrorMessage += ";"+ errorMessage.replaceFirst("\\|", columnLabel);
                } else {
                    resultErrorMessage = errorMessage.replaceFirst("\\|", columnLabel);
                }
            }
            return resultErrorMessage;
        }

        void reset(){
            ifPassedThrough = true;
            errorCodeThrough = 0;
            errorMessageThrough = "";
            resultErrorCodeThrough = 0;
            resultErrorMessageThrough = "";
            tmpContentThrough = null;

            ifPassed = true;
            errorCode = 0;
            errorMessage = "";
        }

        void setRowValue_0(row11Struct row11) {
    // validate nullable
    if (row11.idCanal == null) {
        ifPassedThrough = false;
        errorCodeThrough += 4;
        errorMessageThrough += "|empty or null";
    }
            resultErrorCodeThrough = handleErrorCode(errorCodeThrough,resultErrorCodeThrough);
            errorCodeThrough = 0;
            resultErrorMessageThrough = handleErrorMessage(errorMessageThrough,resultErrorMessageThrough,"idCanal:");
            errorMessageThrough = "";
    // validate nullable
    if (row11.nomCanal == null) {
        ifPassedThrough = false;
        errorCodeThrough += 4;
        errorMessageThrough += "|empty or null";
    }    try {
        if(
        row11.nomCanal != null
        ) {
            String tester_tSchemaComplianceCheck_4 = String.valueOf(row11.nomCanal);
        }
    } catch(java.lang.Exception e) {
globalMap.put("tSchemaComplianceCheck_4_ERROR_MESSAGE",e.getMessage());
        ifPassedThrough = false;
        errorCodeThrough += 2;
        errorMessageThrough += "|wrong type";
    }
            resultErrorCodeThrough = handleErrorCode(errorCodeThrough,resultErrorCodeThrough);
            errorCodeThrough = 0;
            resultErrorMessageThrough = handleErrorMessage(errorMessageThrough,resultErrorMessageThrough,"nomCanal:");
            errorMessageThrough = "";
    // validate nullable
    if (row11.typeCanal == null) {
        ifPassedThrough = false;
        errorCodeThrough += 4;
        errorMessageThrough += "|empty or null";
    }    try {
        if(
        row11.typeCanal != null
        ) {
            String tester_tSchemaComplianceCheck_4 = String.valueOf(row11.typeCanal);
        }
    } catch(java.lang.Exception e) {
globalMap.put("tSchemaComplianceCheck_4_ERROR_MESSAGE",e.getMessage());
        ifPassedThrough = false;
        errorCodeThrough += 2;
        errorMessageThrough += "|wrong type";
    }
            resultErrorCodeThrough = handleErrorCode(errorCodeThrough,resultErrorCodeThrough);
            errorCodeThrough = 0;
            resultErrorMessageThrough = handleErrorMessage(errorMessageThrough,resultErrorMessageThrough,"typeCanal:");
            errorMessageThrough = "";
        }
    }
    RowSetValueUtil_tSchemaComplianceCheck_4 rsvUtil_tSchemaComplianceCheck_4 = new RowSetValueUtil_tSchemaComplianceCheck_4();

 



/**
 * [tSchemaComplianceCheck_4 begin ] stop
 */



	
	/**
	 * [tUniqRow_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tUniqRow_4", false);
		start_Hash.put("tUniqRow_4", System.currentTimeMillis());
		
	
	currentComponent="tUniqRow_4";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row10");
					}
				
		int tos_count_tUniqRow_4 = 0;
		

	
		class KeyStruct_tUniqRow_4 {
	
			private static final int DEFAULT_HASHCODE = 1;
		    private static final int PRIME = 31;
		    private int hashCode = DEFAULT_HASHCODE;
		    public boolean hashCodeDirty = true;
	
	        
					Integer idCanal;        
	        
		    @Override
			public int hashCode() {
				if (this.hashCodeDirty) {
					final int prime = PRIME;
					int result = DEFAULT_HASHCODE;
			
								result = prime * result + ((this.idCanal == null) ? 0 : this.idCanal.hashCode());
								
		    		this.hashCode = result;
		    		this.hashCodeDirty = false;		
				}
				return this.hashCode;
			}
			
			@Override
			public boolean equals(Object obj) {
				if (this == obj) return true;
				if (obj == null) return false;
				if (getClass() != obj.getClass()) return false;
				final KeyStruct_tUniqRow_4 other = (KeyStruct_tUniqRow_4) obj;
				
									if (this.idCanal == null) {
										if (other.idCanal != null) 
											return false;
								
									} else if (!this.idCanal.equals(other.idCanal))
								 
										return false;
								
				
				return true;
			}
	  
	        
		}

	
int nb_uniques_tUniqRow_4 = 0;
int nb_duplicates_tUniqRow_4 = 0;
KeyStruct_tUniqRow_4 finder_tUniqRow_4 = new KeyStruct_tUniqRow_4();
java.util.Set<KeyStruct_tUniqRow_4> keystUniqRow_4 = new java.util.HashSet<KeyStruct_tUniqRow_4>(); 

 



/**
 * [tUniqRow_4 begin ] stop
 */



	
	/**
	 * [tFileInputDelimited_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileInputDelimited_4", false);
		start_Hash.put("tFileInputDelimited_4", System.currentTimeMillis());
		
	
	currentComponent="tFileInputDelimited_4";

	
		int tos_count_tFileInputDelimited_4 = 0;
		
	
	
	
 
	
	
	final routines.system.RowState rowstate_tFileInputDelimited_4 = new routines.system.RowState();
	
	
				int nb_line_tFileInputDelimited_4 = 0;
				org.talend.fileprocess.FileInputDelimited fid_tFileInputDelimited_4 = null;
				int limit_tFileInputDelimited_4 = -1;
				try{
					
						Object filename_tFileInputDelimited_4 = context.source_path+"canauxDistribution.csv";
						if(filename_tFileInputDelimited_4 instanceof java.io.InputStream){
							
			int footer_value_tFileInputDelimited_4 = 0, random_value_tFileInputDelimited_4 = -1;
			if(footer_value_tFileInputDelimited_4 >0 || random_value_tFileInputDelimited_4 > 0){
				throw new java.lang.Exception("When the input source is a stream,footer and random shouldn't be bigger than 0.");				
			}
		
						}
						try {
							fid_tFileInputDelimited_4 = new org.talend.fileprocess.FileInputDelimited(context.source_path+"canauxDistribution.csv", "UTF-8",",","\n",false,1,0,
									limit_tFileInputDelimited_4
								,-1, false);
						} catch(java.lang.Exception e) {
globalMap.put("tFileInputDelimited_4_ERROR_MESSAGE",e.getMessage());
							
								
								System.err.println(e.getMessage());
							
						}
					
				    
					while (fid_tFileInputDelimited_4!=null && fid_tFileInputDelimited_4.nextRecord()) {
						rowstate_tFileInputDelimited_4.reset();
						
			    						row10 = null;			
												
									boolean whetherReject_tFileInputDelimited_4 = false;
									row10 = new row10Struct();
									try {
										
				int columnIndexWithD_tFileInputDelimited_4 = 0;
				
					String temp = ""; 
				
					columnIndexWithD_tFileInputDelimited_4 = 0;
					
						temp = fid_tFileInputDelimited_4.get(columnIndexWithD_tFileInputDelimited_4);
						if(temp.length() > 0) {
							
								try {
								
    								row10.idCanal = ParserUtils.parseTo_Integer(temp);
    							
    							} catch(java.lang.Exception ex_tFileInputDelimited_4) {
globalMap.put("tFileInputDelimited_4_ERROR_MESSAGE",ex_tFileInputDelimited_4.getMessage());
									rowstate_tFileInputDelimited_4.setException(new RuntimeException(String.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
										"idCanal", "row10", temp, ex_tFileInputDelimited_4), ex_tFileInputDelimited_4));
								}
    							
						} else {						
							
								
									row10.idCanal = null;
								
							
						}
					
				
					columnIndexWithD_tFileInputDelimited_4 = 1;
					
							row10.nomCanal = fid_tFileInputDelimited_4.get(columnIndexWithD_tFileInputDelimited_4);
						
				
					columnIndexWithD_tFileInputDelimited_4 = 2;
					
							row10.typeCanal = fid_tFileInputDelimited_4.get(columnIndexWithD_tFileInputDelimited_4);
						
				
				
										
										if(rowstate_tFileInputDelimited_4.getException()!=null) {
											throw rowstate_tFileInputDelimited_4.getException();
										}
										
										
							
			    					} catch (java.lang.Exception e) {
globalMap.put("tFileInputDelimited_4_ERROR_MESSAGE",e.getMessage());
			        					whetherReject_tFileInputDelimited_4 = true;
			        					
			                					System.err.println(e.getMessage());
			                					row10 = null;
			                				
										
			    					}
								

 



/**
 * [tFileInputDelimited_4 begin ] stop
 */
	
	/**
	 * [tFileInputDelimited_4 main ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_4";

	

 


	tos_count_tFileInputDelimited_4++;

/**
 * [tFileInputDelimited_4 main ] stop
 */
	
	/**
	 * [tFileInputDelimited_4 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_4";

	

 



/**
 * [tFileInputDelimited_4 process_data_begin ] stop
 */
// Start of branch "row10"
if(row10 != null) { 



	
	/**
	 * [tUniqRow_4 main ] start
	 */

	

	
	
	currentComponent="tUniqRow_4";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row10"
						
						);
					}
					
row11 = null;			
finder_tUniqRow_4.idCanal = row10.idCanal;	
finder_tUniqRow_4.hashCodeDirty = true;
if (!keystUniqRow_4.contains(finder_tUniqRow_4)) {
		KeyStruct_tUniqRow_4 new_tUniqRow_4 = new KeyStruct_tUniqRow_4();

		
new_tUniqRow_4.idCanal = row10.idCanal;
		
		keystUniqRow_4.add(new_tUniqRow_4);if(row11 == null){ 
	
	row11 = new row11Struct();
}row11.idCanal = row10.idCanal;			row11.nomCanal = row10.nomCanal;			row11.typeCanal = row10.typeCanal;					
		nb_uniques_tUniqRow_4++;
	} else {
	  nb_duplicates_tUniqRow_4++;
	}

 


	tos_count_tUniqRow_4++;

/**
 * [tUniqRow_4 main ] stop
 */
	
	/**
	 * [tUniqRow_4 process_data_begin ] start
	 */

	

	
	
	currentComponent="tUniqRow_4";

	

 



/**
 * [tUniqRow_4 process_data_begin ] stop
 */
// Start of branch "row11"
if(row11 != null) { 



	
	/**
	 * [tSchemaComplianceCheck_4 main ] start
	 */

	

	
	
	currentComponent="tSchemaComplianceCheck_4";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row11"
						
						);
					}
					
	row12 = null;
	rsvUtil_tSchemaComplianceCheck_4.setRowValue_0(row11);
	if (rsvUtil_tSchemaComplianceCheck_4.ifPassedThrough) {
		row12 = new row12Struct();
		row12.idCanal = row11.idCanal;
		row12.nomCanal = row11.nomCanal;
		row12.typeCanal = row11.typeCanal;
	}
	rsvUtil_tSchemaComplianceCheck_4.reset();

 


	tos_count_tSchemaComplianceCheck_4++;

/**
 * [tSchemaComplianceCheck_4 main ] stop
 */
	
	/**
	 * [tSchemaComplianceCheck_4 process_data_begin ] start
	 */

	

	
	
	currentComponent="tSchemaComplianceCheck_4";

	

 



/**
 * [tSchemaComplianceCheck_4 process_data_begin ] stop
 */
// Start of branch "row12"
if(row12 != null) { 



	
	/**
	 * [tMap_7 main ] start
	 */

	

	
	
	currentComponent="tMap_7";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row12"
						
						);
					}
					

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_7 = false;
		

        // ###############################
        // # Input tables (lookups)
		  boolean rejectedInnerJoin_tMap_7 = false;
		  boolean mainRowRejected_tMap_7 = false;
            				    								  
		// ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_7__Struct Var = Var__tMap_7;// ###############################
        // ###############################
        // # Output tables

out5 = null;


// # Output table : 'out5'
out5_tmp.ID_CANAL = row12.idCanal ;
out5_tmp.NOM_CANAL = routines.Clean.nettoie(row12.nomCanal) ;
out5_tmp.TYPE_CANAL = routines.Clean.nettoie(row12.typeCanal) ;
out5 = out5_tmp;
// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_7 = false;










 


	tos_count_tMap_7++;

/**
 * [tMap_7 main ] stop
 */
	
	/**
	 * [tMap_7 process_data_begin ] start
	 */

	

	
	
	currentComponent="tMap_7";

	

 



/**
 * [tMap_7 process_data_begin ] stop
 */
// Start of branch "out5"
if(out5 != null) { 



	
	/**
	 * [tDBOutput_4 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_4";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"out5"
						
						);
					}
					



        whetherReject_tDBOutput_4 = false;
                    pstmt_tDBOutput_4.setInt(1, out5.ID_CANAL);

            int checkCount_tDBOutput_4 = -1;
            try (java.sql.ResultSet rs_tDBOutput_4 = pstmt_tDBOutput_4.executeQuery()) {
                while(rs_tDBOutput_4.next()) {
                    checkCount_tDBOutput_4 = rs_tDBOutput_4.getInt(1);
                }
            }
            if(checkCount_tDBOutput_4 > 0) {
                        if(out5.NOM_CANAL == null) {
pstmtUpdate_tDBOutput_4.setNull(1, java.sql.Types.VARCHAR);
} else {pstmtUpdate_tDBOutput_4.setString(1, out5.NOM_CANAL);
}

                        if(out5.TYPE_CANAL == null) {
pstmtUpdate_tDBOutput_4.setNull(2, java.sql.Types.VARCHAR);
} else {pstmtUpdate_tDBOutput_4.setString(2, out5.TYPE_CANAL);
}

                        pstmtUpdate_tDBOutput_4.setInt(3 + count_tDBOutput_4, out5.ID_CANAL);

                try {
                    int processedCount_tDBOutput_4 = pstmtUpdate_tDBOutput_4.executeUpdate();
                    updatedCount_tDBOutput_4 += processedCount_tDBOutput_4;
                    rowsToCommitCount_tDBOutput_4 += processedCount_tDBOutput_4;
                    nb_line_tDBOutput_4++;
                } catch(java.lang.Exception e_tDBOutput_4) {
globalMap.put("tDBOutput_4_ERROR_MESSAGE",e_tDBOutput_4.getMessage());
                    whetherReject_tDBOutput_4 = true;
                        nb_line_tDBOutput_4++;
                            System.err.print(e_tDBOutput_4.getMessage());
                }
            } else {
                        pstmtInsert_tDBOutput_4.setInt(1, out5.ID_CANAL);

                        if(out5.NOM_CANAL == null) {
pstmtInsert_tDBOutput_4.setNull(2, java.sql.Types.VARCHAR);
} else {pstmtInsert_tDBOutput_4.setString(2, out5.NOM_CANAL);
}

                        if(out5.TYPE_CANAL == null) {
pstmtInsert_tDBOutput_4.setNull(3, java.sql.Types.VARCHAR);
} else {pstmtInsert_tDBOutput_4.setString(3, out5.TYPE_CANAL);
}

                try {
                    int processedCount_tDBOutput_4 = pstmtInsert_tDBOutput_4.executeUpdate();
                    insertedCount_tDBOutput_4 += processedCount_tDBOutput_4;
                    rowsToCommitCount_tDBOutput_4 += processedCount_tDBOutput_4;
                    nb_line_tDBOutput_4++;
                } catch(java.lang.Exception e_tDBOutput_4) {
globalMap.put("tDBOutput_4_ERROR_MESSAGE",e_tDBOutput_4.getMessage());
                    whetherReject_tDBOutput_4 = true;
                        nb_line_tDBOutput_4++;
                            System.err.print(e_tDBOutput_4.getMessage());
                }
            }

 


	tos_count_tDBOutput_4++;

/**
 * [tDBOutput_4 main ] stop
 */
	
	/**
	 * [tDBOutput_4 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_4";

	

 



/**
 * [tDBOutput_4 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_4 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_4";

	

 



/**
 * [tDBOutput_4 process_data_end ] stop
 */

} // End of branch "out5"




	
	/**
	 * [tMap_7 process_data_end ] start
	 */

	

	
	
	currentComponent="tMap_7";

	

 



/**
 * [tMap_7 process_data_end ] stop
 */

} // End of branch "row12"




	
	/**
	 * [tSchemaComplianceCheck_4 process_data_end ] start
	 */

	

	
	
	currentComponent="tSchemaComplianceCheck_4";

	

 



/**
 * [tSchemaComplianceCheck_4 process_data_end ] stop
 */

} // End of branch "row11"




	
	/**
	 * [tUniqRow_4 process_data_end ] start
	 */

	

	
	
	currentComponent="tUniqRow_4";

	

 



/**
 * [tUniqRow_4 process_data_end ] stop
 */

} // End of branch "row10"




	
	/**
	 * [tFileInputDelimited_4 process_data_end ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_4";

	

 



/**
 * [tFileInputDelimited_4 process_data_end ] stop
 */
	
	/**
	 * [tFileInputDelimited_4 end ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_4";

	



            }
            }finally{
                if(!((Object)(context.source_path+"canauxDistribution.csv") instanceof java.io.InputStream)){
                	if(fid_tFileInputDelimited_4!=null){
                		fid_tFileInputDelimited_4.close();
                	}
                }
                if(fid_tFileInputDelimited_4!=null){
                	globalMap.put("tFileInputDelimited_4_NB_LINE", fid_tFileInputDelimited_4.getRowNumber());
					
                }
			}
			  

 

ok_Hash.put("tFileInputDelimited_4", true);
end_Hash.put("tFileInputDelimited_4", System.currentTimeMillis());




/**
 * [tFileInputDelimited_4 end ] stop
 */

	
	/**
	 * [tUniqRow_4 end ] start
	 */

	

	
	
	currentComponent="tUniqRow_4";

	

globalMap.put("tUniqRow_4_NB_UNIQUES",nb_uniques_tUniqRow_4);
globalMap.put("tUniqRow_4_NB_DUPLICATES",nb_duplicates_tUniqRow_4);

				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row10");
			  	}
			  	
 

ok_Hash.put("tUniqRow_4", true);
end_Hash.put("tUniqRow_4", System.currentTimeMillis());




/**
 * [tUniqRow_4 end ] stop
 */

	
	/**
	 * [tSchemaComplianceCheck_4 end ] start
	 */

	

	
	
	currentComponent="tSchemaComplianceCheck_4";

	

				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row11");
			  	}
			  	
 

ok_Hash.put("tSchemaComplianceCheck_4", true);
end_Hash.put("tSchemaComplianceCheck_4", System.currentTimeMillis());




/**
 * [tSchemaComplianceCheck_4 end ] stop
 */

	
	/**
	 * [tMap_7 end ] start
	 */

	

	
	
	currentComponent="tMap_7";

	


// ###############################
// # Lookup hashes releasing
// ###############################      





				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row12");
			  	}
			  	
 

ok_Hash.put("tMap_7", true);
end_Hash.put("tMap_7", System.currentTimeMillis());




/**
 * [tMap_7 end ] stop
 */

	
	/**
	 * [tDBOutput_4 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_4";

	
	



	
        if(pstmtUpdate_tDBOutput_4 != null){
            pstmtUpdate_tDBOutput_4.close();
            resourceMap.remove("pstmtUpdate_tDBOutput_4");
        }
        if(pstmtInsert_tDBOutput_4 != null){
            pstmtInsert_tDBOutput_4.close();
            resourceMap.remove("pstmtInsert_tDBOutput_4");
        }
        if(pstmt_tDBOutput_4 != null) {
            pstmt_tDBOutput_4.close();
            resourceMap.remove("pstmt_tDBOutput_4");
        }
    resourceMap.put("statementClosed_tDBOutput_4", true);

	
	nb_line_deleted_tDBOutput_4=nb_line_deleted_tDBOutput_4+ deletedCount_tDBOutput_4;
	nb_line_update_tDBOutput_4=nb_line_update_tDBOutput_4 + updatedCount_tDBOutput_4;
	nb_line_inserted_tDBOutput_4=nb_line_inserted_tDBOutput_4 + insertedCount_tDBOutput_4;
	nb_line_rejected_tDBOutput_4=nb_line_rejected_tDBOutput_4 + rejectedCount_tDBOutput_4;
	
        globalMap.put("tDBOutput_4_NB_LINE",nb_line_tDBOutput_4);
        globalMap.put("tDBOutput_4_NB_LINE_UPDATED",nb_line_update_tDBOutput_4);
        globalMap.put("tDBOutput_4_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_4);
        globalMap.put("tDBOutput_4_NB_LINE_DELETED",nb_line_deleted_tDBOutput_4);
        globalMap.put("tDBOutput_4_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_4);
    

	



				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"out5");
			  	}
			  	
 

ok_Hash.put("tDBOutput_4", true);
end_Hash.put("tDBOutput_4", System.currentTimeMillis());




/**
 * [tDBOutput_4 end ] stop
 */












				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tFileInputDelimited_4:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk6", 0, "ok");
								} 
							
							tFileInputDelimited_5Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFileInputDelimited_4 finally ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_4";

	

 



/**
 * [tFileInputDelimited_4 finally ] stop
 */

	
	/**
	 * [tUniqRow_4 finally ] start
	 */

	

	
	
	currentComponent="tUniqRow_4";

	

 



/**
 * [tUniqRow_4 finally ] stop
 */

	
	/**
	 * [tSchemaComplianceCheck_4 finally ] start
	 */

	

	
	
	currentComponent="tSchemaComplianceCheck_4";

	

 



/**
 * [tSchemaComplianceCheck_4 finally ] stop
 */

	
	/**
	 * [tMap_7 finally ] start
	 */

	

	
	
	currentComponent="tMap_7";

	

 



/**
 * [tMap_7 finally ] stop
 */

	
	/**
	 * [tDBOutput_4 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_4";

	



    if (resourceMap.get("statementClosed_tDBOutput_4") == null) {
                java.sql.PreparedStatement pstmtUpdateToClose_tDBOutput_4 = null;
                if ((pstmtUpdateToClose_tDBOutput_4 = (java.sql.PreparedStatement) resourceMap.remove("pstmtUpdate_tDBOutput_4")) != null) {
                    pstmtUpdateToClose_tDBOutput_4.close();
                }
                java.sql.PreparedStatement pstmtInsertToClose_tDBOutput_4 = null;
                if ((pstmtInsertToClose_tDBOutput_4 = (java.sql.PreparedStatement) resourceMap.remove("pstmtInsert_tDBOutput_4")) != null) {
                    pstmtInsertToClose_tDBOutput_4.close();
                }
                java.sql.PreparedStatement pstmtToClose_tDBOutput_4 = null;
                if ((pstmtToClose_tDBOutput_4 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_4")) != null) {
                    pstmtToClose_tDBOutput_4.close();
                }
    }
 



/**
 * [tDBOutput_4 finally ] stop
 */












				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFileInputDelimited_4_SUBPROCESS_STATE", 1);
	}
	


public static class out7Struct implements routines.system.IPersistableRow<out7Struct> {
    final static byte[] commonByteArrayLock_LOCAL_PROJECT_STG_Load = new byte[0];
    static byte[] commonByteArray_LOCAL_PROJECT_STG_Load = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int ID_VISITEUR;

				public int getID_VISITEUR () {
					return this.ID_VISITEUR;
				}
				
			    public String NOM;

				public String getNOM () {
					return this.NOM;
				}
				
			    public String PRENOM;

				public String getPRENOM () {
					return this.PRENOM;
				}
				
			    public String MAIL;

				public String getMAIL () {
					return this.MAIL;
				}
				
			    public String TELEPHONE;

				public String getTELEPHONE () {
					return this.TELEPHONE;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.ID_VISITEUR;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final out7Struct other = (out7Struct) obj;
		
						if (this.ID_VISITEUR != other.ID_VISITEUR)
							return false;
					

		return true;
    }

	public void copyDataTo(out7Struct other) {

		other.ID_VISITEUR = this.ID_VISITEUR;
	            other.NOM = this.NOM;
	            other.PRENOM = this.PRENOM;
	            other.MAIL = this.MAIL;
	            other.TELEPHONE = this.TELEPHONE;
	            
	}

	public void copyKeysDataTo(out7Struct other) {

		other.ID_VISITEUR = this.ID_VISITEUR;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
			        this.ID_VISITEUR = dis.readInt();
					
					this.NOM = readString(dis);
					
					this.PRENOM = readString(dis);
					
					this.MAIL = readString(dis);
					
					this.TELEPHONE = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
			        this.ID_VISITEUR = dis.readInt();
					
					this.NOM = readString(dis);
					
					this.PRENOM = readString(dis);
					
					this.MAIL = readString(dis);
					
					this.TELEPHONE = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.ID_VISITEUR);
					
					// String
				
						writeString(this.NOM,dos);
					
					// String
				
						writeString(this.PRENOM,dos);
					
					// String
				
						writeString(this.MAIL,dos);
					
					// String
				
						writeString(this.TELEPHONE,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.ID_VISITEUR);
					
					// String
				
						writeString(this.NOM,dos);
					
					// String
				
						writeString(this.PRENOM,dos);
					
					// String
				
						writeString(this.MAIL,dos);
					
					// String
				
						writeString(this.TELEPHONE,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("ID_VISITEUR="+String.valueOf(ID_VISITEUR));
		sb.append(",NOM="+NOM);
		sb.append(",PRENOM="+PRENOM);
		sb.append(",MAIL="+MAIL);
		sb.append(",TELEPHONE="+TELEPHONE);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(out7Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.ID_VISITEUR, other.ID_VISITEUR);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row15Struct implements routines.system.IPersistableRow<row15Struct> {
    final static byte[] commonByteArrayLock_LOCAL_PROJECT_STG_Load = new byte[0];
    static byte[] commonByteArray_LOCAL_PROJECT_STG_Load = new byte[0];

	
			    public Integer id;

				public Integer getId () {
					return this.id;
				}
				
			    public String nom;

				public String getNom () {
					return this.nom;
				}
				
			    public String prenom;

				public String getPrenom () {
					return this.prenom;
				}
				
			    public String email;

				public String getEmail () {
					return this.email;
				}
				
			    public String telephone;

				public String getTelephone () {
					return this.telephone;
				}
				


	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
						this.id = readInteger(dis);
					
					this.nom = readString(dis);
					
					this.prenom = readString(dis);
					
					this.email = readString(dis);
					
					this.telephone = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
						this.id = readInteger(dis);
					
					this.nom = readString(dis);
					
					this.prenom = readString(dis);
					
					this.email = readString(dis);
					
					this.telephone = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.id,dos);
					
					// String
				
						writeString(this.nom,dos);
					
					// String
				
						writeString(this.prenom,dos);
					
					// String
				
						writeString(this.email,dos);
					
					// String
				
						writeString(this.telephone,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// Integer
				
						writeInteger(this.id,dos);
					
					// String
				
						writeString(this.nom,dos);
					
					// String
				
						writeString(this.prenom,dos);
					
					// String
				
						writeString(this.email,dos);
					
					// String
				
						writeString(this.telephone,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id="+String.valueOf(id));
		sb.append(",nom="+nom);
		sb.append(",prenom="+prenom);
		sb.append(",email="+email);
		sb.append(",telephone="+telephone);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row15Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row14Struct implements routines.system.IPersistableRow<row14Struct> {
    final static byte[] commonByteArrayLock_LOCAL_PROJECT_STG_Load = new byte[0];
    static byte[] commonByteArray_LOCAL_PROJECT_STG_Load = new byte[0];

	
			    public Integer id;

				public Integer getId () {
					return this.id;
				}
				
			    public String nom;

				public String getNom () {
					return this.nom;
				}
				
			    public String prenom;

				public String getPrenom () {
					return this.prenom;
				}
				
			    public String email;

				public String getEmail () {
					return this.email;
				}
				
			    public String telephone;

				public String getTelephone () {
					return this.telephone;
				}
				


	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
						this.id = readInteger(dis);
					
					this.nom = readString(dis);
					
					this.prenom = readString(dis);
					
					this.email = readString(dis);
					
					this.telephone = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
						this.id = readInteger(dis);
					
					this.nom = readString(dis);
					
					this.prenom = readString(dis);
					
					this.email = readString(dis);
					
					this.telephone = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.id,dos);
					
					// String
				
						writeString(this.nom,dos);
					
					// String
				
						writeString(this.prenom,dos);
					
					// String
				
						writeString(this.email,dos);
					
					// String
				
						writeString(this.telephone,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// Integer
				
						writeInteger(this.id,dos);
					
					// String
				
						writeString(this.nom,dos);
					
					// String
				
						writeString(this.prenom,dos);
					
					// String
				
						writeString(this.email,dos);
					
					// String
				
						writeString(this.telephone,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id="+String.valueOf(id));
		sb.append(",nom="+nom);
		sb.append(",prenom="+prenom);
		sb.append(",email="+email);
		sb.append(",telephone="+telephone);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row14Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row13Struct implements routines.system.IPersistableRow<row13Struct> {
    final static byte[] commonByteArrayLock_LOCAL_PROJECT_STG_Load = new byte[0];
    static byte[] commonByteArray_LOCAL_PROJECT_STG_Load = new byte[0];

	
			    public Integer id;

				public Integer getId () {
					return this.id;
				}
				
			    public String nom;

				public String getNom () {
					return this.nom;
				}
				
			    public String prenom;

				public String getPrenom () {
					return this.prenom;
				}
				
			    public String email;

				public String getEmail () {
					return this.email;
				}
				
			    public String telephone;

				public String getTelephone () {
					return this.telephone;
				}
				


	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
						this.id = readInteger(dis);
					
					this.nom = readString(dis);
					
					this.prenom = readString(dis);
					
					this.email = readString(dis);
					
					this.telephone = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
						this.id = readInteger(dis);
					
					this.nom = readString(dis);
					
					this.prenom = readString(dis);
					
					this.email = readString(dis);
					
					this.telephone = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.id,dos);
					
					// String
				
						writeString(this.nom,dos);
					
					// String
				
						writeString(this.prenom,dos);
					
					// String
				
						writeString(this.email,dos);
					
					// String
				
						writeString(this.telephone,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// Integer
				
						writeInteger(this.id,dos);
					
					// String
				
						writeString(this.nom,dos);
					
					// String
				
						writeString(this.prenom,dos);
					
					// String
				
						writeString(this.email,dos);
					
					// String
				
						writeString(this.telephone,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id="+String.valueOf(id));
		sb.append(",nom="+nom);
		sb.append(",prenom="+prenom);
		sb.append(",email="+email);
		sb.append(",telephone="+telephone);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row13Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tFileInputDelimited_5Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFileInputDelimited_5_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row13Struct row13 = new row13Struct();
row14Struct row14 = new row14Struct();
row15Struct row15 = new row15Struct();
out7Struct out7 = new out7Struct();







	
	/**
	 * [tDBOutput_5 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_5", false);
		start_Hash.put("tDBOutput_5", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_5";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"out7");
					}
				
		int tos_count_tDBOutput_5 = 0;
		






        int updateKeyCount_tDBOutput_5 = 1;
        if(updateKeyCount_tDBOutput_5 < 1) {
            throw new RuntimeException("For update, Schema must have a key");
        } else if (updateKeyCount_tDBOutput_5 == 5 && true) {
                    System.err.println("For update, every Schema column can not be a key");
        }
    
    int nb_line_tDBOutput_5 = 0;
    int nb_line_update_tDBOutput_5 = 0;
    int nb_line_inserted_tDBOutput_5 = 0;
    int nb_line_deleted_tDBOutput_5 = 0;
    int nb_line_rejected_tDBOutput_5 = 0;

    int tmp_batchUpdateCount_tDBOutput_5 = 0;

    int deletedCount_tDBOutput_5=0;
    int updatedCount_tDBOutput_5=0;
    int insertedCount_tDBOutput_5=0;
    int rowsToCommitCount_tDBOutput_5=0;
    int rejectedCount_tDBOutput_5=0;

    boolean whetherReject_tDBOutput_5 = false;

    java.sql.Connection conn_tDBOutput_5 = null;

    //optional table
    String dbschema_tDBOutput_5 = null;
    String tableName_tDBOutput_5 = null;
        dbschema_tDBOutput_5 = (String)globalMap.get("dbschema_tDBConnection_2");
		
        conn_tDBOutput_5 = (java.sql.Connection)globalMap.get("conn_tDBConnection_2");
        int count_tDBOutput_5=0;

        if(dbschema_tDBOutput_5 == null || dbschema_tDBOutput_5.trim().length() == 0) {
            tableName_tDBOutput_5 = ("STG_DIM_VISITEUR");
        } else {
            tableName_tDBOutput_5 = dbschema_tDBOutput_5 + "." + ("STG_DIM_VISITEUR");
        }
            try (java.sql.Statement stmtClear_tDBOutput_5 = conn_tDBOutput_5.createStatement()) {
                stmtClear_tDBOutput_5.executeUpdate("DELETE FROM " + tableName_tDBOutput_5 + "");
            }
                java.sql.PreparedStatement pstmt_tDBOutput_5 = conn_tDBOutput_5.prepareStatement("SELECT COUNT(1) FROM " + tableName_tDBOutput_5 + " WHERE ID_VISITEUR = ?");
                resourceMap.put("pstmt_tDBOutput_5", pstmt_tDBOutput_5);
                String insert_tDBOutput_5 = "INSERT INTO " + tableName_tDBOutput_5 + " (ID_VISITEUR,NOM,PRENOM,MAIL,TELEPHONE) VALUES (?,?,?,?,?)";    
                java.sql.PreparedStatement pstmtInsert_tDBOutput_5 = conn_tDBOutput_5.prepareStatement(insert_tDBOutput_5);
                resourceMap.put("pstmtInsert_tDBOutput_5", pstmtInsert_tDBOutput_5);
                String update_tDBOutput_5 = "UPDATE " + tableName_tDBOutput_5 + " SET NOM = ?,PRENOM = ?,MAIL = ?,TELEPHONE = ? WHERE ID_VISITEUR = ?";
                java.sql.PreparedStatement pstmtUpdate_tDBOutput_5 = conn_tDBOutput_5.prepareStatement(update_tDBOutput_5);
                resourceMap.put("pstmtUpdate_tDBOutput_5", pstmtUpdate_tDBOutput_5);





 



/**
 * [tDBOutput_5 begin ] stop
 */



	
	/**
	 * [tMap_8 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_8", false);
		start_Hash.put("tMap_8", System.currentTimeMillis());
		
	
	currentComponent="tMap_8";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row15");
					}
				
		int tos_count_tMap_8 = 0;
		




// ###############################
// # Lookup's keys initialization
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_8__Struct  {
}
Var__tMap_8__Struct Var__tMap_8 = new Var__tMap_8__Struct();
// ###############################

// ###############################
// # Outputs initialization
out7Struct out7_tmp = new out7Struct();
// ###############################

        
        



        









 



/**
 * [tMap_8 begin ] stop
 */



	
	/**
	 * [tSchemaComplianceCheck_5 begin ] start
	 */

	

	
		
		ok_Hash.put("tSchemaComplianceCheck_5", false);
		start_Hash.put("tSchemaComplianceCheck_5", System.currentTimeMillis());
		
	
	currentComponent="tSchemaComplianceCheck_5";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row14");
					}
				
		int tos_count_tSchemaComplianceCheck_5 = 0;
		

    class RowSetValueUtil_tSchemaComplianceCheck_5 {

        boolean ifPassedThrough = true;
        int errorCodeThrough = 0;
        String errorMessageThrough = "";
        int resultErrorCodeThrough = 0;
        String resultErrorMessageThrough = "";
        String tmpContentThrough = null;

        boolean ifPassed = true;
        int errorCode = 0;
        String errorMessage = "";

        void handleBigdecimalPrecision(String data, int iPrecision, int maxLength){
            //number of digits before the decimal point(ignoring frontend zeroes)
            int len1 = 0;
            int len2 = 0;
            ifPassed = true;
            errorCode = 0;
            errorMessage = "";
            if(data.startsWith("-")){
                data = data.substring(1);
            }
            data = org.apache.commons.lang.StringUtils.stripStart(data, "0");

            if(data.indexOf(".") >= 0){
                len1 = data.indexOf(".");
                data = org.apache.commons.lang.StringUtils.stripEnd(data, "0");
                len2 = data.length() - (len1 + 1);
            }else{
                len1 = data.length();
            }

            if (iPrecision < len2) {
                ifPassed = false;
                errorCode += 8;
                errorMessage += "|precision Non-matches";
            } else if (maxLength < len1 + iPrecision) {
                ifPassed = false;
                errorCode += 8;
                errorMessage += "|invalid Length setting is unsuitable for Precision";
            }
        }

        int handleErrorCode(int errorCode, int resultErrorCode){
            if (errorCode > 0) {
                if (resultErrorCode > 0) {
                    resultErrorCode = 16;
                } else {
                    resultErrorCode = errorCode;
                }
            }
            return resultErrorCode;
        }

        String handleErrorMessage(String errorMessage, String resultErrorMessage, String columnLabel){
            if (errorMessage.length() > 0) {
                if (resultErrorMessage.length() > 0) {
                    resultErrorMessage += ";"+ errorMessage.replaceFirst("\\|", columnLabel);
                } else {
                    resultErrorMessage = errorMessage.replaceFirst("\\|", columnLabel);
                }
            }
            return resultErrorMessage;
        }

        void reset(){
            ifPassedThrough = true;
            errorCodeThrough = 0;
            errorMessageThrough = "";
            resultErrorCodeThrough = 0;
            resultErrorMessageThrough = "";
            tmpContentThrough = null;

            ifPassed = true;
            errorCode = 0;
            errorMessage = "";
        }

        void setRowValue_0(row14Struct row14) {
    // validate nullable (empty as null)
    if ((row14.id == null) || ("".equals(row14.id))) {
        ifPassedThrough = false;
        errorCodeThrough += 4;
        errorMessageThrough += "|empty or null";
    }
            resultErrorCodeThrough = handleErrorCode(errorCodeThrough,resultErrorCodeThrough);
            errorCodeThrough = 0;
            resultErrorMessageThrough = handleErrorMessage(errorMessageThrough,resultErrorMessageThrough,"id:");
            errorMessageThrough = "";
    // validate nullable (empty as null)
    if ((row14.nom == null) || ("".equals(row14.nom))) {
        ifPassedThrough = false;
        errorCodeThrough += 4;
        errorMessageThrough += "|empty or null";
    }    try {
        if(
        row14.nom != null
        ) {
            String tester_tSchemaComplianceCheck_5 = String.valueOf(row14.nom);
        }
    } catch(java.lang.Exception e) {
globalMap.put("tSchemaComplianceCheck_5_ERROR_MESSAGE",e.getMessage());
        ifPassedThrough = false;
        errorCodeThrough += 2;
        errorMessageThrough += "|wrong type";
    }
            resultErrorCodeThrough = handleErrorCode(errorCodeThrough,resultErrorCodeThrough);
            errorCodeThrough = 0;
            resultErrorMessageThrough = handleErrorMessage(errorMessageThrough,resultErrorMessageThrough,"nom:");
            errorMessageThrough = "";
    // validate nullable (empty as null)
    if ((row14.prenom == null) || ("".equals(row14.prenom))) {
        ifPassedThrough = false;
        errorCodeThrough += 4;
        errorMessageThrough += "|empty or null";
    }    try {
        if(
        row14.prenom != null
        ) {
            String tester_tSchemaComplianceCheck_5 = String.valueOf(row14.prenom);
        }
    } catch(java.lang.Exception e) {
globalMap.put("tSchemaComplianceCheck_5_ERROR_MESSAGE",e.getMessage());
        ifPassedThrough = false;
        errorCodeThrough += 2;
        errorMessageThrough += "|wrong type";
    }
            resultErrorCodeThrough = handleErrorCode(errorCodeThrough,resultErrorCodeThrough);
            errorCodeThrough = 0;
            resultErrorMessageThrough = handleErrorMessage(errorMessageThrough,resultErrorMessageThrough,"prenom:");
            errorMessageThrough = "";    try {
        if(
        row14.email != null
        && (!"".equals(row14.email))
        ) {
            String tester_tSchemaComplianceCheck_5 = String.valueOf(row14.email);
        }
    } catch(java.lang.Exception e) {
globalMap.put("tSchemaComplianceCheck_5_ERROR_MESSAGE",e.getMessage());
        ifPassedThrough = false;
        errorCodeThrough += 2;
        errorMessageThrough += "|wrong type";
    }
            resultErrorCodeThrough = handleErrorCode(errorCodeThrough,resultErrorCodeThrough);
            errorCodeThrough = 0;
            resultErrorMessageThrough = handleErrorMessage(errorMessageThrough,resultErrorMessageThrough,"email:");
            errorMessageThrough = "";
    // validate nullable (empty as null)
    if ((row14.telephone == null) || ("".equals(row14.telephone))) {
        ifPassedThrough = false;
        errorCodeThrough += 4;
        errorMessageThrough += "|empty or null";
    }    try {
        if(
        row14.telephone != null
        ) {
            String tester_tSchemaComplianceCheck_5 = String.valueOf(row14.telephone);
        }
    } catch(java.lang.Exception e) {
globalMap.put("tSchemaComplianceCheck_5_ERROR_MESSAGE",e.getMessage());
        ifPassedThrough = false;
        errorCodeThrough += 2;
        errorMessageThrough += "|wrong type";
    }
            resultErrorCodeThrough = handleErrorCode(errorCodeThrough,resultErrorCodeThrough);
            errorCodeThrough = 0;
            resultErrorMessageThrough = handleErrorMessage(errorMessageThrough,resultErrorMessageThrough,"telephone:");
            errorMessageThrough = "";
        }
    }
    RowSetValueUtil_tSchemaComplianceCheck_5 rsvUtil_tSchemaComplianceCheck_5 = new RowSetValueUtil_tSchemaComplianceCheck_5();

 



/**
 * [tSchemaComplianceCheck_5 begin ] stop
 */



	
	/**
	 * [tUniqRow_5 begin ] start
	 */

	

	
		
		ok_Hash.put("tUniqRow_5", false);
		start_Hash.put("tUniqRow_5", System.currentTimeMillis());
		
	
	currentComponent="tUniqRow_5";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row13");
					}
				
		int tos_count_tUniqRow_5 = 0;
		

	
		class KeyStruct_tUniqRow_5 {
	
			private static final int DEFAULT_HASHCODE = 1;
		    private static final int PRIME = 31;
		    private int hashCode = DEFAULT_HASHCODE;
		    public boolean hashCodeDirty = true;
	
	        
					Integer id;        
	        
		    @Override
			public int hashCode() {
				if (this.hashCodeDirty) {
					final int prime = PRIME;
					int result = DEFAULT_HASHCODE;
			
								result = prime * result + ((this.id == null) ? 0 : this.id.hashCode());
								
		    		this.hashCode = result;
		    		this.hashCodeDirty = false;		
				}
				return this.hashCode;
			}
			
			@Override
			public boolean equals(Object obj) {
				if (this == obj) return true;
				if (obj == null) return false;
				if (getClass() != obj.getClass()) return false;
				final KeyStruct_tUniqRow_5 other = (KeyStruct_tUniqRow_5) obj;
				
									if (this.id == null) {
										if (other.id != null) 
											return false;
								
									} else if (!this.id.equals(other.id))
								 
										return false;
								
				
				return true;
			}
	  
	        
		}

	
int nb_uniques_tUniqRow_5 = 0;
int nb_duplicates_tUniqRow_5 = 0;
KeyStruct_tUniqRow_5 finder_tUniqRow_5 = new KeyStruct_tUniqRow_5();
java.util.Set<KeyStruct_tUniqRow_5> keystUniqRow_5 = new java.util.HashSet<KeyStruct_tUniqRow_5>(); 

 



/**
 * [tUniqRow_5 begin ] stop
 */



	
	/**
	 * [tFileInputDelimited_5 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileInputDelimited_5", false);
		start_Hash.put("tFileInputDelimited_5", System.currentTimeMillis());
		
	
	currentComponent="tFileInputDelimited_5";

	
		int tos_count_tFileInputDelimited_5 = 0;
		
	
	
	
 
	
	
	final routines.system.RowState rowstate_tFileInputDelimited_5 = new routines.system.RowState();
	
	
				int nb_line_tFileInputDelimited_5 = 0;
				org.talend.fileprocess.FileInputDelimited fid_tFileInputDelimited_5 = null;
				int limit_tFileInputDelimited_5 = -1;
				try{
					
						Object filename_tFileInputDelimited_5 = context.source_path+"visiteur.csv";
						if(filename_tFileInputDelimited_5 instanceof java.io.InputStream){
							
			int footer_value_tFileInputDelimited_5 = 0, random_value_tFileInputDelimited_5 = -1;
			if(footer_value_tFileInputDelimited_5 >0 || random_value_tFileInputDelimited_5 > 0){
				throw new java.lang.Exception("When the input source is a stream,footer and random shouldn't be bigger than 0.");				
			}
		
						}
						try {
							fid_tFileInputDelimited_5 = new org.talend.fileprocess.FileInputDelimited(context.source_path+"visiteur.csv", "US-ASCII",",","\n",false,1,0,
									limit_tFileInputDelimited_5
								,-1, false);
						} catch(java.lang.Exception e) {
globalMap.put("tFileInputDelimited_5_ERROR_MESSAGE",e.getMessage());
							
								
								System.err.println(e.getMessage());
							
						}
					
				    
					while (fid_tFileInputDelimited_5!=null && fid_tFileInputDelimited_5.nextRecord()) {
						rowstate_tFileInputDelimited_5.reset();
						
			    						row13 = null;			
												
									boolean whetherReject_tFileInputDelimited_5 = false;
									row13 = new row13Struct();
									try {
										
				int columnIndexWithD_tFileInputDelimited_5 = 0;
				
					String temp = ""; 
				
					columnIndexWithD_tFileInputDelimited_5 = 0;
					
						temp = fid_tFileInputDelimited_5.get(columnIndexWithD_tFileInputDelimited_5);
						if(temp.length() > 0) {
							
								try {
								
    								row13.id = ParserUtils.parseTo_Integer(temp);
    							
    							} catch(java.lang.Exception ex_tFileInputDelimited_5) {
globalMap.put("tFileInputDelimited_5_ERROR_MESSAGE",ex_tFileInputDelimited_5.getMessage());
									rowstate_tFileInputDelimited_5.setException(new RuntimeException(String.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
										"id", "row13", temp, ex_tFileInputDelimited_5), ex_tFileInputDelimited_5));
								}
    							
						} else {						
							
								
									row13.id = null;
								
							
						}
					
				
					columnIndexWithD_tFileInputDelimited_5 = 1;
					
							row13.nom = fid_tFileInputDelimited_5.get(columnIndexWithD_tFileInputDelimited_5);
						
				
					columnIndexWithD_tFileInputDelimited_5 = 2;
					
							row13.prenom = fid_tFileInputDelimited_5.get(columnIndexWithD_tFileInputDelimited_5);
						
				
					columnIndexWithD_tFileInputDelimited_5 = 3;
					
							row13.email = fid_tFileInputDelimited_5.get(columnIndexWithD_tFileInputDelimited_5);
						
				
					columnIndexWithD_tFileInputDelimited_5 = 4;
					
							row13.telephone = fid_tFileInputDelimited_5.get(columnIndexWithD_tFileInputDelimited_5);
						
				
				
										
										if(rowstate_tFileInputDelimited_5.getException()!=null) {
											throw rowstate_tFileInputDelimited_5.getException();
										}
										
										
							
			    					} catch (java.lang.Exception e) {
globalMap.put("tFileInputDelimited_5_ERROR_MESSAGE",e.getMessage());
			        					whetherReject_tFileInputDelimited_5 = true;
			        					
			                					System.err.println(e.getMessage());
			                					row13 = null;
			                				
										
			    					}
								

 



/**
 * [tFileInputDelimited_5 begin ] stop
 */
	
	/**
	 * [tFileInputDelimited_5 main ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_5";

	

 


	tos_count_tFileInputDelimited_5++;

/**
 * [tFileInputDelimited_5 main ] stop
 */
	
	/**
	 * [tFileInputDelimited_5 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_5";

	

 



/**
 * [tFileInputDelimited_5 process_data_begin ] stop
 */
// Start of branch "row13"
if(row13 != null) { 



	
	/**
	 * [tUniqRow_5 main ] start
	 */

	

	
	
	currentComponent="tUniqRow_5";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row13"
						
						);
					}
					
row14 = null;			
finder_tUniqRow_5.id = row13.id;	
finder_tUniqRow_5.hashCodeDirty = true;
if (!keystUniqRow_5.contains(finder_tUniqRow_5)) {
		KeyStruct_tUniqRow_5 new_tUniqRow_5 = new KeyStruct_tUniqRow_5();

		
new_tUniqRow_5.id = row13.id;
		
		keystUniqRow_5.add(new_tUniqRow_5);if(row14 == null){ 
	
	row14 = new row14Struct();
}row14.id = row13.id;			row14.nom = row13.nom;			row14.prenom = row13.prenom;			row14.email = row13.email;			row14.telephone = row13.telephone;					
		nb_uniques_tUniqRow_5++;
	} else {
	  nb_duplicates_tUniqRow_5++;
	}

 


	tos_count_tUniqRow_5++;

/**
 * [tUniqRow_5 main ] stop
 */
	
	/**
	 * [tUniqRow_5 process_data_begin ] start
	 */

	

	
	
	currentComponent="tUniqRow_5";

	

 



/**
 * [tUniqRow_5 process_data_begin ] stop
 */
// Start of branch "row14"
if(row14 != null) { 



	
	/**
	 * [tSchemaComplianceCheck_5 main ] start
	 */

	

	
	
	currentComponent="tSchemaComplianceCheck_5";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row14"
						
						);
					}
					
	row15 = null;
	rsvUtil_tSchemaComplianceCheck_5.setRowValue_0(row14);
	if (rsvUtil_tSchemaComplianceCheck_5.ifPassedThrough) {
		row15 = new row15Struct();
		row15.id = row14.id;
		row15.nom = row14.nom;
		row15.prenom = row14.prenom;
		row15.email = row14.email;
		row15.telephone = row14.telephone;
	}
	rsvUtil_tSchemaComplianceCheck_5.reset();

 


	tos_count_tSchemaComplianceCheck_5++;

/**
 * [tSchemaComplianceCheck_5 main ] stop
 */
	
	/**
	 * [tSchemaComplianceCheck_5 process_data_begin ] start
	 */

	

	
	
	currentComponent="tSchemaComplianceCheck_5";

	

 



/**
 * [tSchemaComplianceCheck_5 process_data_begin ] stop
 */
// Start of branch "row15"
if(row15 != null) { 



	
	/**
	 * [tMap_8 main ] start
	 */

	

	
	
	currentComponent="tMap_8";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row15"
						
						);
					}
					

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_8 = false;
		

        // ###############################
        // # Input tables (lookups)
		  boolean rejectedInnerJoin_tMap_8 = false;
		  boolean mainRowRejected_tMap_8 = false;
            				    								  
		// ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_8__Struct Var = Var__tMap_8;// ###############################
        // ###############################
        // # Output tables

out7 = null;


// # Output table : 'out7'
out7_tmp.ID_VISITEUR = row15.id ;
out7_tmp.NOM = routines.Clean.nettoie(row15.nom);
out7_tmp.PRENOM = routines.Clean.nettoie(row15.prenom);
out7_tmp.MAIL = routines.Clean.nettoie(row15.email);
out7_tmp.TELEPHONE = routines.Clean.nettoie(row15.telephone);
out7 = out7_tmp;
// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_8 = false;










 


	tos_count_tMap_8++;

/**
 * [tMap_8 main ] stop
 */
	
	/**
	 * [tMap_8 process_data_begin ] start
	 */

	

	
	
	currentComponent="tMap_8";

	

 



/**
 * [tMap_8 process_data_begin ] stop
 */
// Start of branch "out7"
if(out7 != null) { 



	
	/**
	 * [tDBOutput_5 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_5";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"out7"
						
						);
					}
					



        whetherReject_tDBOutput_5 = false;
                    pstmt_tDBOutput_5.setInt(1, out7.ID_VISITEUR);

            int checkCount_tDBOutput_5 = -1;
            try (java.sql.ResultSet rs_tDBOutput_5 = pstmt_tDBOutput_5.executeQuery()) {
                while(rs_tDBOutput_5.next()) {
                    checkCount_tDBOutput_5 = rs_tDBOutput_5.getInt(1);
                }
            }
            if(checkCount_tDBOutput_5 > 0) {
                        if(out7.NOM == null) {
pstmtUpdate_tDBOutput_5.setNull(1, java.sql.Types.VARCHAR);
} else {pstmtUpdate_tDBOutput_5.setString(1, out7.NOM);
}

                        if(out7.PRENOM == null) {
pstmtUpdate_tDBOutput_5.setNull(2, java.sql.Types.VARCHAR);
} else {pstmtUpdate_tDBOutput_5.setString(2, out7.PRENOM);
}

                        if(out7.MAIL == null) {
pstmtUpdate_tDBOutput_5.setNull(3, java.sql.Types.VARCHAR);
} else {pstmtUpdate_tDBOutput_5.setString(3, out7.MAIL);
}

                        if(out7.TELEPHONE == null) {
pstmtUpdate_tDBOutput_5.setNull(4, java.sql.Types.VARCHAR);
} else {pstmtUpdate_tDBOutput_5.setString(4, out7.TELEPHONE);
}

                        pstmtUpdate_tDBOutput_5.setInt(5 + count_tDBOutput_5, out7.ID_VISITEUR);

                try {
                    int processedCount_tDBOutput_5 = pstmtUpdate_tDBOutput_5.executeUpdate();
                    updatedCount_tDBOutput_5 += processedCount_tDBOutput_5;
                    rowsToCommitCount_tDBOutput_5 += processedCount_tDBOutput_5;
                    nb_line_tDBOutput_5++;
                } catch(java.lang.Exception e_tDBOutput_5) {
globalMap.put("tDBOutput_5_ERROR_MESSAGE",e_tDBOutput_5.getMessage());
                    whetherReject_tDBOutput_5 = true;
                        nb_line_tDBOutput_5++;
                            System.err.print(e_tDBOutput_5.getMessage());
                }
            } else {
                        pstmtInsert_tDBOutput_5.setInt(1, out7.ID_VISITEUR);

                        if(out7.NOM == null) {
pstmtInsert_tDBOutput_5.setNull(2, java.sql.Types.VARCHAR);
} else {pstmtInsert_tDBOutput_5.setString(2, out7.NOM);
}

                        if(out7.PRENOM == null) {
pstmtInsert_tDBOutput_5.setNull(3, java.sql.Types.VARCHAR);
} else {pstmtInsert_tDBOutput_5.setString(3, out7.PRENOM);
}

                        if(out7.MAIL == null) {
pstmtInsert_tDBOutput_5.setNull(4, java.sql.Types.VARCHAR);
} else {pstmtInsert_tDBOutput_5.setString(4, out7.MAIL);
}

                        if(out7.TELEPHONE == null) {
pstmtInsert_tDBOutput_5.setNull(5, java.sql.Types.VARCHAR);
} else {pstmtInsert_tDBOutput_5.setString(5, out7.TELEPHONE);
}

                try {
                    int processedCount_tDBOutput_5 = pstmtInsert_tDBOutput_5.executeUpdate();
                    insertedCount_tDBOutput_5 += processedCount_tDBOutput_5;
                    rowsToCommitCount_tDBOutput_5 += processedCount_tDBOutput_5;
                    nb_line_tDBOutput_5++;
                } catch(java.lang.Exception e_tDBOutput_5) {
globalMap.put("tDBOutput_5_ERROR_MESSAGE",e_tDBOutput_5.getMessage());
                    whetherReject_tDBOutput_5 = true;
                        nb_line_tDBOutput_5++;
                            System.err.print(e_tDBOutput_5.getMessage());
                }
            }

 


	tos_count_tDBOutput_5++;

/**
 * [tDBOutput_5 main ] stop
 */
	
	/**
	 * [tDBOutput_5 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_5";

	

 



/**
 * [tDBOutput_5 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_5 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_5";

	

 



/**
 * [tDBOutput_5 process_data_end ] stop
 */

} // End of branch "out7"




	
	/**
	 * [tMap_8 process_data_end ] start
	 */

	

	
	
	currentComponent="tMap_8";

	

 



/**
 * [tMap_8 process_data_end ] stop
 */

} // End of branch "row15"




	
	/**
	 * [tSchemaComplianceCheck_5 process_data_end ] start
	 */

	

	
	
	currentComponent="tSchemaComplianceCheck_5";

	

 



/**
 * [tSchemaComplianceCheck_5 process_data_end ] stop
 */

} // End of branch "row14"




	
	/**
	 * [tUniqRow_5 process_data_end ] start
	 */

	

	
	
	currentComponent="tUniqRow_5";

	

 



/**
 * [tUniqRow_5 process_data_end ] stop
 */

} // End of branch "row13"




	
	/**
	 * [tFileInputDelimited_5 process_data_end ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_5";

	

 



/**
 * [tFileInputDelimited_5 process_data_end ] stop
 */
	
	/**
	 * [tFileInputDelimited_5 end ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_5";

	



            }
            }finally{
                if(!((Object)(context.source_path+"visiteur.csv") instanceof java.io.InputStream)){
                	if(fid_tFileInputDelimited_5!=null){
                		fid_tFileInputDelimited_5.close();
                	}
                }
                if(fid_tFileInputDelimited_5!=null){
                	globalMap.put("tFileInputDelimited_5_NB_LINE", fid_tFileInputDelimited_5.getRowNumber());
					
                }
			}
			  

 

ok_Hash.put("tFileInputDelimited_5", true);
end_Hash.put("tFileInputDelimited_5", System.currentTimeMillis());




/**
 * [tFileInputDelimited_5 end ] stop
 */

	
	/**
	 * [tUniqRow_5 end ] start
	 */

	

	
	
	currentComponent="tUniqRow_5";

	

globalMap.put("tUniqRow_5_NB_UNIQUES",nb_uniques_tUniqRow_5);
globalMap.put("tUniqRow_5_NB_DUPLICATES",nb_duplicates_tUniqRow_5);

				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row13");
			  	}
			  	
 

ok_Hash.put("tUniqRow_5", true);
end_Hash.put("tUniqRow_5", System.currentTimeMillis());




/**
 * [tUniqRow_5 end ] stop
 */

	
	/**
	 * [tSchemaComplianceCheck_5 end ] start
	 */

	

	
	
	currentComponent="tSchemaComplianceCheck_5";

	

				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row14");
			  	}
			  	
 

ok_Hash.put("tSchemaComplianceCheck_5", true);
end_Hash.put("tSchemaComplianceCheck_5", System.currentTimeMillis());




/**
 * [tSchemaComplianceCheck_5 end ] stop
 */

	
	/**
	 * [tMap_8 end ] start
	 */

	

	
	
	currentComponent="tMap_8";

	


// ###############################
// # Lookup hashes releasing
// ###############################      





				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row15");
			  	}
			  	
 

ok_Hash.put("tMap_8", true);
end_Hash.put("tMap_8", System.currentTimeMillis());




/**
 * [tMap_8 end ] stop
 */

	
	/**
	 * [tDBOutput_5 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_5";

	
	



	
        if(pstmtUpdate_tDBOutput_5 != null){
            pstmtUpdate_tDBOutput_5.close();
            resourceMap.remove("pstmtUpdate_tDBOutput_5");
        }
        if(pstmtInsert_tDBOutput_5 != null){
            pstmtInsert_tDBOutput_5.close();
            resourceMap.remove("pstmtInsert_tDBOutput_5");
        }
        if(pstmt_tDBOutput_5 != null) {
            pstmt_tDBOutput_5.close();
            resourceMap.remove("pstmt_tDBOutput_5");
        }
    resourceMap.put("statementClosed_tDBOutput_5", true);

	
	nb_line_deleted_tDBOutput_5=nb_line_deleted_tDBOutput_5+ deletedCount_tDBOutput_5;
	nb_line_update_tDBOutput_5=nb_line_update_tDBOutput_5 + updatedCount_tDBOutput_5;
	nb_line_inserted_tDBOutput_5=nb_line_inserted_tDBOutput_5 + insertedCount_tDBOutput_5;
	nb_line_rejected_tDBOutput_5=nb_line_rejected_tDBOutput_5 + rejectedCount_tDBOutput_5;
	
        globalMap.put("tDBOutput_5_NB_LINE",nb_line_tDBOutput_5);
        globalMap.put("tDBOutput_5_NB_LINE_UPDATED",nb_line_update_tDBOutput_5);
        globalMap.put("tDBOutput_5_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_5);
        globalMap.put("tDBOutput_5_NB_LINE_DELETED",nb_line_deleted_tDBOutput_5);
        globalMap.put("tDBOutput_5_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_5);
    

	



				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"out7");
			  	}
			  	
 

ok_Hash.put("tDBOutput_5", true);
end_Hash.put("tDBOutput_5", System.currentTimeMillis());




/**
 * [tDBOutput_5 end ] stop
 */












				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tFileInputDelimited_5:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk7", 0, "ok");
								} 
							
							tFileInputDelimited_6Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFileInputDelimited_5 finally ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_5";

	

 



/**
 * [tFileInputDelimited_5 finally ] stop
 */

	
	/**
	 * [tUniqRow_5 finally ] start
	 */

	

	
	
	currentComponent="tUniqRow_5";

	

 



/**
 * [tUniqRow_5 finally ] stop
 */

	
	/**
	 * [tSchemaComplianceCheck_5 finally ] start
	 */

	

	
	
	currentComponent="tSchemaComplianceCheck_5";

	

 



/**
 * [tSchemaComplianceCheck_5 finally ] stop
 */

	
	/**
	 * [tMap_8 finally ] start
	 */

	

	
	
	currentComponent="tMap_8";

	

 



/**
 * [tMap_8 finally ] stop
 */

	
	/**
	 * [tDBOutput_5 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_5";

	



    if (resourceMap.get("statementClosed_tDBOutput_5") == null) {
                java.sql.PreparedStatement pstmtUpdateToClose_tDBOutput_5 = null;
                if ((pstmtUpdateToClose_tDBOutput_5 = (java.sql.PreparedStatement) resourceMap.remove("pstmtUpdate_tDBOutput_5")) != null) {
                    pstmtUpdateToClose_tDBOutput_5.close();
                }
                java.sql.PreparedStatement pstmtInsertToClose_tDBOutput_5 = null;
                if ((pstmtInsertToClose_tDBOutput_5 = (java.sql.PreparedStatement) resourceMap.remove("pstmtInsert_tDBOutput_5")) != null) {
                    pstmtInsertToClose_tDBOutput_5.close();
                }
                java.sql.PreparedStatement pstmtToClose_tDBOutput_5 = null;
                if ((pstmtToClose_tDBOutput_5 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_5")) != null) {
                    pstmtToClose_tDBOutput_5.close();
                }
    }
 



/**
 * [tDBOutput_5 finally ] stop
 */












				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFileInputDelimited_5_SUBPROCESS_STATE", 1);
	}
	


public static class out8Struct implements routines.system.IPersistableRow<out8Struct> {
    final static byte[] commonByteArrayLock_LOCAL_PROJECT_STG_Load = new byte[0];
    static byte[] commonByteArray_LOCAL_PROJECT_STG_Load = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int ID;

				public int getID () {
					return this.ID;
				}
				
			    public int SK_CANAL_ID;

				public int getSK_CANAL_ID () {
					return this.SK_CANAL_ID;
				}
				
			    public int SK_VISITEUR_ID;

				public int getSK_VISITEUR_ID () {
					return this.SK_VISITEUR_ID;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.ID;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final out8Struct other = (out8Struct) obj;
		
						if (this.ID != other.ID)
							return false;
					

		return true;
    }

	public void copyDataTo(out8Struct other) {

		other.ID = this.ID;
	            other.SK_CANAL_ID = this.SK_CANAL_ID;
	            other.SK_VISITEUR_ID = this.SK_VISITEUR_ID;
	            
	}

	public void copyKeysDataTo(out8Struct other) {

		other.ID = this.ID;
	            	
	}




    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
			        this.ID = dis.readInt();
					
			        this.SK_CANAL_ID = dis.readInt();
					
			        this.SK_VISITEUR_ID = dis.readInt();
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
			        this.ID = dis.readInt();
					
			        this.SK_CANAL_ID = dis.readInt();
					
			        this.SK_VISITEUR_ID = dis.readInt();
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.ID);
					
					// int
				
		            	dos.writeInt(this.SK_CANAL_ID);
					
					// int
				
		            	dos.writeInt(this.SK_VISITEUR_ID);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.ID);
					
					// int
				
		            	dos.writeInt(this.SK_CANAL_ID);
					
					// int
				
		            	dos.writeInt(this.SK_VISITEUR_ID);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("ID="+String.valueOf(ID));
		sb.append(",SK_CANAL_ID="+String.valueOf(SK_CANAL_ID));
		sb.append(",SK_VISITEUR_ID="+String.valueOf(SK_VISITEUR_ID));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(out8Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.ID, other.ID);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row18Struct implements routines.system.IPersistableRow<row18Struct> {
    final static byte[] commonByteArrayLock_LOCAL_PROJECT_STG_Load = new byte[0];
    static byte[] commonByteArray_LOCAL_PROJECT_STG_Load = new byte[0];

	
			    public Integer idCanalVisiteur;

				public Integer getIdCanalVisiteur () {
					return this.idCanalVisiteur;
				}
				
			    public Integer idCanal;

				public Integer getIdCanal () {
					return this.idCanal;
				}
				
			    public Integer idVisiteurs;

				public Integer getIdVisiteurs () {
					return this.idVisiteurs;
				}
				


	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
						this.idCanalVisiteur = readInteger(dis);
					
						this.idCanal = readInteger(dis);
					
						this.idVisiteurs = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
						this.idCanalVisiteur = readInteger(dis);
					
						this.idCanal = readInteger(dis);
					
						this.idVisiteurs = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.idCanalVisiteur,dos);
					
					// Integer
				
						writeInteger(this.idCanal,dos);
					
					// Integer
				
						writeInteger(this.idVisiteurs,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// Integer
				
						writeInteger(this.idCanalVisiteur,dos);
					
					// Integer
				
						writeInteger(this.idCanal,dos);
					
					// Integer
				
						writeInteger(this.idVisiteurs,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("idCanalVisiteur="+String.valueOf(idCanalVisiteur));
		sb.append(",idCanal="+String.valueOf(idCanal));
		sb.append(",idVisiteurs="+String.valueOf(idVisiteurs));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row18Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row17Struct implements routines.system.IPersistableRow<row17Struct> {
    final static byte[] commonByteArrayLock_LOCAL_PROJECT_STG_Load = new byte[0];
    static byte[] commonByteArray_LOCAL_PROJECT_STG_Load = new byte[0];

	
			    public Integer idCanalVisiteur;

				public Integer getIdCanalVisiteur () {
					return this.idCanalVisiteur;
				}
				
			    public Integer idCanal;

				public Integer getIdCanal () {
					return this.idCanal;
				}
				
			    public Integer idVisiteurs;

				public Integer getIdVisiteurs () {
					return this.idVisiteurs;
				}
				


	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
						this.idCanalVisiteur = readInteger(dis);
					
						this.idCanal = readInteger(dis);
					
						this.idVisiteurs = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
						this.idCanalVisiteur = readInteger(dis);
					
						this.idCanal = readInteger(dis);
					
						this.idVisiteurs = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.idCanalVisiteur,dos);
					
					// Integer
				
						writeInteger(this.idCanal,dos);
					
					// Integer
				
						writeInteger(this.idVisiteurs,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// Integer
				
						writeInteger(this.idCanalVisiteur,dos);
					
					// Integer
				
						writeInteger(this.idCanal,dos);
					
					// Integer
				
						writeInteger(this.idVisiteurs,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("idCanalVisiteur="+String.valueOf(idCanalVisiteur));
		sb.append(",idCanal="+String.valueOf(idCanal));
		sb.append(",idVisiteurs="+String.valueOf(idVisiteurs));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row17Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row16Struct implements routines.system.IPersistableRow<row16Struct> {
    final static byte[] commonByteArrayLock_LOCAL_PROJECT_STG_Load = new byte[0];
    static byte[] commonByteArray_LOCAL_PROJECT_STG_Load = new byte[0];

	
			    public Integer idCanalVisiteur;

				public Integer getIdCanalVisiteur () {
					return this.idCanalVisiteur;
				}
				
			    public Integer idCanal;

				public Integer getIdCanal () {
					return this.idCanal;
				}
				
			    public Integer idVisiteurs;

				public Integer getIdVisiteurs () {
					return this.idVisiteurs;
				}
				


	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
						this.idCanalVisiteur = readInteger(dis);
					
						this.idCanal = readInteger(dis);
					
						this.idVisiteurs = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
						this.idCanalVisiteur = readInteger(dis);
					
						this.idCanal = readInteger(dis);
					
						this.idVisiteurs = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.idCanalVisiteur,dos);
					
					// Integer
				
						writeInteger(this.idCanal,dos);
					
					// Integer
				
						writeInteger(this.idVisiteurs,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// Integer
				
						writeInteger(this.idCanalVisiteur,dos);
					
					// Integer
				
						writeInteger(this.idCanal,dos);
					
					// Integer
				
						writeInteger(this.idVisiteurs,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("idCanalVisiteur="+String.valueOf(idCanalVisiteur));
		sb.append(",idCanal="+String.valueOf(idCanal));
		sb.append(",idVisiteurs="+String.valueOf(idVisiteurs));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row16Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tFileInputDelimited_6Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFileInputDelimited_6_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row16Struct row16 = new row16Struct();
row17Struct row17 = new row17Struct();
row18Struct row18 = new row18Struct();
out8Struct out8 = new out8Struct();







	
	/**
	 * [tDBOutput_6 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_6", false);
		start_Hash.put("tDBOutput_6", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_6";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"out8");
					}
				
		int tos_count_tDBOutput_6 = 0;
		






        int updateKeyCount_tDBOutput_6 = 1;
        if(updateKeyCount_tDBOutput_6 < 1) {
            throw new RuntimeException("For update, Schema must have a key");
        } else if (updateKeyCount_tDBOutput_6 == 3 && true) {
                    System.err.println("For update, every Schema column can not be a key");
        }
    
    int nb_line_tDBOutput_6 = 0;
    int nb_line_update_tDBOutput_6 = 0;
    int nb_line_inserted_tDBOutput_6 = 0;
    int nb_line_deleted_tDBOutput_6 = 0;
    int nb_line_rejected_tDBOutput_6 = 0;

    int tmp_batchUpdateCount_tDBOutput_6 = 0;

    int deletedCount_tDBOutput_6=0;
    int updatedCount_tDBOutput_6=0;
    int insertedCount_tDBOutput_6=0;
    int rowsToCommitCount_tDBOutput_6=0;
    int rejectedCount_tDBOutput_6=0;

    boolean whetherReject_tDBOutput_6 = false;

    java.sql.Connection conn_tDBOutput_6 = null;

    //optional table
    String dbschema_tDBOutput_6 = null;
    String tableName_tDBOutput_6 = null;
        dbschema_tDBOutput_6 = (String)globalMap.get("dbschema_tDBConnection_2");
		
        conn_tDBOutput_6 = (java.sql.Connection)globalMap.get("conn_tDBConnection_2");
        int count_tDBOutput_6=0;

        if(dbschema_tDBOutput_6 == null || dbschema_tDBOutput_6.trim().length() == 0) {
            tableName_tDBOutput_6 = ("STG_FAIT_CANALVISI");
        } else {
            tableName_tDBOutput_6 = dbschema_tDBOutput_6 + "." + ("STG_FAIT_CANALVISI");
        }
            try (java.sql.Statement stmtClear_tDBOutput_6 = conn_tDBOutput_6.createStatement()) {
                stmtClear_tDBOutput_6.executeUpdate("DELETE FROM " + tableName_tDBOutput_6 + "");
            }
                java.sql.PreparedStatement pstmt_tDBOutput_6 = conn_tDBOutput_6.prepareStatement("SELECT COUNT(1) FROM " + tableName_tDBOutput_6 + " WHERE ID = ?");
                resourceMap.put("pstmt_tDBOutput_6", pstmt_tDBOutput_6);
                String insert_tDBOutput_6 = "INSERT INTO " + tableName_tDBOutput_6 + " (ID,SK_CANAL_ID,SK_VISITEUR_ID) VALUES (?,?,?)";    
                java.sql.PreparedStatement pstmtInsert_tDBOutput_6 = conn_tDBOutput_6.prepareStatement(insert_tDBOutput_6);
                resourceMap.put("pstmtInsert_tDBOutput_6", pstmtInsert_tDBOutput_6);
                String update_tDBOutput_6 = "UPDATE " + tableName_tDBOutput_6 + " SET SK_CANAL_ID = ?,SK_VISITEUR_ID = ? WHERE ID = ?";
                java.sql.PreparedStatement pstmtUpdate_tDBOutput_6 = conn_tDBOutput_6.prepareStatement(update_tDBOutput_6);
                resourceMap.put("pstmtUpdate_tDBOutput_6", pstmtUpdate_tDBOutput_6);





 



/**
 * [tDBOutput_6 begin ] stop
 */



	
	/**
	 * [tMap_9 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_9", false);
		start_Hash.put("tMap_9", System.currentTimeMillis());
		
	
	currentComponent="tMap_9";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row18");
					}
				
		int tos_count_tMap_9 = 0;
		




// ###############################
// # Lookup's keys initialization
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_9__Struct  {
}
Var__tMap_9__Struct Var__tMap_9 = new Var__tMap_9__Struct();
// ###############################

// ###############################
// # Outputs initialization
out8Struct out8_tmp = new out8Struct();
// ###############################

        
        



        









 



/**
 * [tMap_9 begin ] stop
 */



	
	/**
	 * [tSchemaComplianceCheck_6 begin ] start
	 */

	

	
		
		ok_Hash.put("tSchemaComplianceCheck_6", false);
		start_Hash.put("tSchemaComplianceCheck_6", System.currentTimeMillis());
		
	
	currentComponent="tSchemaComplianceCheck_6";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row17");
					}
				
		int tos_count_tSchemaComplianceCheck_6 = 0;
		

    class RowSetValueUtil_tSchemaComplianceCheck_6 {

        boolean ifPassedThrough = true;
        int errorCodeThrough = 0;
        String errorMessageThrough = "";
        int resultErrorCodeThrough = 0;
        String resultErrorMessageThrough = "";
        String tmpContentThrough = null;

        boolean ifPassed = true;
        int errorCode = 0;
        String errorMessage = "";

        void handleBigdecimalPrecision(String data, int iPrecision, int maxLength){
            //number of digits before the decimal point(ignoring frontend zeroes)
            int len1 = 0;
            int len2 = 0;
            ifPassed = true;
            errorCode = 0;
            errorMessage = "";
            if(data.startsWith("-")){
                data = data.substring(1);
            }
            data = org.apache.commons.lang.StringUtils.stripStart(data, "0");

            if(data.indexOf(".") >= 0){
                len1 = data.indexOf(".");
                data = org.apache.commons.lang.StringUtils.stripEnd(data, "0");
                len2 = data.length() - (len1 + 1);
            }else{
                len1 = data.length();
            }

            if (iPrecision < len2) {
                ifPassed = false;
                errorCode += 8;
                errorMessage += "|precision Non-matches";
            } else if (maxLength < len1 + iPrecision) {
                ifPassed = false;
                errorCode += 8;
                errorMessage += "|invalid Length setting is unsuitable for Precision";
            }
        }

        int handleErrorCode(int errorCode, int resultErrorCode){
            if (errorCode > 0) {
                if (resultErrorCode > 0) {
                    resultErrorCode = 16;
                } else {
                    resultErrorCode = errorCode;
                }
            }
            return resultErrorCode;
        }

        String handleErrorMessage(String errorMessage, String resultErrorMessage, String columnLabel){
            if (errorMessage.length() > 0) {
                if (resultErrorMessage.length() > 0) {
                    resultErrorMessage += ";"+ errorMessage.replaceFirst("\\|", columnLabel);
                } else {
                    resultErrorMessage = errorMessage.replaceFirst("\\|", columnLabel);
                }
            }
            return resultErrorMessage;
        }

        void reset(){
            ifPassedThrough = true;
            errorCodeThrough = 0;
            errorMessageThrough = "";
            resultErrorCodeThrough = 0;
            resultErrorMessageThrough = "";
            tmpContentThrough = null;

            ifPassed = true;
            errorCode = 0;
            errorMessage = "";
        }

        void setRowValue_0(row17Struct row17) {
    // validate nullable (empty as null)
    if ((row17.idCanalVisiteur == null) || ("".equals(row17.idCanalVisiteur))) {
        ifPassedThrough = false;
        errorCodeThrough += 4;
        errorMessageThrough += "|empty or null";
    }
            resultErrorCodeThrough = handleErrorCode(errorCodeThrough,resultErrorCodeThrough);
            errorCodeThrough = 0;
            resultErrorMessageThrough = handleErrorMessage(errorMessageThrough,resultErrorMessageThrough,"idCanalVisiteur:");
            errorMessageThrough = "";
    // validate nullable (empty as null)
    if ((row17.idCanal == null) || ("".equals(row17.idCanal))) {
        ifPassedThrough = false;
        errorCodeThrough += 4;
        errorMessageThrough += "|empty or null";
    }
            resultErrorCodeThrough = handleErrorCode(errorCodeThrough,resultErrorCodeThrough);
            errorCodeThrough = 0;
            resultErrorMessageThrough = handleErrorMessage(errorMessageThrough,resultErrorMessageThrough,"idCanal:");
            errorMessageThrough = "";
    // validate nullable (empty as null)
    if ((row17.idVisiteurs == null) || ("".equals(row17.idVisiteurs))) {
        ifPassedThrough = false;
        errorCodeThrough += 4;
        errorMessageThrough += "|empty or null";
    }
            resultErrorCodeThrough = handleErrorCode(errorCodeThrough,resultErrorCodeThrough);
            errorCodeThrough = 0;
            resultErrorMessageThrough = handleErrorMessage(errorMessageThrough,resultErrorMessageThrough,"idVisiteurs:");
            errorMessageThrough = "";
        }
    }
    RowSetValueUtil_tSchemaComplianceCheck_6 rsvUtil_tSchemaComplianceCheck_6 = new RowSetValueUtil_tSchemaComplianceCheck_6();

 



/**
 * [tSchemaComplianceCheck_6 begin ] stop
 */



	
	/**
	 * [tUniqRow_6 begin ] start
	 */

	

	
		
		ok_Hash.put("tUniqRow_6", false);
		start_Hash.put("tUniqRow_6", System.currentTimeMillis());
		
	
	currentComponent="tUniqRow_6";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row16");
					}
				
		int tos_count_tUniqRow_6 = 0;
		

	
		class KeyStruct_tUniqRow_6 {
	
			private static final int DEFAULT_HASHCODE = 1;
		    private static final int PRIME = 31;
		    private int hashCode = DEFAULT_HASHCODE;
		    public boolean hashCodeDirty = true;
	
	        
					Integer idCanalVisiteur;        
	        
		    @Override
			public int hashCode() {
				if (this.hashCodeDirty) {
					final int prime = PRIME;
					int result = DEFAULT_HASHCODE;
			
								result = prime * result + ((this.idCanalVisiteur == null) ? 0 : this.idCanalVisiteur.hashCode());
								
		    		this.hashCode = result;
		    		this.hashCodeDirty = false;		
				}
				return this.hashCode;
			}
			
			@Override
			public boolean equals(Object obj) {
				if (this == obj) return true;
				if (obj == null) return false;
				if (getClass() != obj.getClass()) return false;
				final KeyStruct_tUniqRow_6 other = (KeyStruct_tUniqRow_6) obj;
				
									if (this.idCanalVisiteur == null) {
										if (other.idCanalVisiteur != null) 
											return false;
								
									} else if (!this.idCanalVisiteur.equals(other.idCanalVisiteur))
								 
										return false;
								
				
				return true;
			}
	  
	        
		}

	
int nb_uniques_tUniqRow_6 = 0;
int nb_duplicates_tUniqRow_6 = 0;
KeyStruct_tUniqRow_6 finder_tUniqRow_6 = new KeyStruct_tUniqRow_6();
java.util.Set<KeyStruct_tUniqRow_6> keystUniqRow_6 = new java.util.HashSet<KeyStruct_tUniqRow_6>(); 

 



/**
 * [tUniqRow_6 begin ] stop
 */



	
	/**
	 * [tFileInputDelimited_6 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileInputDelimited_6", false);
		start_Hash.put("tFileInputDelimited_6", System.currentTimeMillis());
		
	
	currentComponent="tFileInputDelimited_6";

	
		int tos_count_tFileInputDelimited_6 = 0;
		
	
	
	
 
	
	
	final routines.system.RowState rowstate_tFileInputDelimited_6 = new routines.system.RowState();
	
	
				int nb_line_tFileInputDelimited_6 = 0;
				org.talend.fileprocess.FileInputDelimited fid_tFileInputDelimited_6 = null;
				int limit_tFileInputDelimited_6 = -1;
				try{
					
						Object filename_tFileInputDelimited_6 = context.source_path+"canalVisiteur.csv";
						if(filename_tFileInputDelimited_6 instanceof java.io.InputStream){
							
			int footer_value_tFileInputDelimited_6 = 0, random_value_tFileInputDelimited_6 = -1;
			if(footer_value_tFileInputDelimited_6 >0 || random_value_tFileInputDelimited_6 > 0){
				throw new java.lang.Exception("When the input source is a stream,footer and random shouldn't be bigger than 0.");				
			}
		
						}
						try {
							fid_tFileInputDelimited_6 = new org.talend.fileprocess.FileInputDelimited(context.source_path+"canalVisiteur.csv", "UTF-8",",","\n",false,1,0,
									limit_tFileInputDelimited_6
								,-1, false);
						} catch(java.lang.Exception e) {
globalMap.put("tFileInputDelimited_6_ERROR_MESSAGE",e.getMessage());
							
								
								System.err.println(e.getMessage());
							
						}
					
				    
					while (fid_tFileInputDelimited_6!=null && fid_tFileInputDelimited_6.nextRecord()) {
						rowstate_tFileInputDelimited_6.reset();
						
			    						row16 = null;			
												
									boolean whetherReject_tFileInputDelimited_6 = false;
									row16 = new row16Struct();
									try {
										
				int columnIndexWithD_tFileInputDelimited_6 = 0;
				
					String temp = ""; 
				
					columnIndexWithD_tFileInputDelimited_6 = 0;
					
						temp = fid_tFileInputDelimited_6.get(columnIndexWithD_tFileInputDelimited_6);
						if(temp.length() > 0) {
							
								try {
								
    								row16.idCanalVisiteur = ParserUtils.parseTo_Integer(temp);
    							
    							} catch(java.lang.Exception ex_tFileInputDelimited_6) {
globalMap.put("tFileInputDelimited_6_ERROR_MESSAGE",ex_tFileInputDelimited_6.getMessage());
									rowstate_tFileInputDelimited_6.setException(new RuntimeException(String.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
										"idCanalVisiteur", "row16", temp, ex_tFileInputDelimited_6), ex_tFileInputDelimited_6));
								}
    							
						} else {						
							
								
									row16.idCanalVisiteur = null;
								
							
						}
					
				
					columnIndexWithD_tFileInputDelimited_6 = 1;
					
						temp = fid_tFileInputDelimited_6.get(columnIndexWithD_tFileInputDelimited_6);
						if(temp.length() > 0) {
							
								try {
								
    								row16.idCanal = ParserUtils.parseTo_Integer(temp);
    							
    							} catch(java.lang.Exception ex_tFileInputDelimited_6) {
globalMap.put("tFileInputDelimited_6_ERROR_MESSAGE",ex_tFileInputDelimited_6.getMessage());
									rowstate_tFileInputDelimited_6.setException(new RuntimeException(String.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
										"idCanal", "row16", temp, ex_tFileInputDelimited_6), ex_tFileInputDelimited_6));
								}
    							
						} else {						
							
								
									row16.idCanal = null;
								
							
						}
					
				
					columnIndexWithD_tFileInputDelimited_6 = 2;
					
						temp = fid_tFileInputDelimited_6.get(columnIndexWithD_tFileInputDelimited_6);
						if(temp.length() > 0) {
							
								try {
								
    								row16.idVisiteurs = ParserUtils.parseTo_Integer(temp);
    							
    							} catch(java.lang.Exception ex_tFileInputDelimited_6) {
globalMap.put("tFileInputDelimited_6_ERROR_MESSAGE",ex_tFileInputDelimited_6.getMessage());
									rowstate_tFileInputDelimited_6.setException(new RuntimeException(String.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
										"idVisiteurs", "row16", temp, ex_tFileInputDelimited_6), ex_tFileInputDelimited_6));
								}
    							
						} else {						
							
								
									row16.idVisiteurs = null;
								
							
						}
					
				
				
										
										if(rowstate_tFileInputDelimited_6.getException()!=null) {
											throw rowstate_tFileInputDelimited_6.getException();
										}
										
										
							
			    					} catch (java.lang.Exception e) {
globalMap.put("tFileInputDelimited_6_ERROR_MESSAGE",e.getMessage());
			        					whetherReject_tFileInputDelimited_6 = true;
			        					
			                					System.err.println(e.getMessage());
			                					row16 = null;
			                				
										
			    					}
								

 



/**
 * [tFileInputDelimited_6 begin ] stop
 */
	
	/**
	 * [tFileInputDelimited_6 main ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_6";

	

 


	tos_count_tFileInputDelimited_6++;

/**
 * [tFileInputDelimited_6 main ] stop
 */
	
	/**
	 * [tFileInputDelimited_6 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_6";

	

 



/**
 * [tFileInputDelimited_6 process_data_begin ] stop
 */
// Start of branch "row16"
if(row16 != null) { 



	
	/**
	 * [tUniqRow_6 main ] start
	 */

	

	
	
	currentComponent="tUniqRow_6";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row16"
						
						);
					}
					
row17 = null;			
finder_tUniqRow_6.idCanalVisiteur = row16.idCanalVisiteur;	
finder_tUniqRow_6.hashCodeDirty = true;
if (!keystUniqRow_6.contains(finder_tUniqRow_6)) {
		KeyStruct_tUniqRow_6 new_tUniqRow_6 = new KeyStruct_tUniqRow_6();

		
new_tUniqRow_6.idCanalVisiteur = row16.idCanalVisiteur;
		
		keystUniqRow_6.add(new_tUniqRow_6);if(row17 == null){ 
	
	row17 = new row17Struct();
}row17.idCanalVisiteur = row16.idCanalVisiteur;			row17.idCanal = row16.idCanal;			row17.idVisiteurs = row16.idVisiteurs;					
		nb_uniques_tUniqRow_6++;
	} else {
	  nb_duplicates_tUniqRow_6++;
	}

 


	tos_count_tUniqRow_6++;

/**
 * [tUniqRow_6 main ] stop
 */
	
	/**
	 * [tUniqRow_6 process_data_begin ] start
	 */

	

	
	
	currentComponent="tUniqRow_6";

	

 



/**
 * [tUniqRow_6 process_data_begin ] stop
 */
// Start of branch "row17"
if(row17 != null) { 



	
	/**
	 * [tSchemaComplianceCheck_6 main ] start
	 */

	

	
	
	currentComponent="tSchemaComplianceCheck_6";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row17"
						
						);
					}
					
	row18 = null;
	rsvUtil_tSchemaComplianceCheck_6.setRowValue_0(row17);
	if (rsvUtil_tSchemaComplianceCheck_6.ifPassedThrough) {
		row18 = new row18Struct();
		row18.idCanalVisiteur = row17.idCanalVisiteur;
		row18.idCanal = row17.idCanal;
		row18.idVisiteurs = row17.idVisiteurs;
	}
	rsvUtil_tSchemaComplianceCheck_6.reset();

 


	tos_count_tSchemaComplianceCheck_6++;

/**
 * [tSchemaComplianceCheck_6 main ] stop
 */
	
	/**
	 * [tSchemaComplianceCheck_6 process_data_begin ] start
	 */

	

	
	
	currentComponent="tSchemaComplianceCheck_6";

	

 



/**
 * [tSchemaComplianceCheck_6 process_data_begin ] stop
 */
// Start of branch "row18"
if(row18 != null) { 



	
	/**
	 * [tMap_9 main ] start
	 */

	

	
	
	currentComponent="tMap_9";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row18"
						
						);
					}
					

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_9 = false;
		

        // ###############################
        // # Input tables (lookups)
		  boolean rejectedInnerJoin_tMap_9 = false;
		  boolean mainRowRejected_tMap_9 = false;
            				    								  
		// ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_9__Struct Var = Var__tMap_9;// ###############################
        // ###############################
        // # Output tables

out8 = null;


// # Output table : 'out8'
out8_tmp.ID = row18.idCanalVisiteur;
out8_tmp.SK_CANAL_ID = row18.idCanal;
out8_tmp.SK_VISITEUR_ID = row18.idVisiteurs;
out8 = out8_tmp;
// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_9 = false;










 


	tos_count_tMap_9++;

/**
 * [tMap_9 main ] stop
 */
	
	/**
	 * [tMap_9 process_data_begin ] start
	 */

	

	
	
	currentComponent="tMap_9";

	

 



/**
 * [tMap_9 process_data_begin ] stop
 */
// Start of branch "out8"
if(out8 != null) { 



	
	/**
	 * [tDBOutput_6 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_6";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"out8"
						
						);
					}
					



        whetherReject_tDBOutput_6 = false;
                    pstmt_tDBOutput_6.setInt(1, out8.ID);

            int checkCount_tDBOutput_6 = -1;
            try (java.sql.ResultSet rs_tDBOutput_6 = pstmt_tDBOutput_6.executeQuery()) {
                while(rs_tDBOutput_6.next()) {
                    checkCount_tDBOutput_6 = rs_tDBOutput_6.getInt(1);
                }
            }
            if(checkCount_tDBOutput_6 > 0) {
                        pstmtUpdate_tDBOutput_6.setInt(1, out8.SK_CANAL_ID);

                        pstmtUpdate_tDBOutput_6.setInt(2, out8.SK_VISITEUR_ID);

                        pstmtUpdate_tDBOutput_6.setInt(3 + count_tDBOutput_6, out8.ID);

                try {
                    int processedCount_tDBOutput_6 = pstmtUpdate_tDBOutput_6.executeUpdate();
                    updatedCount_tDBOutput_6 += processedCount_tDBOutput_6;
                    rowsToCommitCount_tDBOutput_6 += processedCount_tDBOutput_6;
                    nb_line_tDBOutput_6++;
                } catch(java.lang.Exception e_tDBOutput_6) {
globalMap.put("tDBOutput_6_ERROR_MESSAGE",e_tDBOutput_6.getMessage());
                    whetherReject_tDBOutput_6 = true;
                        nb_line_tDBOutput_6++;
                            System.err.print(e_tDBOutput_6.getMessage());
                }
            } else {
                        pstmtInsert_tDBOutput_6.setInt(1, out8.ID);

                        pstmtInsert_tDBOutput_6.setInt(2, out8.SK_CANAL_ID);

                        pstmtInsert_tDBOutput_6.setInt(3, out8.SK_VISITEUR_ID);

                try {
                    int processedCount_tDBOutput_6 = pstmtInsert_tDBOutput_6.executeUpdate();
                    insertedCount_tDBOutput_6 += processedCount_tDBOutput_6;
                    rowsToCommitCount_tDBOutput_6 += processedCount_tDBOutput_6;
                    nb_line_tDBOutput_6++;
                } catch(java.lang.Exception e_tDBOutput_6) {
globalMap.put("tDBOutput_6_ERROR_MESSAGE",e_tDBOutput_6.getMessage());
                    whetherReject_tDBOutput_6 = true;
                        nb_line_tDBOutput_6++;
                            System.err.print(e_tDBOutput_6.getMessage());
                }
            }

 


	tos_count_tDBOutput_6++;

/**
 * [tDBOutput_6 main ] stop
 */
	
	/**
	 * [tDBOutput_6 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_6";

	

 



/**
 * [tDBOutput_6 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_6 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_6";

	

 



/**
 * [tDBOutput_6 process_data_end ] stop
 */

} // End of branch "out8"




	
	/**
	 * [tMap_9 process_data_end ] start
	 */

	

	
	
	currentComponent="tMap_9";

	

 



/**
 * [tMap_9 process_data_end ] stop
 */

} // End of branch "row18"




	
	/**
	 * [tSchemaComplianceCheck_6 process_data_end ] start
	 */

	

	
	
	currentComponent="tSchemaComplianceCheck_6";

	

 



/**
 * [tSchemaComplianceCheck_6 process_data_end ] stop
 */

} // End of branch "row17"




	
	/**
	 * [tUniqRow_6 process_data_end ] start
	 */

	

	
	
	currentComponent="tUniqRow_6";

	

 



/**
 * [tUniqRow_6 process_data_end ] stop
 */

} // End of branch "row16"




	
	/**
	 * [tFileInputDelimited_6 process_data_end ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_6";

	

 



/**
 * [tFileInputDelimited_6 process_data_end ] stop
 */
	
	/**
	 * [tFileInputDelimited_6 end ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_6";

	



            }
            }finally{
                if(!((Object)(context.source_path+"canalVisiteur.csv") instanceof java.io.InputStream)){
                	if(fid_tFileInputDelimited_6!=null){
                		fid_tFileInputDelimited_6.close();
                	}
                }
                if(fid_tFileInputDelimited_6!=null){
                	globalMap.put("tFileInputDelimited_6_NB_LINE", fid_tFileInputDelimited_6.getRowNumber());
					
                }
			}
			  

 

ok_Hash.put("tFileInputDelimited_6", true);
end_Hash.put("tFileInputDelimited_6", System.currentTimeMillis());




/**
 * [tFileInputDelimited_6 end ] stop
 */

	
	/**
	 * [tUniqRow_6 end ] start
	 */

	

	
	
	currentComponent="tUniqRow_6";

	

globalMap.put("tUniqRow_6_NB_UNIQUES",nb_uniques_tUniqRow_6);
globalMap.put("tUniqRow_6_NB_DUPLICATES",nb_duplicates_tUniqRow_6);

				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row16");
			  	}
			  	
 

ok_Hash.put("tUniqRow_6", true);
end_Hash.put("tUniqRow_6", System.currentTimeMillis());




/**
 * [tUniqRow_6 end ] stop
 */

	
	/**
	 * [tSchemaComplianceCheck_6 end ] start
	 */

	

	
	
	currentComponent="tSchemaComplianceCheck_6";

	

				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row17");
			  	}
			  	
 

ok_Hash.put("tSchemaComplianceCheck_6", true);
end_Hash.put("tSchemaComplianceCheck_6", System.currentTimeMillis());




/**
 * [tSchemaComplianceCheck_6 end ] stop
 */

	
	/**
	 * [tMap_9 end ] start
	 */

	

	
	
	currentComponent="tMap_9";

	


// ###############################
// # Lookup hashes releasing
// ###############################      





				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row18");
			  	}
			  	
 

ok_Hash.put("tMap_9", true);
end_Hash.put("tMap_9", System.currentTimeMillis());




/**
 * [tMap_9 end ] stop
 */

	
	/**
	 * [tDBOutput_6 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_6";

	
	



	
        if(pstmtUpdate_tDBOutput_6 != null){
            pstmtUpdate_tDBOutput_6.close();
            resourceMap.remove("pstmtUpdate_tDBOutput_6");
        }
        if(pstmtInsert_tDBOutput_6 != null){
            pstmtInsert_tDBOutput_6.close();
            resourceMap.remove("pstmtInsert_tDBOutput_6");
        }
        if(pstmt_tDBOutput_6 != null) {
            pstmt_tDBOutput_6.close();
            resourceMap.remove("pstmt_tDBOutput_6");
        }
    resourceMap.put("statementClosed_tDBOutput_6", true);

	
	nb_line_deleted_tDBOutput_6=nb_line_deleted_tDBOutput_6+ deletedCount_tDBOutput_6;
	nb_line_update_tDBOutput_6=nb_line_update_tDBOutput_6 + updatedCount_tDBOutput_6;
	nb_line_inserted_tDBOutput_6=nb_line_inserted_tDBOutput_6 + insertedCount_tDBOutput_6;
	nb_line_rejected_tDBOutput_6=nb_line_rejected_tDBOutput_6 + rejectedCount_tDBOutput_6;
	
        globalMap.put("tDBOutput_6_NB_LINE",nb_line_tDBOutput_6);
        globalMap.put("tDBOutput_6_NB_LINE_UPDATED",nb_line_update_tDBOutput_6);
        globalMap.put("tDBOutput_6_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_6);
        globalMap.put("tDBOutput_6_NB_LINE_DELETED",nb_line_deleted_tDBOutput_6);
        globalMap.put("tDBOutput_6_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_6);
    

	



				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"out8");
			  	}
			  	
 

ok_Hash.put("tDBOutput_6", true);
end_Hash.put("tDBOutput_6", System.currentTimeMillis());




/**
 * [tDBOutput_6 end ] stop
 */












				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tFileInputDelimited_6:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk8", 0, "ok");
								} 
							
							tFileInputDelimited_7Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFileInputDelimited_6 finally ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_6";

	

 



/**
 * [tFileInputDelimited_6 finally ] stop
 */

	
	/**
	 * [tUniqRow_6 finally ] start
	 */

	

	
	
	currentComponent="tUniqRow_6";

	

 



/**
 * [tUniqRow_6 finally ] stop
 */

	
	/**
	 * [tSchemaComplianceCheck_6 finally ] start
	 */

	

	
	
	currentComponent="tSchemaComplianceCheck_6";

	

 



/**
 * [tSchemaComplianceCheck_6 finally ] stop
 */

	
	/**
	 * [tMap_9 finally ] start
	 */

	

	
	
	currentComponent="tMap_9";

	

 



/**
 * [tMap_9 finally ] stop
 */

	
	/**
	 * [tDBOutput_6 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_6";

	



    if (resourceMap.get("statementClosed_tDBOutput_6") == null) {
                java.sql.PreparedStatement pstmtUpdateToClose_tDBOutput_6 = null;
                if ((pstmtUpdateToClose_tDBOutput_6 = (java.sql.PreparedStatement) resourceMap.remove("pstmtUpdate_tDBOutput_6")) != null) {
                    pstmtUpdateToClose_tDBOutput_6.close();
                }
                java.sql.PreparedStatement pstmtInsertToClose_tDBOutput_6 = null;
                if ((pstmtInsertToClose_tDBOutput_6 = (java.sql.PreparedStatement) resourceMap.remove("pstmtInsert_tDBOutput_6")) != null) {
                    pstmtInsertToClose_tDBOutput_6.close();
                }
                java.sql.PreparedStatement pstmtToClose_tDBOutput_6 = null;
                if ((pstmtToClose_tDBOutput_6 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_6")) != null) {
                    pstmtToClose_tDBOutput_6.close();
                }
    }
 



/**
 * [tDBOutput_6 finally ] stop
 */












				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFileInputDelimited_6_SUBPROCESS_STATE", 1);
	}
	


public static class out9Struct implements routines.system.IPersistableRow<out9Struct> {
    final static byte[] commonByteArrayLock_LOCAL_PROJECT_STG_Load = new byte[0];
    static byte[] commonByteArray_LOCAL_PROJECT_STG_Load = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int ID;

				public int getID () {
					return this.ID;
				}
				
			    public int SK_PARTICIPANT_ID;

				public int getSK_PARTICIPANT_ID () {
					return this.SK_PARTICIPANT_ID;
				}
				
			    public String SK_VOL_ID;

				public String getSK_VOL_ID () {
					return this.SK_VOL_ID;
				}
				
			    public int MILES_CALCULES;

				public int getMILES_CALCULES () {
					return this.MILES_CALCULES;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.ID;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final out9Struct other = (out9Struct) obj;
		
						if (this.ID != other.ID)
							return false;
					

		return true;
    }

	public void copyDataTo(out9Struct other) {

		other.ID = this.ID;
	            other.SK_PARTICIPANT_ID = this.SK_PARTICIPANT_ID;
	            other.SK_VOL_ID = this.SK_VOL_ID;
	            other.MILES_CALCULES = this.MILES_CALCULES;
	            
	}

	public void copyKeysDataTo(out9Struct other) {

		other.ID = this.ID;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
			        this.ID = dis.readInt();
					
			        this.SK_PARTICIPANT_ID = dis.readInt();
					
					this.SK_VOL_ID = readString(dis);
					
			        this.MILES_CALCULES = dis.readInt();
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
			        this.ID = dis.readInt();
					
			        this.SK_PARTICIPANT_ID = dis.readInt();
					
					this.SK_VOL_ID = readString(dis);
					
			        this.MILES_CALCULES = dis.readInt();
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.ID);
					
					// int
				
		            	dos.writeInt(this.SK_PARTICIPANT_ID);
					
					// String
				
						writeString(this.SK_VOL_ID,dos);
					
					// int
				
		            	dos.writeInt(this.MILES_CALCULES);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.ID);
					
					// int
				
		            	dos.writeInt(this.SK_PARTICIPANT_ID);
					
					// String
				
						writeString(this.SK_VOL_ID,dos);
					
					// int
				
		            	dos.writeInt(this.MILES_CALCULES);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("ID="+String.valueOf(ID));
		sb.append(",SK_PARTICIPANT_ID="+String.valueOf(SK_PARTICIPANT_ID));
		sb.append(",SK_VOL_ID="+SK_VOL_ID);
		sb.append(",MILES_CALCULES="+String.valueOf(MILES_CALCULES));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(out9Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.ID, other.ID);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row21Struct implements routines.system.IPersistableRow<row21Struct> {
    final static byte[] commonByteArrayLock_LOCAL_PROJECT_STG_Load = new byte[0];
    static byte[] commonByteArray_LOCAL_PROJECT_STG_Load = new byte[0];

	
			    public Integer id_miles;

				public Integer getId_miles () {
					return this.id_miles;
				}
				
			    public Integer id_participant;

				public Integer getId_participant () {
					return this.id_participant;
				}
				
			    public String id_vol;

				public String getId_vol () {
					return this.id_vol;
				}
				
			    public Integer miles_calcule;

				public Integer getMiles_calcule () {
					return this.miles_calcule;
				}
				


	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
						this.id_miles = readInteger(dis);
					
						this.id_participant = readInteger(dis);
					
					this.id_vol = readString(dis);
					
						this.miles_calcule = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
						this.id_miles = readInteger(dis);
					
						this.id_participant = readInteger(dis);
					
					this.id_vol = readString(dis);
					
						this.miles_calcule = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.id_miles,dos);
					
					// Integer
				
						writeInteger(this.id_participant,dos);
					
					// String
				
						writeString(this.id_vol,dos);
					
					// Integer
				
						writeInteger(this.miles_calcule,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// Integer
				
						writeInteger(this.id_miles,dos);
					
					// Integer
				
						writeInteger(this.id_participant,dos);
					
					// String
				
						writeString(this.id_vol,dos);
					
					// Integer
				
						writeInteger(this.miles_calcule,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id_miles="+String.valueOf(id_miles));
		sb.append(",id_participant="+String.valueOf(id_participant));
		sb.append(",id_vol="+id_vol);
		sb.append(",miles_calcule="+String.valueOf(miles_calcule));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row21Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row20Struct implements routines.system.IPersistableRow<row20Struct> {
    final static byte[] commonByteArrayLock_LOCAL_PROJECT_STG_Load = new byte[0];
    static byte[] commonByteArray_LOCAL_PROJECT_STG_Load = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public Integer id_miles;

				public Integer getId_miles () {
					return this.id_miles;
				}
				
			    public Integer id_participant;

				public Integer getId_participant () {
					return this.id_participant;
				}
				
			    public String id_vol;

				public String getId_vol () {
					return this.id_vol;
				}
				
			    public Integer miles_calcule;

				public Integer getMiles_calcule () {
					return this.miles_calcule;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.id_miles == null) ? 0 : this.id_miles.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row20Struct other = (row20Struct) obj;
		
						if (this.id_miles == null) {
							if (other.id_miles != null)
								return false;
						
						} else if (!this.id_miles.equals(other.id_miles))
						
							return false;
					

		return true;
    }

	public void copyDataTo(row20Struct other) {

		other.id_miles = this.id_miles;
	            other.id_participant = this.id_participant;
	            other.id_vol = this.id_vol;
	            other.miles_calcule = this.miles_calcule;
	            
	}

	public void copyKeysDataTo(row20Struct other) {

		other.id_miles = this.id_miles;
	            	
	}



	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
						this.id_miles = readInteger(dis);
					
						this.id_participant = readInteger(dis);
					
					this.id_vol = readString(dis);
					
						this.miles_calcule = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
						this.id_miles = readInteger(dis);
					
						this.id_participant = readInteger(dis);
					
					this.id_vol = readString(dis);
					
						this.miles_calcule = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.id_miles,dos);
					
					// Integer
				
						writeInteger(this.id_participant,dos);
					
					// String
				
						writeString(this.id_vol,dos);
					
					// Integer
				
						writeInteger(this.miles_calcule,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// Integer
				
						writeInteger(this.id_miles,dos);
					
					// Integer
				
						writeInteger(this.id_participant,dos);
					
					// String
				
						writeString(this.id_vol,dos);
					
					// Integer
				
						writeInteger(this.miles_calcule,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id_miles="+String.valueOf(id_miles));
		sb.append(",id_participant="+String.valueOf(id_participant));
		sb.append(",id_vol="+id_vol);
		sb.append(",miles_calcule="+String.valueOf(miles_calcule));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row20Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.id_miles, other.id_miles);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row19Struct implements routines.system.IPersistableRow<row19Struct> {
    final static byte[] commonByteArrayLock_LOCAL_PROJECT_STG_Load = new byte[0];
    static byte[] commonByteArray_LOCAL_PROJECT_STG_Load = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public Integer id_miles;

				public Integer getId_miles () {
					return this.id_miles;
				}
				
			    public Integer id_participant;

				public Integer getId_participant () {
					return this.id_participant;
				}
				
			    public String id_vol;

				public String getId_vol () {
					return this.id_vol;
				}
				
			    public Integer miles_calcule;

				public Integer getMiles_calcule () {
					return this.miles_calcule;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
						result = prime * result + ((this.id_miles == null) ? 0 : this.id_miles.hashCode());
					
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final row19Struct other = (row19Struct) obj;
		
						if (this.id_miles == null) {
							if (other.id_miles != null)
								return false;
						
						} else if (!this.id_miles.equals(other.id_miles))
						
							return false;
					

		return true;
    }

	public void copyDataTo(row19Struct other) {

		other.id_miles = this.id_miles;
	            other.id_participant = this.id_participant;
	            other.id_vol = this.id_vol;
	            other.miles_calcule = this.miles_calcule;
	            
	}

	public void copyKeysDataTo(row19Struct other) {

		other.id_miles = this.id_miles;
	            	
	}



	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
						this.id_miles = readInteger(dis);
					
						this.id_participant = readInteger(dis);
					
					this.id_vol = readString(dis);
					
						this.miles_calcule = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
						this.id_miles = readInteger(dis);
					
						this.id_participant = readInteger(dis);
					
					this.id_vol = readString(dis);
					
						this.miles_calcule = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.id_miles,dos);
					
					// Integer
				
						writeInteger(this.id_participant,dos);
					
					// String
				
						writeString(this.id_vol,dos);
					
					// Integer
				
						writeInteger(this.miles_calcule,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// Integer
				
						writeInteger(this.id_miles,dos);
					
					// Integer
				
						writeInteger(this.id_participant,dos);
					
					// String
				
						writeString(this.id_vol,dos);
					
					// Integer
				
						writeInteger(this.miles_calcule,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("id_miles="+String.valueOf(id_miles));
		sb.append(",id_participant="+String.valueOf(id_participant));
		sb.append(",id_vol="+id_vol);
		sb.append(",miles_calcule="+String.valueOf(miles_calcule));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row19Struct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.id_miles, other.id_miles);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tFileInputDelimited_7Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFileInputDelimited_7_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row19Struct row19 = new row19Struct();
row20Struct row20 = new row20Struct();
row21Struct row21 = new row21Struct();
out9Struct out9 = new out9Struct();







	
	/**
	 * [tDBOutput_7 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_7", false);
		start_Hash.put("tDBOutput_7", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_7";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"out9");
					}
				
		int tos_count_tDBOutput_7 = 0;
		






        int updateKeyCount_tDBOutput_7 = 1;
        if(updateKeyCount_tDBOutput_7 < 1) {
            throw new RuntimeException("For update, Schema must have a key");
        } else if (updateKeyCount_tDBOutput_7 == 4 && true) {
                    System.err.println("For update, every Schema column can not be a key");
        }
    
    int nb_line_tDBOutput_7 = 0;
    int nb_line_update_tDBOutput_7 = 0;
    int nb_line_inserted_tDBOutput_7 = 0;
    int nb_line_deleted_tDBOutput_7 = 0;
    int nb_line_rejected_tDBOutput_7 = 0;

    int tmp_batchUpdateCount_tDBOutput_7 = 0;

    int deletedCount_tDBOutput_7=0;
    int updatedCount_tDBOutput_7=0;
    int insertedCount_tDBOutput_7=0;
    int rowsToCommitCount_tDBOutput_7=0;
    int rejectedCount_tDBOutput_7=0;

    boolean whetherReject_tDBOutput_7 = false;

    java.sql.Connection conn_tDBOutput_7 = null;

    //optional table
    String dbschema_tDBOutput_7 = null;
    String tableName_tDBOutput_7 = null;
        dbschema_tDBOutput_7 = (String)globalMap.get("dbschema_tDBConnection_2");
		
        conn_tDBOutput_7 = (java.sql.Connection)globalMap.get("conn_tDBConnection_2");
        int count_tDBOutput_7=0;

        if(dbschema_tDBOutput_7 == null || dbschema_tDBOutput_7.trim().length() == 0) {
            tableName_tDBOutput_7 = ("STG_FAIT_MILES");
        } else {
            tableName_tDBOutput_7 = dbschema_tDBOutput_7 + "." + ("STG_FAIT_MILES");
        }
            try (java.sql.Statement stmtClear_tDBOutput_7 = conn_tDBOutput_7.createStatement()) {
                stmtClear_tDBOutput_7.executeUpdate("DELETE FROM " + tableName_tDBOutput_7 + "");
            }
                java.sql.PreparedStatement pstmt_tDBOutput_7 = conn_tDBOutput_7.prepareStatement("SELECT COUNT(1) FROM " + tableName_tDBOutput_7 + " WHERE ID = ?");
                resourceMap.put("pstmt_tDBOutput_7", pstmt_tDBOutput_7);
                String insert_tDBOutput_7 = "INSERT INTO " + tableName_tDBOutput_7 + " (ID,SK_PARTICIPANT_ID,SK_VOL_ID,MILES_CALCULES) VALUES (?,?,?,?)";    
                java.sql.PreparedStatement pstmtInsert_tDBOutput_7 = conn_tDBOutput_7.prepareStatement(insert_tDBOutput_7);
                resourceMap.put("pstmtInsert_tDBOutput_7", pstmtInsert_tDBOutput_7);
                String update_tDBOutput_7 = "UPDATE " + tableName_tDBOutput_7 + " SET SK_PARTICIPANT_ID = ?,SK_VOL_ID = ?,MILES_CALCULES = ? WHERE ID = ?";
                java.sql.PreparedStatement pstmtUpdate_tDBOutput_7 = conn_tDBOutput_7.prepareStatement(update_tDBOutput_7);
                resourceMap.put("pstmtUpdate_tDBOutput_7", pstmtUpdate_tDBOutput_7);





 



/**
 * [tDBOutput_7 begin ] stop
 */



	
	/**
	 * [tMap_10 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_10", false);
		start_Hash.put("tMap_10", System.currentTimeMillis());
		
	
	currentComponent="tMap_10";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row21");
					}
				
		int tos_count_tMap_10 = 0;
		




// ###############################
// # Lookup's keys initialization
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_10__Struct  {
}
Var__tMap_10__Struct Var__tMap_10 = new Var__tMap_10__Struct();
// ###############################

// ###############################
// # Outputs initialization
out9Struct out9_tmp = new out9Struct();
// ###############################

        
        



        









 



/**
 * [tMap_10 begin ] stop
 */



	
	/**
	 * [tSchemaComplianceCheck_7 begin ] start
	 */

	

	
		
		ok_Hash.put("tSchemaComplianceCheck_7", false);
		start_Hash.put("tSchemaComplianceCheck_7", System.currentTimeMillis());
		
	
	currentComponent="tSchemaComplianceCheck_7";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row20");
					}
				
		int tos_count_tSchemaComplianceCheck_7 = 0;
		

    class RowSetValueUtil_tSchemaComplianceCheck_7 {

        boolean ifPassedThrough = true;
        int errorCodeThrough = 0;
        String errorMessageThrough = "";
        int resultErrorCodeThrough = 0;
        String resultErrorMessageThrough = "";
        String tmpContentThrough = null;

        boolean ifPassed = true;
        int errorCode = 0;
        String errorMessage = "";

        void handleBigdecimalPrecision(String data, int iPrecision, int maxLength){
            //number of digits before the decimal point(ignoring frontend zeroes)
            int len1 = 0;
            int len2 = 0;
            ifPassed = true;
            errorCode = 0;
            errorMessage = "";
            if(data.startsWith("-")){
                data = data.substring(1);
            }
            data = org.apache.commons.lang.StringUtils.stripStart(data, "0");

            if(data.indexOf(".") >= 0){
                len1 = data.indexOf(".");
                data = org.apache.commons.lang.StringUtils.stripEnd(data, "0");
                len2 = data.length() - (len1 + 1);
            }else{
                len1 = data.length();
            }

            if (iPrecision < len2) {
                ifPassed = false;
                errorCode += 8;
                errorMessage += "|precision Non-matches";
            } else if (maxLength < len1 + iPrecision) {
                ifPassed = false;
                errorCode += 8;
                errorMessage += "|invalid Length setting is unsuitable for Precision";
            }
        }

        int handleErrorCode(int errorCode, int resultErrorCode){
            if (errorCode > 0) {
                if (resultErrorCode > 0) {
                    resultErrorCode = 16;
                } else {
                    resultErrorCode = errorCode;
                }
            }
            return resultErrorCode;
        }

        String handleErrorMessage(String errorMessage, String resultErrorMessage, String columnLabel){
            if (errorMessage.length() > 0) {
                if (resultErrorMessage.length() > 0) {
                    resultErrorMessage += ";"+ errorMessage.replaceFirst("\\|", columnLabel);
                } else {
                    resultErrorMessage = errorMessage.replaceFirst("\\|", columnLabel);
                }
            }
            return resultErrorMessage;
        }

        void reset(){
            ifPassedThrough = true;
            errorCodeThrough = 0;
            errorMessageThrough = "";
            resultErrorCodeThrough = 0;
            resultErrorMessageThrough = "";
            tmpContentThrough = null;

            ifPassed = true;
            errorCode = 0;
            errorMessage = "";
        }

        void setRowValue_0(row20Struct row20) {
    // validate nullable (empty as null)
    if ((row20.id_miles == null) || ("".equals(row20.id_miles))) {
        ifPassedThrough = false;
        errorCodeThrough += 4;
        errorMessageThrough += "|empty or null";
    }
            resultErrorCodeThrough = handleErrorCode(errorCodeThrough,resultErrorCodeThrough);
            errorCodeThrough = 0;
            resultErrorMessageThrough = handleErrorMessage(errorMessageThrough,resultErrorMessageThrough,"id_miles:");
            errorMessageThrough = "";
    // validate nullable (empty as null)
    if ((row20.id_participant == null) || ("".equals(row20.id_participant))) {
        ifPassedThrough = false;
        errorCodeThrough += 4;
        errorMessageThrough += "|empty or null";
    }
            resultErrorCodeThrough = handleErrorCode(errorCodeThrough,resultErrorCodeThrough);
            errorCodeThrough = 0;
            resultErrorMessageThrough = handleErrorMessage(errorMessageThrough,resultErrorMessageThrough,"id_participant:");
            errorMessageThrough = "";
    // validate nullable (empty as null)
    if ((row20.id_vol == null) || ("".equals(row20.id_vol))) {
        ifPassedThrough = false;
        errorCodeThrough += 4;
        errorMessageThrough += "|empty or null";
    }    try {
        if(
        row20.id_vol != null
        ) {
            String tester_tSchemaComplianceCheck_7 = String.valueOf(row20.id_vol);
        }
    } catch(java.lang.Exception e) {
globalMap.put("tSchemaComplianceCheck_7_ERROR_MESSAGE",e.getMessage());
        ifPassedThrough = false;
        errorCodeThrough += 2;
        errorMessageThrough += "|wrong type";
    }
            resultErrorCodeThrough = handleErrorCode(errorCodeThrough,resultErrorCodeThrough);
            errorCodeThrough = 0;
            resultErrorMessageThrough = handleErrorMessage(errorMessageThrough,resultErrorMessageThrough,"id_vol:");
            errorMessageThrough = "";
    // validate nullable (empty as null)
    if ((row20.miles_calcule == null) || ("".equals(row20.miles_calcule))) {
        ifPassedThrough = false;
        errorCodeThrough += 4;
        errorMessageThrough += "|empty or null";
    }
            resultErrorCodeThrough = handleErrorCode(errorCodeThrough,resultErrorCodeThrough);
            errorCodeThrough = 0;
            resultErrorMessageThrough = handleErrorMessage(errorMessageThrough,resultErrorMessageThrough,"miles_calcule:");
            errorMessageThrough = "";
        }
    }
    RowSetValueUtil_tSchemaComplianceCheck_7 rsvUtil_tSchemaComplianceCheck_7 = new RowSetValueUtil_tSchemaComplianceCheck_7();

 



/**
 * [tSchemaComplianceCheck_7 begin ] stop
 */



	
	/**
	 * [tUniqRow_7 begin ] start
	 */

	

	
		
		ok_Hash.put("tUniqRow_7", false);
		start_Hash.put("tUniqRow_7", System.currentTimeMillis());
		
	
	currentComponent="tUniqRow_7";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row19");
					}
				
		int tos_count_tUniqRow_7 = 0;
		

	
		class KeyStruct_tUniqRow_7 {
	
			private static final int DEFAULT_HASHCODE = 1;
		    private static final int PRIME = 31;
		    private int hashCode = DEFAULT_HASHCODE;
		    public boolean hashCodeDirty = true;
	
	        
					Integer id_miles;        
	        
		    @Override
			public int hashCode() {
				if (this.hashCodeDirty) {
					final int prime = PRIME;
					int result = DEFAULT_HASHCODE;
			
								result = prime * result + ((this.id_miles == null) ? 0 : this.id_miles.hashCode());
								
		    		this.hashCode = result;
		    		this.hashCodeDirty = false;		
				}
				return this.hashCode;
			}
			
			@Override
			public boolean equals(Object obj) {
				if (this == obj) return true;
				if (obj == null) return false;
				if (getClass() != obj.getClass()) return false;
				final KeyStruct_tUniqRow_7 other = (KeyStruct_tUniqRow_7) obj;
				
									if (this.id_miles == null) {
										if (other.id_miles != null) 
											return false;
								
									} else if (!this.id_miles.equals(other.id_miles))
								 
										return false;
								
				
				return true;
			}
	  
	        
		}

	
int nb_uniques_tUniqRow_7 = 0;
int nb_duplicates_tUniqRow_7 = 0;
KeyStruct_tUniqRow_7 finder_tUniqRow_7 = new KeyStruct_tUniqRow_7();
java.util.Set<KeyStruct_tUniqRow_7> keystUniqRow_7 = new java.util.HashSet<KeyStruct_tUniqRow_7>(); 

 



/**
 * [tUniqRow_7 begin ] stop
 */



	
	/**
	 * [tFileInputDelimited_7 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileInputDelimited_7", false);
		start_Hash.put("tFileInputDelimited_7", System.currentTimeMillis());
		
	
	currentComponent="tFileInputDelimited_7";

	
		int tos_count_tFileInputDelimited_7 = 0;
		
	
	
	
 
	
	
	final routines.system.RowState rowstate_tFileInputDelimited_7 = new routines.system.RowState();
	
	
				int nb_line_tFileInputDelimited_7 = 0;
				org.talend.fileprocess.FileInputDelimited fid_tFileInputDelimited_7 = null;
				int limit_tFileInputDelimited_7 = -1;
				try{
					
						Object filename_tFileInputDelimited_7 = context.source_path+"miles.csv";
						if(filename_tFileInputDelimited_7 instanceof java.io.InputStream){
							
			int footer_value_tFileInputDelimited_7 = 0, random_value_tFileInputDelimited_7 = -1;
			if(footer_value_tFileInputDelimited_7 >0 || random_value_tFileInputDelimited_7 > 0){
				throw new java.lang.Exception("When the input source is a stream,footer and random shouldn't be bigger than 0.");				
			}
		
						}
						try {
							fid_tFileInputDelimited_7 = new org.talend.fileprocess.FileInputDelimited(context.source_path+"miles.csv", "UTF-8",",","\n",false,1,0,
									limit_tFileInputDelimited_7
								,-1, false);
						} catch(java.lang.Exception e) {
globalMap.put("tFileInputDelimited_7_ERROR_MESSAGE",e.getMessage());
							
								
								System.err.println(e.getMessage());
							
						}
					
				    
					while (fid_tFileInputDelimited_7!=null && fid_tFileInputDelimited_7.nextRecord()) {
						rowstate_tFileInputDelimited_7.reset();
						
			    						row19 = null;			
												
									boolean whetherReject_tFileInputDelimited_7 = false;
									row19 = new row19Struct();
									try {
										
				int columnIndexWithD_tFileInputDelimited_7 = 0;
				
					String temp = ""; 
				
					columnIndexWithD_tFileInputDelimited_7 = 0;
					
						temp = fid_tFileInputDelimited_7.get(columnIndexWithD_tFileInputDelimited_7);
						if(temp.length() > 0) {
							
								try {
								
    								row19.id_miles = ParserUtils.parseTo_Integer(temp);
    							
    							} catch(java.lang.Exception ex_tFileInputDelimited_7) {
globalMap.put("tFileInputDelimited_7_ERROR_MESSAGE",ex_tFileInputDelimited_7.getMessage());
									rowstate_tFileInputDelimited_7.setException(new RuntimeException(String.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
										"id_miles", "row19", temp, ex_tFileInputDelimited_7), ex_tFileInputDelimited_7));
								}
    							
						} else {						
							
								
									row19.id_miles = null;
								
							
						}
					
				
					columnIndexWithD_tFileInputDelimited_7 = 1;
					
						temp = fid_tFileInputDelimited_7.get(columnIndexWithD_tFileInputDelimited_7);
						if(temp.length() > 0) {
							
								try {
								
    								row19.id_participant = ParserUtils.parseTo_Integer(temp);
    							
    							} catch(java.lang.Exception ex_tFileInputDelimited_7) {
globalMap.put("tFileInputDelimited_7_ERROR_MESSAGE",ex_tFileInputDelimited_7.getMessage());
									rowstate_tFileInputDelimited_7.setException(new RuntimeException(String.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
										"id_participant", "row19", temp, ex_tFileInputDelimited_7), ex_tFileInputDelimited_7));
								}
    							
						} else {						
							
								
									row19.id_participant = null;
								
							
						}
					
				
					columnIndexWithD_tFileInputDelimited_7 = 2;
					
							row19.id_vol = fid_tFileInputDelimited_7.get(columnIndexWithD_tFileInputDelimited_7);
						
				
					columnIndexWithD_tFileInputDelimited_7 = 3;
					
						temp = fid_tFileInputDelimited_7.get(columnIndexWithD_tFileInputDelimited_7);
						if(temp.length() > 0) {
							
								try {
								
    								row19.miles_calcule = ParserUtils.parseTo_Integer(temp);
    							
    							} catch(java.lang.Exception ex_tFileInputDelimited_7) {
globalMap.put("tFileInputDelimited_7_ERROR_MESSAGE",ex_tFileInputDelimited_7.getMessage());
									rowstate_tFileInputDelimited_7.setException(new RuntimeException(String.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
										"miles_calcule", "row19", temp, ex_tFileInputDelimited_7), ex_tFileInputDelimited_7));
								}
    							
						} else {						
							
								
									row19.miles_calcule = null;
								
							
						}
					
				
				
										
										if(rowstate_tFileInputDelimited_7.getException()!=null) {
											throw rowstate_tFileInputDelimited_7.getException();
										}
										
										
							
			    					} catch (java.lang.Exception e) {
globalMap.put("tFileInputDelimited_7_ERROR_MESSAGE",e.getMessage());
			        					whetherReject_tFileInputDelimited_7 = true;
			        					
			                					System.err.println(e.getMessage());
			                					row19 = null;
			                				
										
			    					}
								

 



/**
 * [tFileInputDelimited_7 begin ] stop
 */
	
	/**
	 * [tFileInputDelimited_7 main ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_7";

	

 


	tos_count_tFileInputDelimited_7++;

/**
 * [tFileInputDelimited_7 main ] stop
 */
	
	/**
	 * [tFileInputDelimited_7 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_7";

	

 



/**
 * [tFileInputDelimited_7 process_data_begin ] stop
 */
// Start of branch "row19"
if(row19 != null) { 



	
	/**
	 * [tUniqRow_7 main ] start
	 */

	

	
	
	currentComponent="tUniqRow_7";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row19"
						
						);
					}
					
row20 = null;			
finder_tUniqRow_7.id_miles = row19.id_miles;	
finder_tUniqRow_7.hashCodeDirty = true;
if (!keystUniqRow_7.contains(finder_tUniqRow_7)) {
		KeyStruct_tUniqRow_7 new_tUniqRow_7 = new KeyStruct_tUniqRow_7();

		
new_tUniqRow_7.id_miles = row19.id_miles;
		
		keystUniqRow_7.add(new_tUniqRow_7);if(row20 == null){ 
	
	row20 = new row20Struct();
}row20.id_miles = row19.id_miles;			row20.id_participant = row19.id_participant;			row20.id_vol = row19.id_vol;			row20.miles_calcule = row19.miles_calcule;					
		nb_uniques_tUniqRow_7++;
	} else {
	  nb_duplicates_tUniqRow_7++;
	}

 


	tos_count_tUniqRow_7++;

/**
 * [tUniqRow_7 main ] stop
 */
	
	/**
	 * [tUniqRow_7 process_data_begin ] start
	 */

	

	
	
	currentComponent="tUniqRow_7";

	

 



/**
 * [tUniqRow_7 process_data_begin ] stop
 */
// Start of branch "row20"
if(row20 != null) { 



	
	/**
	 * [tSchemaComplianceCheck_7 main ] start
	 */

	

	
	
	currentComponent="tSchemaComplianceCheck_7";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row20"
						
						);
					}
					
	row21 = null;
	rsvUtil_tSchemaComplianceCheck_7.setRowValue_0(row20);
	if (rsvUtil_tSchemaComplianceCheck_7.ifPassedThrough) {
		row21 = new row21Struct();
		row21.id_miles = row20.id_miles;
		row21.id_participant = row20.id_participant;
		row21.id_vol = row20.id_vol;
		row21.miles_calcule = row20.miles_calcule;
	}
	rsvUtil_tSchemaComplianceCheck_7.reset();

 


	tos_count_tSchemaComplianceCheck_7++;

/**
 * [tSchemaComplianceCheck_7 main ] stop
 */
	
	/**
	 * [tSchemaComplianceCheck_7 process_data_begin ] start
	 */

	

	
	
	currentComponent="tSchemaComplianceCheck_7";

	

 



/**
 * [tSchemaComplianceCheck_7 process_data_begin ] stop
 */
// Start of branch "row21"
if(row21 != null) { 



	
	/**
	 * [tMap_10 main ] start
	 */

	

	
	
	currentComponent="tMap_10";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row21"
						
						);
					}
					

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_10 = false;
		

        // ###############################
        // # Input tables (lookups)
		  boolean rejectedInnerJoin_tMap_10 = false;
		  boolean mainRowRejected_tMap_10 = false;
            				    								  
		// ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_10__Struct Var = Var__tMap_10;// ###############################
        // ###############################
        // # Output tables

out9 = null;


// # Output table : 'out9'
out9_tmp.ID = row21.id_miles ;
out9_tmp.SK_PARTICIPANT_ID = row21.id_participant ;
out9_tmp.SK_VOL_ID = routines.Clean.nettoie(row21.id_vol);
out9_tmp.MILES_CALCULES = row21.miles_calcule ;
out9 = out9_tmp;
// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_10 = false;










 


	tos_count_tMap_10++;

/**
 * [tMap_10 main ] stop
 */
	
	/**
	 * [tMap_10 process_data_begin ] start
	 */

	

	
	
	currentComponent="tMap_10";

	

 



/**
 * [tMap_10 process_data_begin ] stop
 */
// Start of branch "out9"
if(out9 != null) { 



	
	/**
	 * [tDBOutput_7 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_7";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"out9"
						
						);
					}
					



        whetherReject_tDBOutput_7 = false;
                    pstmt_tDBOutput_7.setInt(1, out9.ID);

            int checkCount_tDBOutput_7 = -1;
            try (java.sql.ResultSet rs_tDBOutput_7 = pstmt_tDBOutput_7.executeQuery()) {
                while(rs_tDBOutput_7.next()) {
                    checkCount_tDBOutput_7 = rs_tDBOutput_7.getInt(1);
                }
            }
            if(checkCount_tDBOutput_7 > 0) {
                        pstmtUpdate_tDBOutput_7.setInt(1, out9.SK_PARTICIPANT_ID);

                        if(out9.SK_VOL_ID == null) {
pstmtUpdate_tDBOutput_7.setNull(2, java.sql.Types.VARCHAR);
} else {pstmtUpdate_tDBOutput_7.setString(2, out9.SK_VOL_ID);
}

                        pstmtUpdate_tDBOutput_7.setInt(3, out9.MILES_CALCULES);

                        pstmtUpdate_tDBOutput_7.setInt(4 + count_tDBOutput_7, out9.ID);

                try {
                    int processedCount_tDBOutput_7 = pstmtUpdate_tDBOutput_7.executeUpdate();
                    updatedCount_tDBOutput_7 += processedCount_tDBOutput_7;
                    rowsToCommitCount_tDBOutput_7 += processedCount_tDBOutput_7;
                    nb_line_tDBOutput_7++;
                } catch(java.lang.Exception e_tDBOutput_7) {
globalMap.put("tDBOutput_7_ERROR_MESSAGE",e_tDBOutput_7.getMessage());
                    whetherReject_tDBOutput_7 = true;
                        nb_line_tDBOutput_7++;
                            System.err.print(e_tDBOutput_7.getMessage());
                }
            } else {
                        pstmtInsert_tDBOutput_7.setInt(1, out9.ID);

                        pstmtInsert_tDBOutput_7.setInt(2, out9.SK_PARTICIPANT_ID);

                        if(out9.SK_VOL_ID == null) {
pstmtInsert_tDBOutput_7.setNull(3, java.sql.Types.VARCHAR);
} else {pstmtInsert_tDBOutput_7.setString(3, out9.SK_VOL_ID);
}

                        pstmtInsert_tDBOutput_7.setInt(4, out9.MILES_CALCULES);

                try {
                    int processedCount_tDBOutput_7 = pstmtInsert_tDBOutput_7.executeUpdate();
                    insertedCount_tDBOutput_7 += processedCount_tDBOutput_7;
                    rowsToCommitCount_tDBOutput_7 += processedCount_tDBOutput_7;
                    nb_line_tDBOutput_7++;
                } catch(java.lang.Exception e_tDBOutput_7) {
globalMap.put("tDBOutput_7_ERROR_MESSAGE",e_tDBOutput_7.getMessage());
                    whetherReject_tDBOutput_7 = true;
                        nb_line_tDBOutput_7++;
                            System.err.print(e_tDBOutput_7.getMessage());
                }
            }

 


	tos_count_tDBOutput_7++;

/**
 * [tDBOutput_7 main ] stop
 */
	
	/**
	 * [tDBOutput_7 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_7";

	

 



/**
 * [tDBOutput_7 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_7 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_7";

	

 



/**
 * [tDBOutput_7 process_data_end ] stop
 */

} // End of branch "out9"




	
	/**
	 * [tMap_10 process_data_end ] start
	 */

	

	
	
	currentComponent="tMap_10";

	

 



/**
 * [tMap_10 process_data_end ] stop
 */

} // End of branch "row21"




	
	/**
	 * [tSchemaComplianceCheck_7 process_data_end ] start
	 */

	

	
	
	currentComponent="tSchemaComplianceCheck_7";

	

 



/**
 * [tSchemaComplianceCheck_7 process_data_end ] stop
 */

} // End of branch "row20"




	
	/**
	 * [tUniqRow_7 process_data_end ] start
	 */

	

	
	
	currentComponent="tUniqRow_7";

	

 



/**
 * [tUniqRow_7 process_data_end ] stop
 */

} // End of branch "row19"




	
	/**
	 * [tFileInputDelimited_7 process_data_end ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_7";

	

 



/**
 * [tFileInputDelimited_7 process_data_end ] stop
 */
	
	/**
	 * [tFileInputDelimited_7 end ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_7";

	



            }
            }finally{
                if(!((Object)(context.source_path+"miles.csv") instanceof java.io.InputStream)){
                	if(fid_tFileInputDelimited_7!=null){
                		fid_tFileInputDelimited_7.close();
                	}
                }
                if(fid_tFileInputDelimited_7!=null){
                	globalMap.put("tFileInputDelimited_7_NB_LINE", fid_tFileInputDelimited_7.getRowNumber());
					
                }
			}
			  

 

ok_Hash.put("tFileInputDelimited_7", true);
end_Hash.put("tFileInputDelimited_7", System.currentTimeMillis());




/**
 * [tFileInputDelimited_7 end ] stop
 */

	
	/**
	 * [tUniqRow_7 end ] start
	 */

	

	
	
	currentComponent="tUniqRow_7";

	

globalMap.put("tUniqRow_7_NB_UNIQUES",nb_uniques_tUniqRow_7);
globalMap.put("tUniqRow_7_NB_DUPLICATES",nb_duplicates_tUniqRow_7);

				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row19");
			  	}
			  	
 

ok_Hash.put("tUniqRow_7", true);
end_Hash.put("tUniqRow_7", System.currentTimeMillis());




/**
 * [tUniqRow_7 end ] stop
 */

	
	/**
	 * [tSchemaComplianceCheck_7 end ] start
	 */

	

	
	
	currentComponent="tSchemaComplianceCheck_7";

	

				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row20");
			  	}
			  	
 

ok_Hash.put("tSchemaComplianceCheck_7", true);
end_Hash.put("tSchemaComplianceCheck_7", System.currentTimeMillis());




/**
 * [tSchemaComplianceCheck_7 end ] stop
 */

	
	/**
	 * [tMap_10 end ] start
	 */

	

	
	
	currentComponent="tMap_10";

	


// ###############################
// # Lookup hashes releasing
// ###############################      





				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row21");
			  	}
			  	
 

ok_Hash.put("tMap_10", true);
end_Hash.put("tMap_10", System.currentTimeMillis());




/**
 * [tMap_10 end ] stop
 */

	
	/**
	 * [tDBOutput_7 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_7";

	
	



	
        if(pstmtUpdate_tDBOutput_7 != null){
            pstmtUpdate_tDBOutput_7.close();
            resourceMap.remove("pstmtUpdate_tDBOutput_7");
        }
        if(pstmtInsert_tDBOutput_7 != null){
            pstmtInsert_tDBOutput_7.close();
            resourceMap.remove("pstmtInsert_tDBOutput_7");
        }
        if(pstmt_tDBOutput_7 != null) {
            pstmt_tDBOutput_7.close();
            resourceMap.remove("pstmt_tDBOutput_7");
        }
    resourceMap.put("statementClosed_tDBOutput_7", true);

	
	nb_line_deleted_tDBOutput_7=nb_line_deleted_tDBOutput_7+ deletedCount_tDBOutput_7;
	nb_line_update_tDBOutput_7=nb_line_update_tDBOutput_7 + updatedCount_tDBOutput_7;
	nb_line_inserted_tDBOutput_7=nb_line_inserted_tDBOutput_7 + insertedCount_tDBOutput_7;
	nb_line_rejected_tDBOutput_7=nb_line_rejected_tDBOutput_7 + rejectedCount_tDBOutput_7;
	
        globalMap.put("tDBOutput_7_NB_LINE",nb_line_tDBOutput_7);
        globalMap.put("tDBOutput_7_NB_LINE_UPDATED",nb_line_update_tDBOutput_7);
        globalMap.put("tDBOutput_7_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_7);
        globalMap.put("tDBOutput_7_NB_LINE_DELETED",nb_line_deleted_tDBOutput_7);
        globalMap.put("tDBOutput_7_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_7);
    

	



				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"out9");
			  	}
			  	
 

ok_Hash.put("tDBOutput_7", true);
end_Hash.put("tDBOutput_7", System.currentTimeMillis());




/**
 * [tDBOutput_7 end ] stop
 */












				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tFileInputDelimited_7:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk9", 0, "ok");
								} 
							
							tFileInputDelimited_8Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFileInputDelimited_7 finally ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_7";

	

 



/**
 * [tFileInputDelimited_7 finally ] stop
 */

	
	/**
	 * [tUniqRow_7 finally ] start
	 */

	

	
	
	currentComponent="tUniqRow_7";

	

 



/**
 * [tUniqRow_7 finally ] stop
 */

	
	/**
	 * [tSchemaComplianceCheck_7 finally ] start
	 */

	

	
	
	currentComponent="tSchemaComplianceCheck_7";

	

 



/**
 * [tSchemaComplianceCheck_7 finally ] stop
 */

	
	/**
	 * [tMap_10 finally ] start
	 */

	

	
	
	currentComponent="tMap_10";

	

 



/**
 * [tMap_10 finally ] stop
 */

	
	/**
	 * [tDBOutput_7 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_7";

	



    if (resourceMap.get("statementClosed_tDBOutput_7") == null) {
                java.sql.PreparedStatement pstmtUpdateToClose_tDBOutput_7 = null;
                if ((pstmtUpdateToClose_tDBOutput_7 = (java.sql.PreparedStatement) resourceMap.remove("pstmtUpdate_tDBOutput_7")) != null) {
                    pstmtUpdateToClose_tDBOutput_7.close();
                }
                java.sql.PreparedStatement pstmtInsertToClose_tDBOutput_7 = null;
                if ((pstmtInsertToClose_tDBOutput_7 = (java.sql.PreparedStatement) resourceMap.remove("pstmtInsert_tDBOutput_7")) != null) {
                    pstmtInsertToClose_tDBOutput_7.close();
                }
                java.sql.PreparedStatement pstmtToClose_tDBOutput_7 = null;
                if ((pstmtToClose_tDBOutput_7 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_7")) != null) {
                    pstmtToClose_tDBOutput_7.close();
                }
    }
 



/**
 * [tDBOutput_7 finally ] stop
 */












				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFileInputDelimited_7_SUBPROCESS_STATE", 1);
	}
	


public static class STG_BILLETStruct implements routines.system.IPersistableRow<STG_BILLETStruct> {
    final static byte[] commonByteArrayLock_LOCAL_PROJECT_STG_Load = new byte[0];
    static byte[] commonByteArray_LOCAL_PROJECT_STG_Load = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int ID_BILLET;

				public int getID_BILLET () {
					return this.ID_BILLET;
				}
				
			    public int SK_CANAL_ID;

				public int getSK_CANAL_ID () {
					return this.SK_CANAL_ID;
				}
				
			    public String SK_VOL_ID;

				public String getSK_VOL_ID () {
					return this.SK_VOL_ID;
				}
				
			    public float TARIF_BASE;

				public float getTARIF_BASE () {
					return this.TARIF_BASE;
				}
				
			    public float PRIX_ACHAT;

				public float getPRIX_ACHAT () {
					return this.PRIX_ACHAT;
				}
				
			    public java.util.Date DATE_ACHAT;

				public java.util.Date getDATE_ACHAT () {
					return this.DATE_ACHAT;
				}
				
			    public String CLASSE;

				public String getCLASSE () {
					return this.CLASSE;
				}
				
			    public String STATUS;

				public String getSTATUS () {
					return this.STATUS;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.ID_BILLET;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final STG_BILLETStruct other = (STG_BILLETStruct) obj;
		
						if (this.ID_BILLET != other.ID_BILLET)
							return false;
					

		return true;
    }

	public void copyDataTo(STG_BILLETStruct other) {

		other.ID_BILLET = this.ID_BILLET;
	            other.SK_CANAL_ID = this.SK_CANAL_ID;
	            other.SK_VOL_ID = this.SK_VOL_ID;
	            other.TARIF_BASE = this.TARIF_BASE;
	            other.PRIX_ACHAT = this.PRIX_ACHAT;
	            other.DATE_ACHAT = this.DATE_ACHAT;
	            other.CLASSE = this.CLASSE;
	            other.STATUS = this.STATUS;
	            
	}

	public void copyKeysDataTo(STG_BILLETStruct other) {

		other.ID_BILLET = this.ID_BILLET;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
			        this.ID_BILLET = dis.readInt();
					
			        this.SK_CANAL_ID = dis.readInt();
					
					this.SK_VOL_ID = readString(dis);
					
			        this.TARIF_BASE = dis.readFloat();
					
			        this.PRIX_ACHAT = dis.readFloat();
					
					this.DATE_ACHAT = readDate(dis);
					
					this.CLASSE = readString(dis);
					
					this.STATUS = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
			        this.ID_BILLET = dis.readInt();
					
			        this.SK_CANAL_ID = dis.readInt();
					
					this.SK_VOL_ID = readString(dis);
					
			        this.TARIF_BASE = dis.readFloat();
					
			        this.PRIX_ACHAT = dis.readFloat();
					
					this.DATE_ACHAT = readDate(dis);
					
					this.CLASSE = readString(dis);
					
					this.STATUS = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.ID_BILLET);
					
					// int
				
		            	dos.writeInt(this.SK_CANAL_ID);
					
					// String
				
						writeString(this.SK_VOL_ID,dos);
					
					// float
				
		            	dos.writeFloat(this.TARIF_BASE);
					
					// float
				
		            	dos.writeFloat(this.PRIX_ACHAT);
					
					// java.util.Date
				
						writeDate(this.DATE_ACHAT,dos);
					
					// String
				
						writeString(this.CLASSE,dos);
					
					// String
				
						writeString(this.STATUS,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.ID_BILLET);
					
					// int
				
		            	dos.writeInt(this.SK_CANAL_ID);
					
					// String
				
						writeString(this.SK_VOL_ID,dos);
					
					// float
				
		            	dos.writeFloat(this.TARIF_BASE);
					
					// float
				
		            	dos.writeFloat(this.PRIX_ACHAT);
					
					// java.util.Date
				
						writeDate(this.DATE_ACHAT,dos);
					
					// String
				
						writeString(this.CLASSE,dos);
					
					// String
				
						writeString(this.STATUS,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("ID_BILLET="+String.valueOf(ID_BILLET));
		sb.append(",SK_CANAL_ID="+String.valueOf(SK_CANAL_ID));
		sb.append(",SK_VOL_ID="+SK_VOL_ID);
		sb.append(",TARIF_BASE="+String.valueOf(TARIF_BASE));
		sb.append(",PRIX_ACHAT="+String.valueOf(PRIX_ACHAT));
		sb.append(",DATE_ACHAT="+String.valueOf(DATE_ACHAT));
		sb.append(",CLASSE="+CLASSE);
		sb.append(",STATUS="+STATUS);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(STG_BILLETStruct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.ID_BILLET, other.ID_BILLET);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row24Struct implements routines.system.IPersistableRow<row24Struct> {
    final static byte[] commonByteArrayLock_LOCAL_PROJECT_STG_Load = new byte[0];
    static byte[] commonByteArray_LOCAL_PROJECT_STG_Load = new byte[0];

	
			    public Integer IDBillet;

				public Integer getIDBillet () {
					return this.IDBillet;
				}
				
			    public Integer IDCanal;

				public Integer getIDCanal () {
					return this.IDCanal;
				}
				
			    public String IDVol;

				public String getIDVol () {
					return this.IDVol;
				}
				
			    public Float TarifBase;

				public Float getTarifBase () {
					return this.TarifBase;
				}
				
			    public Float PrixAchat;

				public Float getPrixAchat () {
					return this.PrixAchat;
				}
				
			    public String DateAchat;

				public String getDateAchat () {
					return this.DateAchat;
				}
				
			    public String Classe;

				public String getClasse () {
					return this.Classe;
				}
				
			    public String Status;

				public String getStatus () {
					return this.Status;
				}
				


	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
						this.IDBillet = readInteger(dis);
					
						this.IDCanal = readInteger(dis);
					
					this.IDVol = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.TarifBase = null;
           				} else {
           			    	this.TarifBase = dis.readFloat();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.PrixAchat = null;
           				} else {
           			    	this.PrixAchat = dis.readFloat();
           				}
					
					this.DateAchat = readString(dis);
					
					this.Classe = readString(dis);
					
					this.Status = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
						this.IDBillet = readInteger(dis);
					
						this.IDCanal = readInteger(dis);
					
					this.IDVol = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.TarifBase = null;
           				} else {
           			    	this.TarifBase = dis.readFloat();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.PrixAchat = null;
           				} else {
           			    	this.PrixAchat = dis.readFloat();
           				}
					
					this.DateAchat = readString(dis);
					
					this.Classe = readString(dis);
					
					this.Status = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.IDBillet,dos);
					
					// Integer
				
						writeInteger(this.IDCanal,dos);
					
					// String
				
						writeString(this.IDVol,dos);
					
					// Float
				
						if(this.TarifBase == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.TarifBase);
		            	}
					
					// Float
				
						if(this.PrixAchat == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.PrixAchat);
		            	}
					
					// String
				
						writeString(this.DateAchat,dos);
					
					// String
				
						writeString(this.Classe,dos);
					
					// String
				
						writeString(this.Status,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// Integer
				
						writeInteger(this.IDBillet,dos);
					
					// Integer
				
						writeInteger(this.IDCanal,dos);
					
					// String
				
						writeString(this.IDVol,dos);
					
					// Float
				
						if(this.TarifBase == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.TarifBase);
		            	}
					
					// Float
				
						if(this.PrixAchat == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.PrixAchat);
		            	}
					
					// String
				
						writeString(this.DateAchat,dos);
					
					// String
				
						writeString(this.Classe,dos);
					
					// String
				
						writeString(this.Status,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("IDBillet="+String.valueOf(IDBillet));
		sb.append(",IDCanal="+String.valueOf(IDCanal));
		sb.append(",IDVol="+IDVol);
		sb.append(",TarifBase="+String.valueOf(TarifBase));
		sb.append(",PrixAchat="+String.valueOf(PrixAchat));
		sb.append(",DateAchat="+DateAchat);
		sb.append(",Classe="+Classe);
		sb.append(",Status="+Status);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row24Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row23Struct implements routines.system.IPersistableRow<row23Struct> {
    final static byte[] commonByteArrayLock_LOCAL_PROJECT_STG_Load = new byte[0];
    static byte[] commonByteArray_LOCAL_PROJECT_STG_Load = new byte[0];

	
			    public Integer IDBillet;

				public Integer getIDBillet () {
					return this.IDBillet;
				}
				
			    public Integer IDCanal;

				public Integer getIDCanal () {
					return this.IDCanal;
				}
				
			    public String IDVol;

				public String getIDVol () {
					return this.IDVol;
				}
				
			    public Float TarifBase;

				public Float getTarifBase () {
					return this.TarifBase;
				}
				
			    public Float PrixAchat;

				public Float getPrixAchat () {
					return this.PrixAchat;
				}
				
			    public String DateAchat;

				public String getDateAchat () {
					return this.DateAchat;
				}
				
			    public String Classe;

				public String getClasse () {
					return this.Classe;
				}
				
			    public String Status;

				public String getStatus () {
					return this.Status;
				}
				


	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
						this.IDBillet = readInteger(dis);
					
						this.IDCanal = readInteger(dis);
					
					this.IDVol = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.TarifBase = null;
           				} else {
           			    	this.TarifBase = dis.readFloat();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.PrixAchat = null;
           				} else {
           			    	this.PrixAchat = dis.readFloat();
           				}
					
					this.DateAchat = readString(dis);
					
					this.Classe = readString(dis);
					
					this.Status = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
						this.IDBillet = readInteger(dis);
					
						this.IDCanal = readInteger(dis);
					
					this.IDVol = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.TarifBase = null;
           				} else {
           			    	this.TarifBase = dis.readFloat();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.PrixAchat = null;
           				} else {
           			    	this.PrixAchat = dis.readFloat();
           				}
					
					this.DateAchat = readString(dis);
					
					this.Classe = readString(dis);
					
					this.Status = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.IDBillet,dos);
					
					// Integer
				
						writeInteger(this.IDCanal,dos);
					
					// String
				
						writeString(this.IDVol,dos);
					
					// Float
				
						if(this.TarifBase == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.TarifBase);
		            	}
					
					// Float
				
						if(this.PrixAchat == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.PrixAchat);
		            	}
					
					// String
				
						writeString(this.DateAchat,dos);
					
					// String
				
						writeString(this.Classe,dos);
					
					// String
				
						writeString(this.Status,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// Integer
				
						writeInteger(this.IDBillet,dos);
					
					// Integer
				
						writeInteger(this.IDCanal,dos);
					
					// String
				
						writeString(this.IDVol,dos);
					
					// Float
				
						if(this.TarifBase == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.TarifBase);
		            	}
					
					// Float
				
						if(this.PrixAchat == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.PrixAchat);
		            	}
					
					// String
				
						writeString(this.DateAchat,dos);
					
					// String
				
						writeString(this.Classe,dos);
					
					// String
				
						writeString(this.Status,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("IDBillet="+String.valueOf(IDBillet));
		sb.append(",IDCanal="+String.valueOf(IDCanal));
		sb.append(",IDVol="+IDVol);
		sb.append(",TarifBase="+String.valueOf(TarifBase));
		sb.append(",PrixAchat="+String.valueOf(PrixAchat));
		sb.append(",DateAchat="+DateAchat);
		sb.append(",Classe="+Classe);
		sb.append(",Status="+Status);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row23Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row22Struct implements routines.system.IPersistableRow<row22Struct> {
    final static byte[] commonByteArrayLock_LOCAL_PROJECT_STG_Load = new byte[0];
    static byte[] commonByteArray_LOCAL_PROJECT_STG_Load = new byte[0];

	
			    public Integer IDBillet;

				public Integer getIDBillet () {
					return this.IDBillet;
				}
				
			    public Integer IDCanal;

				public Integer getIDCanal () {
					return this.IDCanal;
				}
				
			    public String IDVol;

				public String getIDVol () {
					return this.IDVol;
				}
				
			    public Float TarifBase;

				public Float getTarifBase () {
					return this.TarifBase;
				}
				
			    public Float PrixAchat;

				public Float getPrixAchat () {
					return this.PrixAchat;
				}
				
			    public String DateAchat;

				public String getDateAchat () {
					return this.DateAchat;
				}
				
			    public String Classe;

				public String getClasse () {
					return this.Classe;
				}
				
			    public String Status;

				public String getStatus () {
					return this.Status;
				}
				


	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
						this.IDBillet = readInteger(dis);
					
						this.IDCanal = readInteger(dis);
					
					this.IDVol = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.TarifBase = null;
           				} else {
           			    	this.TarifBase = dis.readFloat();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.PrixAchat = null;
           				} else {
           			    	this.PrixAchat = dis.readFloat();
           				}
					
					this.DateAchat = readString(dis);
					
					this.Classe = readString(dis);
					
					this.Status = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
						this.IDBillet = readInteger(dis);
					
						this.IDCanal = readInteger(dis);
					
					this.IDVol = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.TarifBase = null;
           				} else {
           			    	this.TarifBase = dis.readFloat();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.PrixAchat = null;
           				} else {
           			    	this.PrixAchat = dis.readFloat();
           				}
					
					this.DateAchat = readString(dis);
					
					this.Classe = readString(dis);
					
					this.Status = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.IDBillet,dos);
					
					// Integer
				
						writeInteger(this.IDCanal,dos);
					
					// String
				
						writeString(this.IDVol,dos);
					
					// Float
				
						if(this.TarifBase == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.TarifBase);
		            	}
					
					// Float
				
						if(this.PrixAchat == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.PrixAchat);
		            	}
					
					// String
				
						writeString(this.DateAchat,dos);
					
					// String
				
						writeString(this.Classe,dos);
					
					// String
				
						writeString(this.Status,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// Integer
				
						writeInteger(this.IDBillet,dos);
					
					// Integer
				
						writeInteger(this.IDCanal,dos);
					
					// String
				
						writeString(this.IDVol,dos);
					
					// Float
				
						if(this.TarifBase == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.TarifBase);
		            	}
					
					// Float
				
						if(this.PrixAchat == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.PrixAchat);
		            	}
					
					// String
				
						writeString(this.DateAchat,dos);
					
					// String
				
						writeString(this.Classe,dos);
					
					// String
				
						writeString(this.Status,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("IDBillet="+String.valueOf(IDBillet));
		sb.append(",IDCanal="+String.valueOf(IDCanal));
		sb.append(",IDVol="+IDVol);
		sb.append(",TarifBase="+String.valueOf(TarifBase));
		sb.append(",PrixAchat="+String.valueOf(PrixAchat));
		sb.append(",DateAchat="+DateAchat);
		sb.append(",Classe="+Classe);
		sb.append(",Status="+Status);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row22Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tFileInputDelimited_8Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFileInputDelimited_8_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row22Struct row22 = new row22Struct();
row23Struct row23 = new row23Struct();
row24Struct row24 = new row24Struct();
STG_BILLETStruct STG_BILLET = new STG_BILLETStruct();







	
	/**
	 * [tDBOutput_8 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_8", false);
		start_Hash.put("tDBOutput_8", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_8";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"STG_BILLET");
					}
				
		int tos_count_tDBOutput_8 = 0;
		






        int updateKeyCount_tDBOutput_8 = 1;
        if(updateKeyCount_tDBOutput_8 < 1) {
            throw new RuntimeException("For update, Schema must have a key");
        } else if (updateKeyCount_tDBOutput_8 == 8 && true) {
                    System.err.println("For update, every Schema column can not be a key");
        }
    
    int nb_line_tDBOutput_8 = 0;
    int nb_line_update_tDBOutput_8 = 0;
    int nb_line_inserted_tDBOutput_8 = 0;
    int nb_line_deleted_tDBOutput_8 = 0;
    int nb_line_rejected_tDBOutput_8 = 0;

    int tmp_batchUpdateCount_tDBOutput_8 = 0;

    int deletedCount_tDBOutput_8=0;
    int updatedCount_tDBOutput_8=0;
    int insertedCount_tDBOutput_8=0;
    int rowsToCommitCount_tDBOutput_8=0;
    int rejectedCount_tDBOutput_8=0;

    boolean whetherReject_tDBOutput_8 = false;

    java.sql.Connection conn_tDBOutput_8 = null;

    //optional table
    String dbschema_tDBOutput_8 = null;
    String tableName_tDBOutput_8 = null;
        dbschema_tDBOutput_8 = (String)globalMap.get("dbschema_tDBConnection_2");
		
        conn_tDBOutput_8 = (java.sql.Connection)globalMap.get("conn_tDBConnection_2");
        int count_tDBOutput_8=0;

        if(dbschema_tDBOutput_8 == null || dbschema_tDBOutput_8.trim().length() == 0) {
            tableName_tDBOutput_8 = ("STG_DIM_BILLET");
        } else {
            tableName_tDBOutput_8 = dbschema_tDBOutput_8 + "." + ("STG_DIM_BILLET");
        }
            try (java.sql.Statement stmtClear_tDBOutput_8 = conn_tDBOutput_8.createStatement()) {
                stmtClear_tDBOutput_8.executeUpdate("DELETE FROM " + tableName_tDBOutput_8 + "");
            }
                java.sql.PreparedStatement pstmt_tDBOutput_8 = conn_tDBOutput_8.prepareStatement("SELECT COUNT(1) FROM " + tableName_tDBOutput_8 + " WHERE ID_BILLET = ?");
                resourceMap.put("pstmt_tDBOutput_8", pstmt_tDBOutput_8);
                String insert_tDBOutput_8 = "INSERT INTO " + tableName_tDBOutput_8 + " (ID_BILLET,SK_CANAL_ID,SK_VOL_ID,TARIF_BASE,PRIX_ACHAT,DATE_ACHAT,CLASSE,STATUS) VALUES (?,?,?,?,?,?,?,?)";    
                java.sql.PreparedStatement pstmtInsert_tDBOutput_8 = conn_tDBOutput_8.prepareStatement(insert_tDBOutput_8);
                resourceMap.put("pstmtInsert_tDBOutput_8", pstmtInsert_tDBOutput_8);
                String update_tDBOutput_8 = "UPDATE " + tableName_tDBOutput_8 + " SET SK_CANAL_ID = ?,SK_VOL_ID = ?,TARIF_BASE = ?,PRIX_ACHAT = ?,DATE_ACHAT = ?,CLASSE = ?,STATUS = ? WHERE ID_BILLET = ?";
                java.sql.PreparedStatement pstmtUpdate_tDBOutput_8 = conn_tDBOutput_8.prepareStatement(update_tDBOutput_8);
                resourceMap.put("pstmtUpdate_tDBOutput_8", pstmtUpdate_tDBOutput_8);





 



/**
 * [tDBOutput_8 begin ] stop
 */



	
	/**
	 * [tMap_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_3", false);
		start_Hash.put("tMap_3", System.currentTimeMillis());
		
	
	currentComponent="tMap_3";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row24");
					}
				
		int tos_count_tMap_3 = 0;
		




// ###############################
// # Lookup's keys initialization
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_3__Struct  {
}
Var__tMap_3__Struct Var__tMap_3 = new Var__tMap_3__Struct();
// ###############################

// ###############################
// # Outputs initialization
STG_BILLETStruct STG_BILLET_tmp = new STG_BILLETStruct();
// ###############################

        
        



        









 



/**
 * [tMap_3 begin ] stop
 */



	
	/**
	 * [tSchemaComplianceCheck_8 begin ] start
	 */

	

	
		
		ok_Hash.put("tSchemaComplianceCheck_8", false);
		start_Hash.put("tSchemaComplianceCheck_8", System.currentTimeMillis());
		
	
	currentComponent="tSchemaComplianceCheck_8";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row23");
					}
				
		int tos_count_tSchemaComplianceCheck_8 = 0;
		

    class RowSetValueUtil_tSchemaComplianceCheck_8 {

        boolean ifPassedThrough = true;
        int errorCodeThrough = 0;
        String errorMessageThrough = "";
        int resultErrorCodeThrough = 0;
        String resultErrorMessageThrough = "";
        String tmpContentThrough = null;

        boolean ifPassed = true;
        int errorCode = 0;
        String errorMessage = "";

        void handleBigdecimalPrecision(String data, int iPrecision, int maxLength){
            //number of digits before the decimal point(ignoring frontend zeroes)
            int len1 = 0;
            int len2 = 0;
            ifPassed = true;
            errorCode = 0;
            errorMessage = "";
            if(data.startsWith("-")){
                data = data.substring(1);
            }
            data = org.apache.commons.lang.StringUtils.stripStart(data, "0");

            if(data.indexOf(".") >= 0){
                len1 = data.indexOf(".");
                data = org.apache.commons.lang.StringUtils.stripEnd(data, "0");
                len2 = data.length() - (len1 + 1);
            }else{
                len1 = data.length();
            }

            if (iPrecision < len2) {
                ifPassed = false;
                errorCode += 8;
                errorMessage += "|precision Non-matches";
            } else if (maxLength < len1 + iPrecision) {
                ifPassed = false;
                errorCode += 8;
                errorMessage += "|invalid Length setting is unsuitable for Precision";
            }
        }

        int handleErrorCode(int errorCode, int resultErrorCode){
            if (errorCode > 0) {
                if (resultErrorCode > 0) {
                    resultErrorCode = 16;
                } else {
                    resultErrorCode = errorCode;
                }
            }
            return resultErrorCode;
        }

        String handleErrorMessage(String errorMessage, String resultErrorMessage, String columnLabel){
            if (errorMessage.length() > 0) {
                if (resultErrorMessage.length() > 0) {
                    resultErrorMessage += ";"+ errorMessage.replaceFirst("\\|", columnLabel);
                } else {
                    resultErrorMessage = errorMessage.replaceFirst("\\|", columnLabel);
                }
            }
            return resultErrorMessage;
        }

        void reset(){
            ifPassedThrough = true;
            errorCodeThrough = 0;
            errorMessageThrough = "";
            resultErrorCodeThrough = 0;
            resultErrorMessageThrough = "";
            tmpContentThrough = null;

            ifPassed = true;
            errorCode = 0;
            errorMessage = "";
        }

        void setRowValue_0(row23Struct row23) {
    // validate nullable (empty as null)
    if ((row23.IDBillet == null) || ("".equals(row23.IDBillet))) {
        ifPassedThrough = false;
        errorCodeThrough += 4;
        errorMessageThrough += "|empty or null";
    }
            resultErrorCodeThrough = handleErrorCode(errorCodeThrough,resultErrorCodeThrough);
            errorCodeThrough = 0;
            resultErrorMessageThrough = handleErrorMessage(errorMessageThrough,resultErrorMessageThrough,"IDBillet:");
            errorMessageThrough = "";
    // validate nullable (empty as null)
    if ((row23.IDCanal == null) || ("".equals(row23.IDCanal))) {
        ifPassedThrough = false;
        errorCodeThrough += 4;
        errorMessageThrough += "|empty or null";
    }
            resultErrorCodeThrough = handleErrorCode(errorCodeThrough,resultErrorCodeThrough);
            errorCodeThrough = 0;
            resultErrorMessageThrough = handleErrorMessage(errorMessageThrough,resultErrorMessageThrough,"IDCanal:");
            errorMessageThrough = "";
    // validate nullable (empty as null)
    if ((row23.IDVol == null) || ("".equals(row23.IDVol))) {
        ifPassedThrough = false;
        errorCodeThrough += 4;
        errorMessageThrough += "|empty or null";
    }    try {
        if(
        row23.IDVol != null
        ) {
            String tester_tSchemaComplianceCheck_8 = String.valueOf(row23.IDVol);
        }
    } catch(java.lang.Exception e) {
globalMap.put("tSchemaComplianceCheck_8_ERROR_MESSAGE",e.getMessage());
        ifPassedThrough = false;
        errorCodeThrough += 2;
        errorMessageThrough += "|wrong type";
    }
            resultErrorCodeThrough = handleErrorCode(errorCodeThrough,resultErrorCodeThrough);
            errorCodeThrough = 0;
            resultErrorMessageThrough = handleErrorMessage(errorMessageThrough,resultErrorMessageThrough,"IDVol:");
            errorMessageThrough = "";
    // validate nullable (empty as null)
    if ((row23.TarifBase == null) || ("".equals(row23.TarifBase))) {
        ifPassedThrough = false;
        errorCodeThrough += 4;
        errorMessageThrough += "|empty or null";
    }
            resultErrorCodeThrough = handleErrorCode(errorCodeThrough,resultErrorCodeThrough);
            errorCodeThrough = 0;
            resultErrorMessageThrough = handleErrorMessage(errorMessageThrough,resultErrorMessageThrough,"TarifBase:");
            errorMessageThrough = "";
    // validate nullable (empty as null)
    if ((row23.PrixAchat == null) || ("".equals(row23.PrixAchat))) {
        ifPassedThrough = false;
        errorCodeThrough += 4;
        errorMessageThrough += "|empty or null";
    }
            resultErrorCodeThrough = handleErrorCode(errorCodeThrough,resultErrorCodeThrough);
            errorCodeThrough = 0;
            resultErrorMessageThrough = handleErrorMessage(errorMessageThrough,resultErrorMessageThrough,"PrixAchat:");
            errorMessageThrough = "";
    // validate nullable (empty as null)
    if ((row23.DateAchat == null) || ("".equals(row23.DateAchat))) {
        ifPassedThrough = false;
        errorCodeThrough += 4;
        errorMessageThrough += "|empty or null";
    }    try {
        if(
        row23.DateAchat != null
        ) {
            String tester_tSchemaComplianceCheck_8 = String.valueOf(row23.DateAchat);
        }
    } catch(java.lang.Exception e) {
globalMap.put("tSchemaComplianceCheck_8_ERROR_MESSAGE",e.getMessage());
        ifPassedThrough = false;
        errorCodeThrough += 2;
        errorMessageThrough += "|wrong type";
    }
            resultErrorCodeThrough = handleErrorCode(errorCodeThrough,resultErrorCodeThrough);
            errorCodeThrough = 0;
            resultErrorMessageThrough = handleErrorMessage(errorMessageThrough,resultErrorMessageThrough,"DateAchat:");
            errorMessageThrough = "";
    // validate nullable (empty as null)
    if ((row23.Classe == null) || ("".equals(row23.Classe))) {
        ifPassedThrough = false;
        errorCodeThrough += 4;
        errorMessageThrough += "|empty or null";
    }    try {
        if(
        row23.Classe != null
        ) {
            String tester_tSchemaComplianceCheck_8 = String.valueOf(row23.Classe);
        }
    } catch(java.lang.Exception e) {
globalMap.put("tSchemaComplianceCheck_8_ERROR_MESSAGE",e.getMessage());
        ifPassedThrough = false;
        errorCodeThrough += 2;
        errorMessageThrough += "|wrong type";
    }
            resultErrorCodeThrough = handleErrorCode(errorCodeThrough,resultErrorCodeThrough);
            errorCodeThrough = 0;
            resultErrorMessageThrough = handleErrorMessage(errorMessageThrough,resultErrorMessageThrough,"Classe:");
            errorMessageThrough = "";
    // validate nullable (empty as null)
    if ((row23.Status == null) || ("".equals(row23.Status))) {
        ifPassedThrough = false;
        errorCodeThrough += 4;
        errorMessageThrough += "|empty or null";
    }    try {
        if(
        row23.Status != null
        ) {
            String tester_tSchemaComplianceCheck_8 = String.valueOf(row23.Status);
        }
    } catch(java.lang.Exception e) {
globalMap.put("tSchemaComplianceCheck_8_ERROR_MESSAGE",e.getMessage());
        ifPassedThrough = false;
        errorCodeThrough += 2;
        errorMessageThrough += "|wrong type";
    }
            resultErrorCodeThrough = handleErrorCode(errorCodeThrough,resultErrorCodeThrough);
            errorCodeThrough = 0;
            resultErrorMessageThrough = handleErrorMessage(errorMessageThrough,resultErrorMessageThrough,"Status:");
            errorMessageThrough = "";
        }
    }
    RowSetValueUtil_tSchemaComplianceCheck_8 rsvUtil_tSchemaComplianceCheck_8 = new RowSetValueUtil_tSchemaComplianceCheck_8();

 



/**
 * [tSchemaComplianceCheck_8 begin ] stop
 */



	
	/**
	 * [tUniqRow_8 begin ] start
	 */

	

	
		
		ok_Hash.put("tUniqRow_8", false);
		start_Hash.put("tUniqRow_8", System.currentTimeMillis());
		
	
	currentComponent="tUniqRow_8";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row22");
					}
				
		int tos_count_tUniqRow_8 = 0;
		

	
		class KeyStruct_tUniqRow_8 {
	
			private static final int DEFAULT_HASHCODE = 1;
		    private static final int PRIME = 31;
		    private int hashCode = DEFAULT_HASHCODE;
		    public boolean hashCodeDirty = true;
	
	        
					Integer IDBillet;        
	        
		    @Override
			public int hashCode() {
				if (this.hashCodeDirty) {
					final int prime = PRIME;
					int result = DEFAULT_HASHCODE;
			
								result = prime * result + ((this.IDBillet == null) ? 0 : this.IDBillet.hashCode());
								
		    		this.hashCode = result;
		    		this.hashCodeDirty = false;		
				}
				return this.hashCode;
			}
			
			@Override
			public boolean equals(Object obj) {
				if (this == obj) return true;
				if (obj == null) return false;
				if (getClass() != obj.getClass()) return false;
				final KeyStruct_tUniqRow_8 other = (KeyStruct_tUniqRow_8) obj;
				
									if (this.IDBillet == null) {
										if (other.IDBillet != null) 
											return false;
								
									} else if (!this.IDBillet.equals(other.IDBillet))
								 
										return false;
								
				
				return true;
			}
	  
	        
		}

	
int nb_uniques_tUniqRow_8 = 0;
int nb_duplicates_tUniqRow_8 = 0;
KeyStruct_tUniqRow_8 finder_tUniqRow_8 = new KeyStruct_tUniqRow_8();
java.util.Set<KeyStruct_tUniqRow_8> keystUniqRow_8 = new java.util.HashSet<KeyStruct_tUniqRow_8>(); 

 



/**
 * [tUniqRow_8 begin ] stop
 */



	
	/**
	 * [tFileInputDelimited_8 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileInputDelimited_8", false);
		start_Hash.put("tFileInputDelimited_8", System.currentTimeMillis());
		
	
	currentComponent="tFileInputDelimited_8";

	
		int tos_count_tFileInputDelimited_8 = 0;
		
	
	
	
 
	
	
	final routines.system.RowState rowstate_tFileInputDelimited_8 = new routines.system.RowState();
	
	
				int nb_line_tFileInputDelimited_8 = 0;
				org.talend.fileprocess.FileInputDelimited fid_tFileInputDelimited_8 = null;
				int limit_tFileInputDelimited_8 = -1;
				try{
					
						Object filename_tFileInputDelimited_8 = context.source_path+"billet.csv";
						if(filename_tFileInputDelimited_8 instanceof java.io.InputStream){
							
			int footer_value_tFileInputDelimited_8 = 0, random_value_tFileInputDelimited_8 = -1;
			if(footer_value_tFileInputDelimited_8 >0 || random_value_tFileInputDelimited_8 > 0){
				throw new java.lang.Exception("When the input source is a stream,footer and random shouldn't be bigger than 0.");				
			}
		
						}
						try {
							fid_tFileInputDelimited_8 = new org.talend.fileprocess.FileInputDelimited(context.source_path+"billet.csv", "UTF-8",";","\n",false,1,0,
									limit_tFileInputDelimited_8
								,-1, false);
						} catch(java.lang.Exception e) {
globalMap.put("tFileInputDelimited_8_ERROR_MESSAGE",e.getMessage());
							
								
								System.err.println(e.getMessage());
							
						}
					
				    
					while (fid_tFileInputDelimited_8!=null && fid_tFileInputDelimited_8.nextRecord()) {
						rowstate_tFileInputDelimited_8.reset();
						
			    						row22 = null;			
												
									boolean whetherReject_tFileInputDelimited_8 = false;
									row22 = new row22Struct();
									try {
										
				int columnIndexWithD_tFileInputDelimited_8 = 0;
				
					String temp = ""; 
				
					columnIndexWithD_tFileInputDelimited_8 = 0;
					
						temp = fid_tFileInputDelimited_8.get(columnIndexWithD_tFileInputDelimited_8);
						if(temp.length() > 0) {
							
								try {
								
    								row22.IDBillet = ParserUtils.parseTo_Integer(temp);
    							
    							} catch(java.lang.Exception ex_tFileInputDelimited_8) {
globalMap.put("tFileInputDelimited_8_ERROR_MESSAGE",ex_tFileInputDelimited_8.getMessage());
									rowstate_tFileInputDelimited_8.setException(new RuntimeException(String.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
										"IDBillet", "row22", temp, ex_tFileInputDelimited_8), ex_tFileInputDelimited_8));
								}
    							
						} else {						
							
								
									row22.IDBillet = null;
								
							
						}
					
				
					columnIndexWithD_tFileInputDelimited_8 = 1;
					
						temp = fid_tFileInputDelimited_8.get(columnIndexWithD_tFileInputDelimited_8);
						if(temp.length() > 0) {
							
								try {
								
    								row22.IDCanal = ParserUtils.parseTo_Integer(temp);
    							
    							} catch(java.lang.Exception ex_tFileInputDelimited_8) {
globalMap.put("tFileInputDelimited_8_ERROR_MESSAGE",ex_tFileInputDelimited_8.getMessage());
									rowstate_tFileInputDelimited_8.setException(new RuntimeException(String.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
										"IDCanal", "row22", temp, ex_tFileInputDelimited_8), ex_tFileInputDelimited_8));
								}
    							
						} else {						
							
								
									row22.IDCanal = null;
								
							
						}
					
				
					columnIndexWithD_tFileInputDelimited_8 = 2;
					
							row22.IDVol = fid_tFileInputDelimited_8.get(columnIndexWithD_tFileInputDelimited_8);
						
				
					columnIndexWithD_tFileInputDelimited_8 = 3;
					
						temp = fid_tFileInputDelimited_8.get(columnIndexWithD_tFileInputDelimited_8);
						if(temp.length() > 0) {
							
								try {
								
    								row22.TarifBase = ParserUtils.parseTo_Float(temp);
    							
    							} catch(java.lang.Exception ex_tFileInputDelimited_8) {
globalMap.put("tFileInputDelimited_8_ERROR_MESSAGE",ex_tFileInputDelimited_8.getMessage());
									rowstate_tFileInputDelimited_8.setException(new RuntimeException(String.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
										"TarifBase", "row22", temp, ex_tFileInputDelimited_8), ex_tFileInputDelimited_8));
								}
    							
						} else {						
							
								
									row22.TarifBase = null;
								
							
						}
					
				
					columnIndexWithD_tFileInputDelimited_8 = 4;
					
						temp = fid_tFileInputDelimited_8.get(columnIndexWithD_tFileInputDelimited_8);
						if(temp.length() > 0) {
							
								try {
								
    								row22.PrixAchat = ParserUtils.parseTo_Float(temp);
    							
    							} catch(java.lang.Exception ex_tFileInputDelimited_8) {
globalMap.put("tFileInputDelimited_8_ERROR_MESSAGE",ex_tFileInputDelimited_8.getMessage());
									rowstate_tFileInputDelimited_8.setException(new RuntimeException(String.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
										"PrixAchat", "row22", temp, ex_tFileInputDelimited_8), ex_tFileInputDelimited_8));
								}
    							
						} else {						
							
								
									row22.PrixAchat = null;
								
							
						}
					
				
					columnIndexWithD_tFileInputDelimited_8 = 5;
					
							row22.DateAchat = fid_tFileInputDelimited_8.get(columnIndexWithD_tFileInputDelimited_8);
						
				
					columnIndexWithD_tFileInputDelimited_8 = 6;
					
							row22.Classe = fid_tFileInputDelimited_8.get(columnIndexWithD_tFileInputDelimited_8);
						
				
					columnIndexWithD_tFileInputDelimited_8 = 7;
					
							row22.Status = fid_tFileInputDelimited_8.get(columnIndexWithD_tFileInputDelimited_8);
						
				
				
										
										if(rowstate_tFileInputDelimited_8.getException()!=null) {
											throw rowstate_tFileInputDelimited_8.getException();
										}
										
										
							
			    					} catch (java.lang.Exception e) {
globalMap.put("tFileInputDelimited_8_ERROR_MESSAGE",e.getMessage());
			        					whetherReject_tFileInputDelimited_8 = true;
			        					
			                					System.err.println(e.getMessage());
			                					row22 = null;
			                				
										
			    					}
								

 



/**
 * [tFileInputDelimited_8 begin ] stop
 */
	
	/**
	 * [tFileInputDelimited_8 main ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_8";

	

 


	tos_count_tFileInputDelimited_8++;

/**
 * [tFileInputDelimited_8 main ] stop
 */
	
	/**
	 * [tFileInputDelimited_8 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_8";

	

 



/**
 * [tFileInputDelimited_8 process_data_begin ] stop
 */
// Start of branch "row22"
if(row22 != null) { 



	
	/**
	 * [tUniqRow_8 main ] start
	 */

	

	
	
	currentComponent="tUniqRow_8";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row22"
						
						);
					}
					
row23 = null;			
finder_tUniqRow_8.IDBillet = row22.IDBillet;	
finder_tUniqRow_8.hashCodeDirty = true;
if (!keystUniqRow_8.contains(finder_tUniqRow_8)) {
		KeyStruct_tUniqRow_8 new_tUniqRow_8 = new KeyStruct_tUniqRow_8();

		
new_tUniqRow_8.IDBillet = row22.IDBillet;
		
		keystUniqRow_8.add(new_tUniqRow_8);if(row23 == null){ 
	
	row23 = new row23Struct();
}row23.IDBillet = row22.IDBillet;			row23.IDCanal = row22.IDCanal;			row23.IDVol = row22.IDVol;			row23.TarifBase = row22.TarifBase;			row23.PrixAchat = row22.PrixAchat;			row23.DateAchat = row22.DateAchat;			row23.Classe = row22.Classe;			row23.Status = row22.Status;					
		nb_uniques_tUniqRow_8++;
	} else {
	  nb_duplicates_tUniqRow_8++;
	}

 


	tos_count_tUniqRow_8++;

/**
 * [tUniqRow_8 main ] stop
 */
	
	/**
	 * [tUniqRow_8 process_data_begin ] start
	 */

	

	
	
	currentComponent="tUniqRow_8";

	

 



/**
 * [tUniqRow_8 process_data_begin ] stop
 */
// Start of branch "row23"
if(row23 != null) { 



	
	/**
	 * [tSchemaComplianceCheck_8 main ] start
	 */

	

	
	
	currentComponent="tSchemaComplianceCheck_8";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row23"
						
						);
					}
					
	row24 = null;
	rsvUtil_tSchemaComplianceCheck_8.setRowValue_0(row23);
	if (rsvUtil_tSchemaComplianceCheck_8.ifPassedThrough) {
		row24 = new row24Struct();
		row24.IDBillet = row23.IDBillet;
		row24.IDCanal = row23.IDCanal;
		row24.IDVol = row23.IDVol;
		row24.TarifBase = row23.TarifBase;
		row24.PrixAchat = row23.PrixAchat;
		row24.DateAchat = row23.DateAchat;
		row24.Classe = row23.Classe;
		row24.Status = row23.Status;
	}
	rsvUtil_tSchemaComplianceCheck_8.reset();

 


	tos_count_tSchemaComplianceCheck_8++;

/**
 * [tSchemaComplianceCheck_8 main ] stop
 */
	
	/**
	 * [tSchemaComplianceCheck_8 process_data_begin ] start
	 */

	

	
	
	currentComponent="tSchemaComplianceCheck_8";

	

 



/**
 * [tSchemaComplianceCheck_8 process_data_begin ] stop
 */
// Start of branch "row24"
if(row24 != null) { 



	
	/**
	 * [tMap_3 main ] start
	 */

	

	
	
	currentComponent="tMap_3";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row24"
						
						);
					}
					

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_3 = false;
		

        // ###############################
        // # Input tables (lookups)
		  boolean rejectedInnerJoin_tMap_3 = false;
		  boolean mainRowRejected_tMap_3 = false;
            				    								  
		// ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_3__Struct Var = Var__tMap_3;// ###############################
        // ###############################
        // # Output tables

STG_BILLET = null;


// # Output table : 'STG_BILLET'
STG_BILLET_tmp.ID_BILLET = row24.IDBillet ;
STG_BILLET_tmp.SK_CANAL_ID = row24.IDCanal ;
STG_BILLET_tmp.SK_VOL_ID = row24.IDVol ;
STG_BILLET_tmp.TARIF_BASE = row24.TarifBase ;
STG_BILLET_tmp.PRIX_ACHAT = row24.PrixAchat ;
STG_BILLET_tmp.DATE_ACHAT = row24.DateAchat != null && row24.DateAchat.matches("\\d{2}/\\d{2}/\\d{4}") ? TalendDate.parseDate("dd/MM/yyyy", row24.DateAchat) : null ;
STG_BILLET_tmp.CLASSE = row24.Classe ;
STG_BILLET_tmp.STATUS = row24.Status ;
STG_BILLET = STG_BILLET_tmp;
// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_3 = false;










 


	tos_count_tMap_3++;

/**
 * [tMap_3 main ] stop
 */
	
	/**
	 * [tMap_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tMap_3";

	

 



/**
 * [tMap_3 process_data_begin ] stop
 */
// Start of branch "STG_BILLET"
if(STG_BILLET != null) { 



	
	/**
	 * [tDBOutput_8 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_8";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"STG_BILLET"
						
						);
					}
					



        whetherReject_tDBOutput_8 = false;
                    pstmt_tDBOutput_8.setInt(1, STG_BILLET.ID_BILLET);

            int checkCount_tDBOutput_8 = -1;
            try (java.sql.ResultSet rs_tDBOutput_8 = pstmt_tDBOutput_8.executeQuery()) {
                while(rs_tDBOutput_8.next()) {
                    checkCount_tDBOutput_8 = rs_tDBOutput_8.getInt(1);
                }
            }
            if(checkCount_tDBOutput_8 > 0) {
                        pstmtUpdate_tDBOutput_8.setInt(1, STG_BILLET.SK_CANAL_ID);

                        if(STG_BILLET.SK_VOL_ID == null) {
pstmtUpdate_tDBOutput_8.setNull(2, java.sql.Types.VARCHAR);
} else {pstmtUpdate_tDBOutput_8.setString(2, STG_BILLET.SK_VOL_ID);
}

                        pstmtUpdate_tDBOutput_8.setFloat(3, STG_BILLET.TARIF_BASE);

                        pstmtUpdate_tDBOutput_8.setFloat(4, STG_BILLET.PRIX_ACHAT);

                        if(STG_BILLET.DATE_ACHAT != null) {
pstmtUpdate_tDBOutput_8.setObject(5, new java.sql.Timestamp(STG_BILLET.DATE_ACHAT.getTime()),java.sql.Types.DATE);
} else {
pstmtUpdate_tDBOutput_8.setNull(5, java.sql.Types.DATE);
}

                        if(STG_BILLET.CLASSE == null) {
pstmtUpdate_tDBOutput_8.setNull(6, java.sql.Types.VARCHAR);
} else {pstmtUpdate_tDBOutput_8.setString(6, STG_BILLET.CLASSE);
}

                        if(STG_BILLET.STATUS == null) {
pstmtUpdate_tDBOutput_8.setNull(7, java.sql.Types.VARCHAR);
} else {pstmtUpdate_tDBOutput_8.setString(7, STG_BILLET.STATUS);
}

                        pstmtUpdate_tDBOutput_8.setInt(8 + count_tDBOutput_8, STG_BILLET.ID_BILLET);

                try {
                    int processedCount_tDBOutput_8 = pstmtUpdate_tDBOutput_8.executeUpdate();
                    updatedCount_tDBOutput_8 += processedCount_tDBOutput_8;
                    rowsToCommitCount_tDBOutput_8 += processedCount_tDBOutput_8;
                    nb_line_tDBOutput_8++;
                } catch(java.lang.Exception e_tDBOutput_8) {
globalMap.put("tDBOutput_8_ERROR_MESSAGE",e_tDBOutput_8.getMessage());
                    whetherReject_tDBOutput_8 = true;
                        nb_line_tDBOutput_8++;
                            System.err.print(e_tDBOutput_8.getMessage());
                }
            } else {
                        pstmtInsert_tDBOutput_8.setInt(1, STG_BILLET.ID_BILLET);

                        pstmtInsert_tDBOutput_8.setInt(2, STG_BILLET.SK_CANAL_ID);

                        if(STG_BILLET.SK_VOL_ID == null) {
pstmtInsert_tDBOutput_8.setNull(3, java.sql.Types.VARCHAR);
} else {pstmtInsert_tDBOutput_8.setString(3, STG_BILLET.SK_VOL_ID);
}

                        pstmtInsert_tDBOutput_8.setFloat(4, STG_BILLET.TARIF_BASE);

                        pstmtInsert_tDBOutput_8.setFloat(5, STG_BILLET.PRIX_ACHAT);

                        if(STG_BILLET.DATE_ACHAT != null) {
pstmtInsert_tDBOutput_8.setObject(6, new java.sql.Timestamp(STG_BILLET.DATE_ACHAT.getTime()),java.sql.Types.DATE);
} else {
pstmtInsert_tDBOutput_8.setNull(6, java.sql.Types.DATE);
}

                        if(STG_BILLET.CLASSE == null) {
pstmtInsert_tDBOutput_8.setNull(7, java.sql.Types.VARCHAR);
} else {pstmtInsert_tDBOutput_8.setString(7, STG_BILLET.CLASSE);
}

                        if(STG_BILLET.STATUS == null) {
pstmtInsert_tDBOutput_8.setNull(8, java.sql.Types.VARCHAR);
} else {pstmtInsert_tDBOutput_8.setString(8, STG_BILLET.STATUS);
}

                try {
                    int processedCount_tDBOutput_8 = pstmtInsert_tDBOutput_8.executeUpdate();
                    insertedCount_tDBOutput_8 += processedCount_tDBOutput_8;
                    rowsToCommitCount_tDBOutput_8 += processedCount_tDBOutput_8;
                    nb_line_tDBOutput_8++;
                } catch(java.lang.Exception e_tDBOutput_8) {
globalMap.put("tDBOutput_8_ERROR_MESSAGE",e_tDBOutput_8.getMessage());
                    whetherReject_tDBOutput_8 = true;
                        nb_line_tDBOutput_8++;
                            System.err.print(e_tDBOutput_8.getMessage());
                }
            }

 


	tos_count_tDBOutput_8++;

/**
 * [tDBOutput_8 main ] stop
 */
	
	/**
	 * [tDBOutput_8 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_8";

	

 



/**
 * [tDBOutput_8 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_8 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_8";

	

 



/**
 * [tDBOutput_8 process_data_end ] stop
 */

} // End of branch "STG_BILLET"




	
	/**
	 * [tMap_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tMap_3";

	

 



/**
 * [tMap_3 process_data_end ] stop
 */

} // End of branch "row24"




	
	/**
	 * [tSchemaComplianceCheck_8 process_data_end ] start
	 */

	

	
	
	currentComponent="tSchemaComplianceCheck_8";

	

 



/**
 * [tSchemaComplianceCheck_8 process_data_end ] stop
 */

} // End of branch "row23"




	
	/**
	 * [tUniqRow_8 process_data_end ] start
	 */

	

	
	
	currentComponent="tUniqRow_8";

	

 



/**
 * [tUniqRow_8 process_data_end ] stop
 */

} // End of branch "row22"




	
	/**
	 * [tFileInputDelimited_8 process_data_end ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_8";

	

 



/**
 * [tFileInputDelimited_8 process_data_end ] stop
 */
	
	/**
	 * [tFileInputDelimited_8 end ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_8";

	



            }
            }finally{
                if(!((Object)(context.source_path+"billet.csv") instanceof java.io.InputStream)){
                	if(fid_tFileInputDelimited_8!=null){
                		fid_tFileInputDelimited_8.close();
                	}
                }
                if(fid_tFileInputDelimited_8!=null){
                	globalMap.put("tFileInputDelimited_8_NB_LINE", fid_tFileInputDelimited_8.getRowNumber());
					
                }
			}
			  

 

ok_Hash.put("tFileInputDelimited_8", true);
end_Hash.put("tFileInputDelimited_8", System.currentTimeMillis());




/**
 * [tFileInputDelimited_8 end ] stop
 */

	
	/**
	 * [tUniqRow_8 end ] start
	 */

	

	
	
	currentComponent="tUniqRow_8";

	

globalMap.put("tUniqRow_8_NB_UNIQUES",nb_uniques_tUniqRow_8);
globalMap.put("tUniqRow_8_NB_DUPLICATES",nb_duplicates_tUniqRow_8);

				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row22");
			  	}
			  	
 

ok_Hash.put("tUniqRow_8", true);
end_Hash.put("tUniqRow_8", System.currentTimeMillis());




/**
 * [tUniqRow_8 end ] stop
 */

	
	/**
	 * [tSchemaComplianceCheck_8 end ] start
	 */

	

	
	
	currentComponent="tSchemaComplianceCheck_8";

	

				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row23");
			  	}
			  	
 

ok_Hash.put("tSchemaComplianceCheck_8", true);
end_Hash.put("tSchemaComplianceCheck_8", System.currentTimeMillis());




/**
 * [tSchemaComplianceCheck_8 end ] stop
 */

	
	/**
	 * [tMap_3 end ] start
	 */

	

	
	
	currentComponent="tMap_3";

	


// ###############################
// # Lookup hashes releasing
// ###############################      





				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row24");
			  	}
			  	
 

ok_Hash.put("tMap_3", true);
end_Hash.put("tMap_3", System.currentTimeMillis());




/**
 * [tMap_3 end ] stop
 */

	
	/**
	 * [tDBOutput_8 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_8";

	
	



	
        if(pstmtUpdate_tDBOutput_8 != null){
            pstmtUpdate_tDBOutput_8.close();
            resourceMap.remove("pstmtUpdate_tDBOutput_8");
        }
        if(pstmtInsert_tDBOutput_8 != null){
            pstmtInsert_tDBOutput_8.close();
            resourceMap.remove("pstmtInsert_tDBOutput_8");
        }
        if(pstmt_tDBOutput_8 != null) {
            pstmt_tDBOutput_8.close();
            resourceMap.remove("pstmt_tDBOutput_8");
        }
    resourceMap.put("statementClosed_tDBOutput_8", true);

	
	nb_line_deleted_tDBOutput_8=nb_line_deleted_tDBOutput_8+ deletedCount_tDBOutput_8;
	nb_line_update_tDBOutput_8=nb_line_update_tDBOutput_8 + updatedCount_tDBOutput_8;
	nb_line_inserted_tDBOutput_8=nb_line_inserted_tDBOutput_8 + insertedCount_tDBOutput_8;
	nb_line_rejected_tDBOutput_8=nb_line_rejected_tDBOutput_8 + rejectedCount_tDBOutput_8;
	
        globalMap.put("tDBOutput_8_NB_LINE",nb_line_tDBOutput_8);
        globalMap.put("tDBOutput_8_NB_LINE_UPDATED",nb_line_update_tDBOutput_8);
        globalMap.put("tDBOutput_8_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_8);
        globalMap.put("tDBOutput_8_NB_LINE_DELETED",nb_line_deleted_tDBOutput_8);
        globalMap.put("tDBOutput_8_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_8);
    

	



				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"STG_BILLET");
			  	}
			  	
 

ok_Hash.put("tDBOutput_8", true);
end_Hash.put("tDBOutput_8", System.currentTimeMillis());




/**
 * [tDBOutput_8 end ] stop
 */












				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tFileInputDelimited_8:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk11", 0, "ok");
								} 
							
							tFileInputDelimited_9Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFileInputDelimited_8 finally ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_8";

	

 



/**
 * [tFileInputDelimited_8 finally ] stop
 */

	
	/**
	 * [tUniqRow_8 finally ] start
	 */

	

	
	
	currentComponent="tUniqRow_8";

	

 



/**
 * [tUniqRow_8 finally ] stop
 */

	
	/**
	 * [tSchemaComplianceCheck_8 finally ] start
	 */

	

	
	
	currentComponent="tSchemaComplianceCheck_8";

	

 



/**
 * [tSchemaComplianceCheck_8 finally ] stop
 */

	
	/**
	 * [tMap_3 finally ] start
	 */

	

	
	
	currentComponent="tMap_3";

	

 



/**
 * [tMap_3 finally ] stop
 */

	
	/**
	 * [tDBOutput_8 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_8";

	



    if (resourceMap.get("statementClosed_tDBOutput_8") == null) {
                java.sql.PreparedStatement pstmtUpdateToClose_tDBOutput_8 = null;
                if ((pstmtUpdateToClose_tDBOutput_8 = (java.sql.PreparedStatement) resourceMap.remove("pstmtUpdate_tDBOutput_8")) != null) {
                    pstmtUpdateToClose_tDBOutput_8.close();
                }
                java.sql.PreparedStatement pstmtInsertToClose_tDBOutput_8 = null;
                if ((pstmtInsertToClose_tDBOutput_8 = (java.sql.PreparedStatement) resourceMap.remove("pstmtInsert_tDBOutput_8")) != null) {
                    pstmtInsertToClose_tDBOutput_8.close();
                }
                java.sql.PreparedStatement pstmtToClose_tDBOutput_8 = null;
                if ((pstmtToClose_tDBOutput_8 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_8")) != null) {
                    pstmtToClose_tDBOutput_8.close();
                }
    }
 



/**
 * [tDBOutput_8 finally ] stop
 */












				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFileInputDelimited_8_SUBPROCESS_STATE", 1);
	}
	


public static class STG_FAIT_PROMOStruct implements routines.system.IPersistableRow<STG_FAIT_PROMOStruct> {
    final static byte[] commonByteArrayLock_LOCAL_PROJECT_STG_Load = new byte[0];
    static byte[] commonByteArray_LOCAL_PROJECT_STG_Load = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int ID_PROMO;

				public int getID_PROMO () {
					return this.ID_PROMO;
				}
				
			    public int SK_BILLET_ID;

				public int getSK_BILLET_ID () {
					return this.SK_BILLET_ID;
				}
				
			    public int SK_PROMOTION_ID;

				public int getSK_PROMOTION_ID () {
					return this.SK_PROMOTION_ID;
				}
				
			    public float TAUX_PROMOTION;

				public float getTAUX_PROMOTION () {
					return this.TAUX_PROMOTION;
				}
				
			    public java.util.Date DATE_DEBUT;

				public java.util.Date getDATE_DEBUT () {
					return this.DATE_DEBUT;
				}
				
			    public java.util.Date DATE_FIN;

				public java.util.Date getDATE_FIN () {
					return this.DATE_FIN;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.ID_PROMO;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final STG_FAIT_PROMOStruct other = (STG_FAIT_PROMOStruct) obj;
		
						if (this.ID_PROMO != other.ID_PROMO)
							return false;
					

		return true;
    }

	public void copyDataTo(STG_FAIT_PROMOStruct other) {

		other.ID_PROMO = this.ID_PROMO;
	            other.SK_BILLET_ID = this.SK_BILLET_ID;
	            other.SK_PROMOTION_ID = this.SK_PROMOTION_ID;
	            other.TAUX_PROMOTION = this.TAUX_PROMOTION;
	            other.DATE_DEBUT = this.DATE_DEBUT;
	            other.DATE_FIN = this.DATE_FIN;
	            
	}

	public void copyKeysDataTo(STG_FAIT_PROMOStruct other) {

		other.ID_PROMO = this.ID_PROMO;
	            	
	}




	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
			        this.ID_PROMO = dis.readInt();
					
			        this.SK_BILLET_ID = dis.readInt();
					
			        this.SK_PROMOTION_ID = dis.readInt();
					
			        this.TAUX_PROMOTION = dis.readFloat();
					
					this.DATE_DEBUT = readDate(dis);
					
					this.DATE_FIN = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
			        this.ID_PROMO = dis.readInt();
					
			        this.SK_BILLET_ID = dis.readInt();
					
			        this.SK_PROMOTION_ID = dis.readInt();
					
			        this.TAUX_PROMOTION = dis.readFloat();
					
					this.DATE_DEBUT = readDate(dis);
					
					this.DATE_FIN = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.ID_PROMO);
					
					// int
				
		            	dos.writeInt(this.SK_BILLET_ID);
					
					// int
				
		            	dos.writeInt(this.SK_PROMOTION_ID);
					
					// float
				
		            	dos.writeFloat(this.TAUX_PROMOTION);
					
					// java.util.Date
				
						writeDate(this.DATE_DEBUT,dos);
					
					// java.util.Date
				
						writeDate(this.DATE_FIN,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.ID_PROMO);
					
					// int
				
		            	dos.writeInt(this.SK_BILLET_ID);
					
					// int
				
		            	dos.writeInt(this.SK_PROMOTION_ID);
					
					// float
				
		            	dos.writeFloat(this.TAUX_PROMOTION);
					
					// java.util.Date
				
						writeDate(this.DATE_DEBUT,dos);
					
					// java.util.Date
				
						writeDate(this.DATE_FIN,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("ID_PROMO="+String.valueOf(ID_PROMO));
		sb.append(",SK_BILLET_ID="+String.valueOf(SK_BILLET_ID));
		sb.append(",SK_PROMOTION_ID="+String.valueOf(SK_PROMOTION_ID));
		sb.append(",TAUX_PROMOTION="+String.valueOf(TAUX_PROMOTION));
		sb.append(",DATE_DEBUT="+String.valueOf(DATE_DEBUT));
		sb.append(",DATE_FIN="+String.valueOf(DATE_FIN));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(STG_FAIT_PROMOStruct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.ID_PROMO, other.ID_PROMO);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row27Struct implements routines.system.IPersistableRow<row27Struct> {
    final static byte[] commonByteArrayLock_LOCAL_PROJECT_STG_Load = new byte[0];
    static byte[] commonByteArray_LOCAL_PROJECT_STG_Load = new byte[0];

	
			    public Integer IDPromo;

				public Integer getIDPromo () {
					return this.IDPromo;
				}
				
			    public Integer IDBillet;

				public Integer getIDBillet () {
					return this.IDBillet;
				}
				
			    public Integer IDPromotion;

				public Integer getIDPromotion () {
					return this.IDPromotion;
				}
				
			    public Float TauxPromotion;

				public Float getTauxPromotion () {
					return this.TauxPromotion;
				}
				
			    public java.util.Date DateDebut;

				public java.util.Date getDateDebut () {
					return this.DateDebut;
				}
				
			    public java.util.Date DateFin;

				public java.util.Date getDateFin () {
					return this.DateFin;
				}
				


	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
						this.IDPromo = readInteger(dis);
					
						this.IDBillet = readInteger(dis);
					
						this.IDPromotion = readInteger(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.TauxPromotion = null;
           				} else {
           			    	this.TauxPromotion = dis.readFloat();
           				}
					
					this.DateDebut = readDate(dis);
					
					this.DateFin = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
						this.IDPromo = readInteger(dis);
					
						this.IDBillet = readInteger(dis);
					
						this.IDPromotion = readInteger(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.TauxPromotion = null;
           				} else {
           			    	this.TauxPromotion = dis.readFloat();
           				}
					
					this.DateDebut = readDate(dis);
					
					this.DateFin = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.IDPromo,dos);
					
					// Integer
				
						writeInteger(this.IDBillet,dos);
					
					// Integer
				
						writeInteger(this.IDPromotion,dos);
					
					// Float
				
						if(this.TauxPromotion == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.TauxPromotion);
		            	}
					
					// java.util.Date
				
						writeDate(this.DateDebut,dos);
					
					// java.util.Date
				
						writeDate(this.DateFin,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// Integer
				
						writeInteger(this.IDPromo,dos);
					
					// Integer
				
						writeInteger(this.IDBillet,dos);
					
					// Integer
				
						writeInteger(this.IDPromotion,dos);
					
					// Float
				
						if(this.TauxPromotion == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.TauxPromotion);
		            	}
					
					// java.util.Date
				
						writeDate(this.DateDebut,dos);
					
					// java.util.Date
				
						writeDate(this.DateFin,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("IDPromo="+String.valueOf(IDPromo));
		sb.append(",IDBillet="+String.valueOf(IDBillet));
		sb.append(",IDPromotion="+String.valueOf(IDPromotion));
		sb.append(",TauxPromotion="+String.valueOf(TauxPromotion));
		sb.append(",DateDebut="+String.valueOf(DateDebut));
		sb.append(",DateFin="+String.valueOf(DateFin));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row27Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row26Struct implements routines.system.IPersistableRow<row26Struct> {
    final static byte[] commonByteArrayLock_LOCAL_PROJECT_STG_Load = new byte[0];
    static byte[] commonByteArray_LOCAL_PROJECT_STG_Load = new byte[0];

	
			    public Integer IDPromo;

				public Integer getIDPromo () {
					return this.IDPromo;
				}
				
			    public Integer IDBillet;

				public Integer getIDBillet () {
					return this.IDBillet;
				}
				
			    public Integer IDPromotion;

				public Integer getIDPromotion () {
					return this.IDPromotion;
				}
				
			    public Float TauxPromotion;

				public Float getTauxPromotion () {
					return this.TauxPromotion;
				}
				
			    public java.util.Date DateDebut;

				public java.util.Date getDateDebut () {
					return this.DateDebut;
				}
				
			    public java.util.Date DateFin;

				public java.util.Date getDateFin () {
					return this.DateFin;
				}
				


	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
						this.IDPromo = readInteger(dis);
					
						this.IDBillet = readInteger(dis);
					
						this.IDPromotion = readInteger(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.TauxPromotion = null;
           				} else {
           			    	this.TauxPromotion = dis.readFloat();
           				}
					
					this.DateDebut = readDate(dis);
					
					this.DateFin = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
						this.IDPromo = readInteger(dis);
					
						this.IDBillet = readInteger(dis);
					
						this.IDPromotion = readInteger(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.TauxPromotion = null;
           				} else {
           			    	this.TauxPromotion = dis.readFloat();
           				}
					
					this.DateDebut = readDate(dis);
					
					this.DateFin = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.IDPromo,dos);
					
					// Integer
				
						writeInteger(this.IDBillet,dos);
					
					// Integer
				
						writeInteger(this.IDPromotion,dos);
					
					// Float
				
						if(this.TauxPromotion == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.TauxPromotion);
		            	}
					
					// java.util.Date
				
						writeDate(this.DateDebut,dos);
					
					// java.util.Date
				
						writeDate(this.DateFin,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// Integer
				
						writeInteger(this.IDPromo,dos);
					
					// Integer
				
						writeInteger(this.IDBillet,dos);
					
					// Integer
				
						writeInteger(this.IDPromotion,dos);
					
					// Float
				
						if(this.TauxPromotion == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.TauxPromotion);
		            	}
					
					// java.util.Date
				
						writeDate(this.DateDebut,dos);
					
					// java.util.Date
				
						writeDate(this.DateFin,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("IDPromo="+String.valueOf(IDPromo));
		sb.append(",IDBillet="+String.valueOf(IDBillet));
		sb.append(",IDPromotion="+String.valueOf(IDPromotion));
		sb.append(",TauxPromotion="+String.valueOf(TauxPromotion));
		sb.append(",DateDebut="+String.valueOf(DateDebut));
		sb.append(",DateFin="+String.valueOf(DateFin));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row26Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row25Struct implements routines.system.IPersistableRow<row25Struct> {
    final static byte[] commonByteArrayLock_LOCAL_PROJECT_STG_Load = new byte[0];
    static byte[] commonByteArray_LOCAL_PROJECT_STG_Load = new byte[0];

	
			    public Integer IDPromo;

				public Integer getIDPromo () {
					return this.IDPromo;
				}
				
			    public Integer IDBillet;

				public Integer getIDBillet () {
					return this.IDBillet;
				}
				
			    public Integer IDPromotion;

				public Integer getIDPromotion () {
					return this.IDPromotion;
				}
				
			    public Float TauxPromotion;

				public Float getTauxPromotion () {
					return this.TauxPromotion;
				}
				
			    public java.util.Date DateDebut;

				public java.util.Date getDateDebut () {
					return this.DateDebut;
				}
				
			    public java.util.Date DateFin;

				public java.util.Date getDateFin () {
					return this.DateFin;
				}
				


	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}
	
	private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = unmarshaller.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(unmarshaller.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }
    
    private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(date1 == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
						this.IDPromo = readInteger(dis);
					
						this.IDBillet = readInteger(dis);
					
						this.IDPromotion = readInteger(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.TauxPromotion = null;
           				} else {
           			    	this.TauxPromotion = dis.readFloat();
           				}
					
					this.DateDebut = readDate(dis);
					
					this.DateFin = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
						this.IDPromo = readInteger(dis);
					
						this.IDBillet = readInteger(dis);
					
						this.IDPromotion = readInteger(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.TauxPromotion = null;
           				} else {
           			    	this.TauxPromotion = dis.readFloat();
           				}
					
					this.DateDebut = readDate(dis);
					
					this.DateFin = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.IDPromo,dos);
					
					// Integer
				
						writeInteger(this.IDBillet,dos);
					
					// Integer
				
						writeInteger(this.IDPromotion,dos);
					
					// Float
				
						if(this.TauxPromotion == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.TauxPromotion);
		            	}
					
					// java.util.Date
				
						writeDate(this.DateDebut,dos);
					
					// java.util.Date
				
						writeDate(this.DateFin,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// Integer
				
						writeInteger(this.IDPromo,dos);
					
					// Integer
				
						writeInteger(this.IDBillet,dos);
					
					// Integer
				
						writeInteger(this.IDPromotion,dos);
					
					// Float
				
						if(this.TauxPromotion == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.TauxPromotion);
		            	}
					
					// java.util.Date
				
						writeDate(this.DateDebut,dos);
					
					// java.util.Date
				
						writeDate(this.DateFin,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("IDPromo="+String.valueOf(IDPromo));
		sb.append(",IDBillet="+String.valueOf(IDBillet));
		sb.append(",IDPromotion="+String.valueOf(IDPromotion));
		sb.append(",TauxPromotion="+String.valueOf(TauxPromotion));
		sb.append(",DateDebut="+String.valueOf(DateDebut));
		sb.append(",DateFin="+String.valueOf(DateFin));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row25Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tFileInputDelimited_9Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFileInputDelimited_9_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row25Struct row25 = new row25Struct();
row26Struct row26 = new row26Struct();
row27Struct row27 = new row27Struct();
STG_FAIT_PROMOStruct STG_FAIT_PROMO = new STG_FAIT_PROMOStruct();







	
	/**
	 * [tDBOutput_9 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_9", false);
		start_Hash.put("tDBOutput_9", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_9";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"STG_FAIT_PROMO");
					}
				
		int tos_count_tDBOutput_9 = 0;
		






        int updateKeyCount_tDBOutput_9 = 1;
        if(updateKeyCount_tDBOutput_9 < 1) {
            throw new RuntimeException("For update, Schema must have a key");
        } else if (updateKeyCount_tDBOutput_9 == 6 && true) {
                    System.err.println("For update, every Schema column can not be a key");
        }
    
    int nb_line_tDBOutput_9 = 0;
    int nb_line_update_tDBOutput_9 = 0;
    int nb_line_inserted_tDBOutput_9 = 0;
    int nb_line_deleted_tDBOutput_9 = 0;
    int nb_line_rejected_tDBOutput_9 = 0;

    int tmp_batchUpdateCount_tDBOutput_9 = 0;

    int deletedCount_tDBOutput_9=0;
    int updatedCount_tDBOutput_9=0;
    int insertedCount_tDBOutput_9=0;
    int rowsToCommitCount_tDBOutput_9=0;
    int rejectedCount_tDBOutput_9=0;

    boolean whetherReject_tDBOutput_9 = false;

    java.sql.Connection conn_tDBOutput_9 = null;

    //optional table
    String dbschema_tDBOutput_9 = null;
    String tableName_tDBOutput_9 = null;
        dbschema_tDBOutput_9 = (String)globalMap.get("dbschema_tDBConnection_2");
		
        conn_tDBOutput_9 = (java.sql.Connection)globalMap.get("conn_tDBConnection_2");
        int count_tDBOutput_9=0;

        if(dbschema_tDBOutput_9 == null || dbschema_tDBOutput_9.trim().length() == 0) {
            tableName_tDBOutput_9 = ("STG_FAIT_PROMOTION");
        } else {
            tableName_tDBOutput_9 = dbschema_tDBOutput_9 + "." + ("STG_FAIT_PROMOTION");
        }
            try (java.sql.Statement stmtClear_tDBOutput_9 = conn_tDBOutput_9.createStatement()) {
                stmtClear_tDBOutput_9.executeUpdate("DELETE FROM " + tableName_tDBOutput_9 + "");
            }
                java.sql.PreparedStatement pstmt_tDBOutput_9 = conn_tDBOutput_9.prepareStatement("SELECT COUNT(1) FROM " + tableName_tDBOutput_9 + " WHERE ID_PROMO = ?");
                resourceMap.put("pstmt_tDBOutput_9", pstmt_tDBOutput_9);
                String insert_tDBOutput_9 = "INSERT INTO " + tableName_tDBOutput_9 + " (ID_PROMO,SK_BILLET_ID,SK_PROMOTION_ID,TAUX_PROMOTION,DATE_DEBUT,DATE_FIN) VALUES (?,?,?,?,?,?)";    
                java.sql.PreparedStatement pstmtInsert_tDBOutput_9 = conn_tDBOutput_9.prepareStatement(insert_tDBOutput_9);
                resourceMap.put("pstmtInsert_tDBOutput_9", pstmtInsert_tDBOutput_9);
                String update_tDBOutput_9 = "UPDATE " + tableName_tDBOutput_9 + " SET SK_BILLET_ID = ?,SK_PROMOTION_ID = ?,TAUX_PROMOTION = ?,DATE_DEBUT = ?,DATE_FIN = ? WHERE ID_PROMO = ?";
                java.sql.PreparedStatement pstmtUpdate_tDBOutput_9 = conn_tDBOutput_9.prepareStatement(update_tDBOutput_9);
                resourceMap.put("pstmtUpdate_tDBOutput_9", pstmtUpdate_tDBOutput_9);





 



/**
 * [tDBOutput_9 begin ] stop
 */



	
	/**
	 * [tMap_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_4", false);
		start_Hash.put("tMap_4", System.currentTimeMillis());
		
	
	currentComponent="tMap_4";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row27");
					}
				
		int tos_count_tMap_4 = 0;
		




// ###############################
// # Lookup's keys initialization
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_4__Struct  {
}
Var__tMap_4__Struct Var__tMap_4 = new Var__tMap_4__Struct();
// ###############################

// ###############################
// # Outputs initialization
STG_FAIT_PROMOStruct STG_FAIT_PROMO_tmp = new STG_FAIT_PROMOStruct();
// ###############################

        
        



        









 



/**
 * [tMap_4 begin ] stop
 */



	
	/**
	 * [tSchemaComplianceCheck_9 begin ] start
	 */

	

	
		
		ok_Hash.put("tSchemaComplianceCheck_9", false);
		start_Hash.put("tSchemaComplianceCheck_9", System.currentTimeMillis());
		
	
	currentComponent="tSchemaComplianceCheck_9";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row26");
					}
				
		int tos_count_tSchemaComplianceCheck_9 = 0;
		

    class RowSetValueUtil_tSchemaComplianceCheck_9 {

        boolean ifPassedThrough = true;
        int errorCodeThrough = 0;
        String errorMessageThrough = "";
        int resultErrorCodeThrough = 0;
        String resultErrorMessageThrough = "";
        String tmpContentThrough = null;

        boolean ifPassed = true;
        int errorCode = 0;
        String errorMessage = "";

        void handleBigdecimalPrecision(String data, int iPrecision, int maxLength){
            //number of digits before the decimal point(ignoring frontend zeroes)
            int len1 = 0;
            int len2 = 0;
            ifPassed = true;
            errorCode = 0;
            errorMessage = "";
            if(data.startsWith("-")){
                data = data.substring(1);
            }
            data = org.apache.commons.lang.StringUtils.stripStart(data, "0");

            if(data.indexOf(".") >= 0){
                len1 = data.indexOf(".");
                data = org.apache.commons.lang.StringUtils.stripEnd(data, "0");
                len2 = data.length() - (len1 + 1);
            }else{
                len1 = data.length();
            }

            if (iPrecision < len2) {
                ifPassed = false;
                errorCode += 8;
                errorMessage += "|precision Non-matches";
            } else if (maxLength < len1 + iPrecision) {
                ifPassed = false;
                errorCode += 8;
                errorMessage += "|invalid Length setting is unsuitable for Precision";
            }
        }

        int handleErrorCode(int errorCode, int resultErrorCode){
            if (errorCode > 0) {
                if (resultErrorCode > 0) {
                    resultErrorCode = 16;
                } else {
                    resultErrorCode = errorCode;
                }
            }
            return resultErrorCode;
        }

        String handleErrorMessage(String errorMessage, String resultErrorMessage, String columnLabel){
            if (errorMessage.length() > 0) {
                if (resultErrorMessage.length() > 0) {
                    resultErrorMessage += ";"+ errorMessage.replaceFirst("\\|", columnLabel);
                } else {
                    resultErrorMessage = errorMessage.replaceFirst("\\|", columnLabel);
                }
            }
            return resultErrorMessage;
        }

        void reset(){
            ifPassedThrough = true;
            errorCodeThrough = 0;
            errorMessageThrough = "";
            resultErrorCodeThrough = 0;
            resultErrorMessageThrough = "";
            tmpContentThrough = null;

            ifPassed = true;
            errorCode = 0;
            errorMessage = "";
        }

        void setRowValue_0(row26Struct row26) {
    // validate nullable (empty as null)
    if ((row26.IDPromo == null) || ("".equals(row26.IDPromo))) {
        ifPassedThrough = false;
        errorCodeThrough += 4;
        errorMessageThrough += "|empty or null";
    }
            resultErrorCodeThrough = handleErrorCode(errorCodeThrough,resultErrorCodeThrough);
            errorCodeThrough = 0;
            resultErrorMessageThrough = handleErrorMessage(errorMessageThrough,resultErrorMessageThrough,"IDPromo:");
            errorMessageThrough = "";
    // validate nullable (empty as null)
    if ((row26.IDBillet == null) || ("".equals(row26.IDBillet))) {
        ifPassedThrough = false;
        errorCodeThrough += 4;
        errorMessageThrough += "|empty or null";
    }
            resultErrorCodeThrough = handleErrorCode(errorCodeThrough,resultErrorCodeThrough);
            errorCodeThrough = 0;
            resultErrorMessageThrough = handleErrorMessage(errorMessageThrough,resultErrorMessageThrough,"IDBillet:");
            errorMessageThrough = "";
    // validate nullable (empty as null)
    if ((row26.IDPromotion == null) || ("".equals(row26.IDPromotion))) {
        ifPassedThrough = false;
        errorCodeThrough += 4;
        errorMessageThrough += "|empty or null";
    }
            resultErrorCodeThrough = handleErrorCode(errorCodeThrough,resultErrorCodeThrough);
            errorCodeThrough = 0;
            resultErrorMessageThrough = handleErrorMessage(errorMessageThrough,resultErrorMessageThrough,"IDPromotion:");
            errorMessageThrough = "";
    // validate nullable (empty as null)
    if ((row26.TauxPromotion == null) || ("".equals(row26.TauxPromotion))) {
        ifPassedThrough = false;
        errorCodeThrough += 4;
        errorMessageThrough += "|empty or null";
    }
            resultErrorCodeThrough = handleErrorCode(errorCodeThrough,resultErrorCodeThrough);
            errorCodeThrough = 0;
            resultErrorMessageThrough = handleErrorMessage(errorMessageThrough,resultErrorMessageThrough,"TauxPromotion:");
            errorMessageThrough = "";
    // validate nullable (empty as null)
    if ((row26.DateDebut == null) || ("".equals(row26.DateDebut))) {
        ifPassedThrough = false;
        errorCodeThrough += 4;
        errorMessageThrough += "|empty or null";
    }
            resultErrorCodeThrough = handleErrorCode(errorCodeThrough,resultErrorCodeThrough);
            errorCodeThrough = 0;
            resultErrorMessageThrough = handleErrorMessage(errorMessageThrough,resultErrorMessageThrough,"DateDebut:");
            errorMessageThrough = "";
    // validate nullable (empty as null)
    if ((row26.DateFin == null) || ("".equals(row26.DateFin))) {
        ifPassedThrough = false;
        errorCodeThrough += 4;
        errorMessageThrough += "|empty or null";
    }
            resultErrorCodeThrough = handleErrorCode(errorCodeThrough,resultErrorCodeThrough);
            errorCodeThrough = 0;
            resultErrorMessageThrough = handleErrorMessage(errorMessageThrough,resultErrorMessageThrough,"DateFin:");
            errorMessageThrough = "";
        }
    }
    RowSetValueUtil_tSchemaComplianceCheck_9 rsvUtil_tSchemaComplianceCheck_9 = new RowSetValueUtil_tSchemaComplianceCheck_9();

 



/**
 * [tSchemaComplianceCheck_9 begin ] stop
 */



	
	/**
	 * [tUniqRow_9 begin ] start
	 */

	

	
		
		ok_Hash.put("tUniqRow_9", false);
		start_Hash.put("tUniqRow_9", System.currentTimeMillis());
		
	
	currentComponent="tUniqRow_9";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row25");
					}
				
		int tos_count_tUniqRow_9 = 0;
		

	
		class KeyStruct_tUniqRow_9 {
	
			private static final int DEFAULT_HASHCODE = 1;
		    private static final int PRIME = 31;
		    private int hashCode = DEFAULT_HASHCODE;
		    public boolean hashCodeDirty = true;
	
	        
					Integer IDPromo;        
	        
		    @Override
			public int hashCode() {
				if (this.hashCodeDirty) {
					final int prime = PRIME;
					int result = DEFAULT_HASHCODE;
			
								result = prime * result + ((this.IDPromo == null) ? 0 : this.IDPromo.hashCode());
								
		    		this.hashCode = result;
		    		this.hashCodeDirty = false;		
				}
				return this.hashCode;
			}
			
			@Override
			public boolean equals(Object obj) {
				if (this == obj) return true;
				if (obj == null) return false;
				if (getClass() != obj.getClass()) return false;
				final KeyStruct_tUniqRow_9 other = (KeyStruct_tUniqRow_9) obj;
				
									if (this.IDPromo == null) {
										if (other.IDPromo != null) 
											return false;
								
									} else if (!this.IDPromo.equals(other.IDPromo))
								 
										return false;
								
				
				return true;
			}
	  
	        
		}

	
int nb_uniques_tUniqRow_9 = 0;
int nb_duplicates_tUniqRow_9 = 0;
KeyStruct_tUniqRow_9 finder_tUniqRow_9 = new KeyStruct_tUniqRow_9();
java.util.Set<KeyStruct_tUniqRow_9> keystUniqRow_9 = new java.util.HashSet<KeyStruct_tUniqRow_9>(); 

 



/**
 * [tUniqRow_9 begin ] stop
 */



	
	/**
	 * [tFileInputDelimited_9 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileInputDelimited_9", false);
		start_Hash.put("tFileInputDelimited_9", System.currentTimeMillis());
		
	
	currentComponent="tFileInputDelimited_9";

	
		int tos_count_tFileInputDelimited_9 = 0;
		
	
	
	
 
	
	
	final routines.system.RowState rowstate_tFileInputDelimited_9 = new routines.system.RowState();
	
	
				int nb_line_tFileInputDelimited_9 = 0;
				org.talend.fileprocess.FileInputDelimited fid_tFileInputDelimited_9 = null;
				int limit_tFileInputDelimited_9 = -1;
				try{
					
						Object filename_tFileInputDelimited_9 = context.source_path+"promo.csv";
						if(filename_tFileInputDelimited_9 instanceof java.io.InputStream){
							
			int footer_value_tFileInputDelimited_9 = 0, random_value_tFileInputDelimited_9 = -1;
			if(footer_value_tFileInputDelimited_9 >0 || random_value_tFileInputDelimited_9 > 0){
				throw new java.lang.Exception("When the input source is a stream,footer and random shouldn't be bigger than 0.");				
			}
		
						}
						try {
							fid_tFileInputDelimited_9 = new org.talend.fileprocess.FileInputDelimited(context.source_path+"promo.csv", "US-ASCII",",","\n",false,1,0,
									limit_tFileInputDelimited_9
								,-1, false);
						} catch(java.lang.Exception e) {
globalMap.put("tFileInputDelimited_9_ERROR_MESSAGE",e.getMessage());
							
								
								System.err.println(e.getMessage());
							
						}
					
				    
					while (fid_tFileInputDelimited_9!=null && fid_tFileInputDelimited_9.nextRecord()) {
						rowstate_tFileInputDelimited_9.reset();
						
			    						row25 = null;			
												
									boolean whetherReject_tFileInputDelimited_9 = false;
									row25 = new row25Struct();
									try {
										
				int columnIndexWithD_tFileInputDelimited_9 = 0;
				
					String temp = ""; 
				
					columnIndexWithD_tFileInputDelimited_9 = 0;
					
						temp = fid_tFileInputDelimited_9.get(columnIndexWithD_tFileInputDelimited_9);
						if(temp.length() > 0) {
							
								try {
								
    								row25.IDPromo = ParserUtils.parseTo_Integer(temp);
    							
    							} catch(java.lang.Exception ex_tFileInputDelimited_9) {
globalMap.put("tFileInputDelimited_9_ERROR_MESSAGE",ex_tFileInputDelimited_9.getMessage());
									rowstate_tFileInputDelimited_9.setException(new RuntimeException(String.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
										"IDPromo", "row25", temp, ex_tFileInputDelimited_9), ex_tFileInputDelimited_9));
								}
    							
						} else {						
							
								
									row25.IDPromo = null;
								
							
						}
					
				
					columnIndexWithD_tFileInputDelimited_9 = 1;
					
						temp = fid_tFileInputDelimited_9.get(columnIndexWithD_tFileInputDelimited_9);
						if(temp.length() > 0) {
							
								try {
								
    								row25.IDBillet = ParserUtils.parseTo_Integer(temp);
    							
    							} catch(java.lang.Exception ex_tFileInputDelimited_9) {
globalMap.put("tFileInputDelimited_9_ERROR_MESSAGE",ex_tFileInputDelimited_9.getMessage());
									rowstate_tFileInputDelimited_9.setException(new RuntimeException(String.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
										"IDBillet", "row25", temp, ex_tFileInputDelimited_9), ex_tFileInputDelimited_9));
								}
    							
						} else {						
							
								
									row25.IDBillet = null;
								
							
						}
					
				
					columnIndexWithD_tFileInputDelimited_9 = 2;
					
						temp = fid_tFileInputDelimited_9.get(columnIndexWithD_tFileInputDelimited_9);
						if(temp.length() > 0) {
							
								try {
								
    								row25.IDPromotion = ParserUtils.parseTo_Integer(temp);
    							
    							} catch(java.lang.Exception ex_tFileInputDelimited_9) {
globalMap.put("tFileInputDelimited_9_ERROR_MESSAGE",ex_tFileInputDelimited_9.getMessage());
									rowstate_tFileInputDelimited_9.setException(new RuntimeException(String.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
										"IDPromotion", "row25", temp, ex_tFileInputDelimited_9), ex_tFileInputDelimited_9));
								}
    							
						} else {						
							
								
									row25.IDPromotion = null;
								
							
						}
					
				
					columnIndexWithD_tFileInputDelimited_9 = 3;
					
						temp = fid_tFileInputDelimited_9.get(columnIndexWithD_tFileInputDelimited_9);
						if(temp.length() > 0) {
							
								try {
								
    								row25.TauxPromotion = ParserUtils.parseTo_Float(temp);
    							
    							} catch(java.lang.Exception ex_tFileInputDelimited_9) {
globalMap.put("tFileInputDelimited_9_ERROR_MESSAGE",ex_tFileInputDelimited_9.getMessage());
									rowstate_tFileInputDelimited_9.setException(new RuntimeException(String.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
										"TauxPromotion", "row25", temp, ex_tFileInputDelimited_9), ex_tFileInputDelimited_9));
								}
    							
						} else {						
							
								
									row25.TauxPromotion = null;
								
							
						}
					
				
					columnIndexWithD_tFileInputDelimited_9 = 4;
					
						temp = fid_tFileInputDelimited_9.get(columnIndexWithD_tFileInputDelimited_9);
						if(temp.length() > 0) {
							
								try {
								
    									row25.DateDebut = ParserUtils.parseTo_Date(temp, "dd-MM-yyyy");
    								
    							} catch(java.lang.Exception ex_tFileInputDelimited_9) {
globalMap.put("tFileInputDelimited_9_ERROR_MESSAGE",ex_tFileInputDelimited_9.getMessage());
									rowstate_tFileInputDelimited_9.setException(new RuntimeException(String.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
										"DateDebut", "row25", temp, ex_tFileInputDelimited_9), ex_tFileInputDelimited_9));
								}
    							
						} else {						
							
								
									row25.DateDebut = null;
								
							
						}
					
				
					columnIndexWithD_tFileInputDelimited_9 = 5;
					
						temp = fid_tFileInputDelimited_9.get(columnIndexWithD_tFileInputDelimited_9);
						if(temp.length() > 0) {
							
								try {
								
    									row25.DateFin = ParserUtils.parseTo_Date(temp, "dd-MM-yyyy");
    								
    							} catch(java.lang.Exception ex_tFileInputDelimited_9) {
globalMap.put("tFileInputDelimited_9_ERROR_MESSAGE",ex_tFileInputDelimited_9.getMessage());
									rowstate_tFileInputDelimited_9.setException(new RuntimeException(String.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
										"DateFin", "row25", temp, ex_tFileInputDelimited_9), ex_tFileInputDelimited_9));
								}
    							
						} else {						
							
								
									row25.DateFin = null;
								
							
						}
					
				
				
										
										if(rowstate_tFileInputDelimited_9.getException()!=null) {
											throw rowstate_tFileInputDelimited_9.getException();
										}
										
										
							
			    					} catch (java.lang.Exception e) {
globalMap.put("tFileInputDelimited_9_ERROR_MESSAGE",e.getMessage());
			        					whetherReject_tFileInputDelimited_9 = true;
			        					
			                					System.err.println(e.getMessage());
			                					row25 = null;
			                				
										
			    					}
								

 



/**
 * [tFileInputDelimited_9 begin ] stop
 */
	
	/**
	 * [tFileInputDelimited_9 main ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_9";

	

 


	tos_count_tFileInputDelimited_9++;

/**
 * [tFileInputDelimited_9 main ] stop
 */
	
	/**
	 * [tFileInputDelimited_9 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_9";

	

 



/**
 * [tFileInputDelimited_9 process_data_begin ] stop
 */
// Start of branch "row25"
if(row25 != null) { 



	
	/**
	 * [tUniqRow_9 main ] start
	 */

	

	
	
	currentComponent="tUniqRow_9";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row25"
						
						);
					}
					
row26 = null;			
finder_tUniqRow_9.IDPromo = row25.IDPromo;	
finder_tUniqRow_9.hashCodeDirty = true;
if (!keystUniqRow_9.contains(finder_tUniqRow_9)) {
		KeyStruct_tUniqRow_9 new_tUniqRow_9 = new KeyStruct_tUniqRow_9();

		
new_tUniqRow_9.IDPromo = row25.IDPromo;
		
		keystUniqRow_9.add(new_tUniqRow_9);if(row26 == null){ 
	
	row26 = new row26Struct();
}row26.IDPromo = row25.IDPromo;			row26.IDBillet = row25.IDBillet;			row26.IDPromotion = row25.IDPromotion;			row26.TauxPromotion = row25.TauxPromotion;			row26.DateDebut = row25.DateDebut;			row26.DateFin = row25.DateFin;					
		nb_uniques_tUniqRow_9++;
	} else {
	  nb_duplicates_tUniqRow_9++;
	}

 


	tos_count_tUniqRow_9++;

/**
 * [tUniqRow_9 main ] stop
 */
	
	/**
	 * [tUniqRow_9 process_data_begin ] start
	 */

	

	
	
	currentComponent="tUniqRow_9";

	

 



/**
 * [tUniqRow_9 process_data_begin ] stop
 */
// Start of branch "row26"
if(row26 != null) { 



	
	/**
	 * [tSchemaComplianceCheck_9 main ] start
	 */

	

	
	
	currentComponent="tSchemaComplianceCheck_9";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row26"
						
						);
					}
					
	row27 = null;
	rsvUtil_tSchemaComplianceCheck_9.setRowValue_0(row26);
	if (rsvUtil_tSchemaComplianceCheck_9.ifPassedThrough) {
		row27 = new row27Struct();
		row27.IDPromo = row26.IDPromo;
		row27.IDBillet = row26.IDBillet;
		row27.IDPromotion = row26.IDPromotion;
		row27.TauxPromotion = row26.TauxPromotion;
		row27.DateDebut = row26.DateDebut;
		row27.DateFin = row26.DateFin;
	}
	rsvUtil_tSchemaComplianceCheck_9.reset();

 


	tos_count_tSchemaComplianceCheck_9++;

/**
 * [tSchemaComplianceCheck_9 main ] stop
 */
	
	/**
	 * [tSchemaComplianceCheck_9 process_data_begin ] start
	 */

	

	
	
	currentComponent="tSchemaComplianceCheck_9";

	

 



/**
 * [tSchemaComplianceCheck_9 process_data_begin ] stop
 */
// Start of branch "row27"
if(row27 != null) { 



	
	/**
	 * [tMap_4 main ] start
	 */

	

	
	
	currentComponent="tMap_4";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row27"
						
						);
					}
					

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_4 = false;
		

        // ###############################
        // # Input tables (lookups)
		  boolean rejectedInnerJoin_tMap_4 = false;
		  boolean mainRowRejected_tMap_4 = false;
            				    								  
		// ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_4__Struct Var = Var__tMap_4;// ###############################
        // ###############################
        // # Output tables

STG_FAIT_PROMO = null;


// # Output table : 'STG_FAIT_PROMO'
STG_FAIT_PROMO_tmp.ID_PROMO = row27.IDPromo ;
STG_FAIT_PROMO_tmp.SK_BILLET_ID = row27.IDBillet ;
STG_FAIT_PROMO_tmp.SK_PROMOTION_ID = row27.IDPromotion ;
STG_FAIT_PROMO_tmp.TAUX_PROMOTION = row27.TauxPromotion ;
STG_FAIT_PROMO_tmp.DATE_DEBUT = row27.DateDebut ;
STG_FAIT_PROMO_tmp.DATE_FIN = row27.DateFin ;
STG_FAIT_PROMO = STG_FAIT_PROMO_tmp;
// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_4 = false;










 


	tos_count_tMap_4++;

/**
 * [tMap_4 main ] stop
 */
	
	/**
	 * [tMap_4 process_data_begin ] start
	 */

	

	
	
	currentComponent="tMap_4";

	

 



/**
 * [tMap_4 process_data_begin ] stop
 */
// Start of branch "STG_FAIT_PROMO"
if(STG_FAIT_PROMO != null) { 



	
	/**
	 * [tDBOutput_9 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_9";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"STG_FAIT_PROMO"
						
						);
					}
					



        whetherReject_tDBOutput_9 = false;
                    pstmt_tDBOutput_9.setInt(1, STG_FAIT_PROMO.ID_PROMO);

            int checkCount_tDBOutput_9 = -1;
            try (java.sql.ResultSet rs_tDBOutput_9 = pstmt_tDBOutput_9.executeQuery()) {
                while(rs_tDBOutput_9.next()) {
                    checkCount_tDBOutput_9 = rs_tDBOutput_9.getInt(1);
                }
            }
            if(checkCount_tDBOutput_9 > 0) {
                        pstmtUpdate_tDBOutput_9.setInt(1, STG_FAIT_PROMO.SK_BILLET_ID);

                        pstmtUpdate_tDBOutput_9.setInt(2, STG_FAIT_PROMO.SK_PROMOTION_ID);

                        pstmtUpdate_tDBOutput_9.setFloat(3, STG_FAIT_PROMO.TAUX_PROMOTION);

                        if(STG_FAIT_PROMO.DATE_DEBUT != null) {
pstmtUpdate_tDBOutput_9.setObject(4, new java.sql.Timestamp(STG_FAIT_PROMO.DATE_DEBUT.getTime()),java.sql.Types.DATE);
} else {
pstmtUpdate_tDBOutput_9.setNull(4, java.sql.Types.DATE);
}

                        if(STG_FAIT_PROMO.DATE_FIN != null) {
pstmtUpdate_tDBOutput_9.setObject(5, new java.sql.Timestamp(STG_FAIT_PROMO.DATE_FIN.getTime()),java.sql.Types.DATE);
} else {
pstmtUpdate_tDBOutput_9.setNull(5, java.sql.Types.DATE);
}

                        pstmtUpdate_tDBOutput_9.setInt(6 + count_tDBOutput_9, STG_FAIT_PROMO.ID_PROMO);

                try {
                    int processedCount_tDBOutput_9 = pstmtUpdate_tDBOutput_9.executeUpdate();
                    updatedCount_tDBOutput_9 += processedCount_tDBOutput_9;
                    rowsToCommitCount_tDBOutput_9 += processedCount_tDBOutput_9;
                    nb_line_tDBOutput_9++;
                } catch(java.lang.Exception e_tDBOutput_9) {
globalMap.put("tDBOutput_9_ERROR_MESSAGE",e_tDBOutput_9.getMessage());
                    whetherReject_tDBOutput_9 = true;
                        nb_line_tDBOutput_9++;
                            System.err.print(e_tDBOutput_9.getMessage());
                }
            } else {
                        pstmtInsert_tDBOutput_9.setInt(1, STG_FAIT_PROMO.ID_PROMO);

                        pstmtInsert_tDBOutput_9.setInt(2, STG_FAIT_PROMO.SK_BILLET_ID);

                        pstmtInsert_tDBOutput_9.setInt(3, STG_FAIT_PROMO.SK_PROMOTION_ID);

                        pstmtInsert_tDBOutput_9.setFloat(4, STG_FAIT_PROMO.TAUX_PROMOTION);

                        if(STG_FAIT_PROMO.DATE_DEBUT != null) {
pstmtInsert_tDBOutput_9.setObject(5, new java.sql.Timestamp(STG_FAIT_PROMO.DATE_DEBUT.getTime()),java.sql.Types.DATE);
} else {
pstmtInsert_tDBOutput_9.setNull(5, java.sql.Types.DATE);
}

                        if(STG_FAIT_PROMO.DATE_FIN != null) {
pstmtInsert_tDBOutput_9.setObject(6, new java.sql.Timestamp(STG_FAIT_PROMO.DATE_FIN.getTime()),java.sql.Types.DATE);
} else {
pstmtInsert_tDBOutput_9.setNull(6, java.sql.Types.DATE);
}

                try {
                    int processedCount_tDBOutput_9 = pstmtInsert_tDBOutput_9.executeUpdate();
                    insertedCount_tDBOutput_9 += processedCount_tDBOutput_9;
                    rowsToCommitCount_tDBOutput_9 += processedCount_tDBOutput_9;
                    nb_line_tDBOutput_9++;
                } catch(java.lang.Exception e_tDBOutput_9) {
globalMap.put("tDBOutput_9_ERROR_MESSAGE",e_tDBOutput_9.getMessage());
                    whetherReject_tDBOutput_9 = true;
                        nb_line_tDBOutput_9++;
                            System.err.print(e_tDBOutput_9.getMessage());
                }
            }

 


	tos_count_tDBOutput_9++;

/**
 * [tDBOutput_9 main ] stop
 */
	
	/**
	 * [tDBOutput_9 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_9";

	

 



/**
 * [tDBOutput_9 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_9 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_9";

	

 



/**
 * [tDBOutput_9 process_data_end ] stop
 */

} // End of branch "STG_FAIT_PROMO"




	
	/**
	 * [tMap_4 process_data_end ] start
	 */

	

	
	
	currentComponent="tMap_4";

	

 



/**
 * [tMap_4 process_data_end ] stop
 */

} // End of branch "row27"




	
	/**
	 * [tSchemaComplianceCheck_9 process_data_end ] start
	 */

	

	
	
	currentComponent="tSchemaComplianceCheck_9";

	

 



/**
 * [tSchemaComplianceCheck_9 process_data_end ] stop
 */

} // End of branch "row26"




	
	/**
	 * [tUniqRow_9 process_data_end ] start
	 */

	

	
	
	currentComponent="tUniqRow_9";

	

 



/**
 * [tUniqRow_9 process_data_end ] stop
 */

} // End of branch "row25"




	
	/**
	 * [tFileInputDelimited_9 process_data_end ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_9";

	

 



/**
 * [tFileInputDelimited_9 process_data_end ] stop
 */
	
	/**
	 * [tFileInputDelimited_9 end ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_9";

	



            }
            }finally{
                if(!((Object)(context.source_path+"promo.csv") instanceof java.io.InputStream)){
                	if(fid_tFileInputDelimited_9!=null){
                		fid_tFileInputDelimited_9.close();
                	}
                }
                if(fid_tFileInputDelimited_9!=null){
                	globalMap.put("tFileInputDelimited_9_NB_LINE", fid_tFileInputDelimited_9.getRowNumber());
					
                }
			}
			  

 

ok_Hash.put("tFileInputDelimited_9", true);
end_Hash.put("tFileInputDelimited_9", System.currentTimeMillis());




/**
 * [tFileInputDelimited_9 end ] stop
 */

	
	/**
	 * [tUniqRow_9 end ] start
	 */

	

	
	
	currentComponent="tUniqRow_9";

	

globalMap.put("tUniqRow_9_NB_UNIQUES",nb_uniques_tUniqRow_9);
globalMap.put("tUniqRow_9_NB_DUPLICATES",nb_duplicates_tUniqRow_9);

				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row25");
			  	}
			  	
 

ok_Hash.put("tUniqRow_9", true);
end_Hash.put("tUniqRow_9", System.currentTimeMillis());




/**
 * [tUniqRow_9 end ] stop
 */

	
	/**
	 * [tSchemaComplianceCheck_9 end ] start
	 */

	

	
	
	currentComponent="tSchemaComplianceCheck_9";

	

				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row26");
			  	}
			  	
 

ok_Hash.put("tSchemaComplianceCheck_9", true);
end_Hash.put("tSchemaComplianceCheck_9", System.currentTimeMillis());




/**
 * [tSchemaComplianceCheck_9 end ] stop
 */

	
	/**
	 * [tMap_4 end ] start
	 */

	

	
	
	currentComponent="tMap_4";

	


// ###############################
// # Lookup hashes releasing
// ###############################      





				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row27");
			  	}
			  	
 

ok_Hash.put("tMap_4", true);
end_Hash.put("tMap_4", System.currentTimeMillis());




/**
 * [tMap_4 end ] stop
 */

	
	/**
	 * [tDBOutput_9 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_9";

	
	



	
        if(pstmtUpdate_tDBOutput_9 != null){
            pstmtUpdate_tDBOutput_9.close();
            resourceMap.remove("pstmtUpdate_tDBOutput_9");
        }
        if(pstmtInsert_tDBOutput_9 != null){
            pstmtInsert_tDBOutput_9.close();
            resourceMap.remove("pstmtInsert_tDBOutput_9");
        }
        if(pstmt_tDBOutput_9 != null) {
            pstmt_tDBOutput_9.close();
            resourceMap.remove("pstmt_tDBOutput_9");
        }
    resourceMap.put("statementClosed_tDBOutput_9", true);

	
	nb_line_deleted_tDBOutput_9=nb_line_deleted_tDBOutput_9+ deletedCount_tDBOutput_9;
	nb_line_update_tDBOutput_9=nb_line_update_tDBOutput_9 + updatedCount_tDBOutput_9;
	nb_line_inserted_tDBOutput_9=nb_line_inserted_tDBOutput_9 + insertedCount_tDBOutput_9;
	nb_line_rejected_tDBOutput_9=nb_line_rejected_tDBOutput_9 + rejectedCount_tDBOutput_9;
	
        globalMap.put("tDBOutput_9_NB_LINE",nb_line_tDBOutput_9);
        globalMap.put("tDBOutput_9_NB_LINE_UPDATED",nb_line_update_tDBOutput_9);
        globalMap.put("tDBOutput_9_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_9);
        globalMap.put("tDBOutput_9_NB_LINE_DELETED",nb_line_deleted_tDBOutput_9);
        globalMap.put("tDBOutput_9_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_9);
    

	



				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"STG_FAIT_PROMO");
			  	}
			  	
 

ok_Hash.put("tDBOutput_9", true);
end_Hash.put("tDBOutput_9", System.currentTimeMillis());




/**
 * [tDBOutput_9 end ] stop
 */












				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tFileInputDelimited_9:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk12", 0, "ok");
								} 
							
							tFileInputDelimited_10Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFileInputDelimited_9 finally ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_9";

	

 



/**
 * [tFileInputDelimited_9 finally ] stop
 */

	
	/**
	 * [tUniqRow_9 finally ] start
	 */

	

	
	
	currentComponent="tUniqRow_9";

	

 



/**
 * [tUniqRow_9 finally ] stop
 */

	
	/**
	 * [tSchemaComplianceCheck_9 finally ] start
	 */

	

	
	
	currentComponent="tSchemaComplianceCheck_9";

	

 



/**
 * [tSchemaComplianceCheck_9 finally ] stop
 */

	
	/**
	 * [tMap_4 finally ] start
	 */

	

	
	
	currentComponent="tMap_4";

	

 



/**
 * [tMap_4 finally ] stop
 */

	
	/**
	 * [tDBOutput_9 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_9";

	



    if (resourceMap.get("statementClosed_tDBOutput_9") == null) {
                java.sql.PreparedStatement pstmtUpdateToClose_tDBOutput_9 = null;
                if ((pstmtUpdateToClose_tDBOutput_9 = (java.sql.PreparedStatement) resourceMap.remove("pstmtUpdate_tDBOutput_9")) != null) {
                    pstmtUpdateToClose_tDBOutput_9.close();
                }
                java.sql.PreparedStatement pstmtInsertToClose_tDBOutput_9 = null;
                if ((pstmtInsertToClose_tDBOutput_9 = (java.sql.PreparedStatement) resourceMap.remove("pstmtInsert_tDBOutput_9")) != null) {
                    pstmtInsertToClose_tDBOutput_9.close();
                }
                java.sql.PreparedStatement pstmtToClose_tDBOutput_9 = null;
                if ((pstmtToClose_tDBOutput_9 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_9")) != null) {
                    pstmtToClose_tDBOutput_9.close();
                }
    }
 



/**
 * [tDBOutput_9 finally ] stop
 */












				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFileInputDelimited_9_SUBPROCESS_STATE", 1);
	}
	


public static class STG_DIM_PROMOTIONStruct implements routines.system.IPersistableRow<STG_DIM_PROMOTIONStruct> {
    final static byte[] commonByteArrayLock_LOCAL_PROJECT_STG_Load = new byte[0];
    static byte[] commonByteArray_LOCAL_PROJECT_STG_Load = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int ID_PROMOTION;

				public int getID_PROMOTION () {
					return this.ID_PROMOTION;
				}
				
			    public String NOM_PROMOTION;

				public String getNOM_PROMOTION () {
					return this.NOM_PROMOTION;
				}
				
			    public String DESCRIPTION;

				public String getDESCRIPTION () {
					return this.DESCRIPTION;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.ID_PROMOTION;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final STG_DIM_PROMOTIONStruct other = (STG_DIM_PROMOTIONStruct) obj;
		
						if (this.ID_PROMOTION != other.ID_PROMOTION)
							return false;
					

		return true;
    }

	public void copyDataTo(STG_DIM_PROMOTIONStruct other) {

		other.ID_PROMOTION = this.ID_PROMOTION;
	            other.NOM_PROMOTION = this.NOM_PROMOTION;
	            other.DESCRIPTION = this.DESCRIPTION;
	            
	}

	public void copyKeysDataTo(STG_DIM_PROMOTIONStruct other) {

		other.ID_PROMOTION = this.ID_PROMOTION;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
			        this.ID_PROMOTION = dis.readInt();
					
					this.NOM_PROMOTION = readString(dis);
					
					this.DESCRIPTION = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
			        this.ID_PROMOTION = dis.readInt();
					
					this.NOM_PROMOTION = readString(dis);
					
					this.DESCRIPTION = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.ID_PROMOTION);
					
					// String
				
						writeString(this.NOM_PROMOTION,dos);
					
					// String
				
						writeString(this.DESCRIPTION,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.ID_PROMOTION);
					
					// String
				
						writeString(this.NOM_PROMOTION,dos);
					
					// String
				
						writeString(this.DESCRIPTION,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("ID_PROMOTION="+String.valueOf(ID_PROMOTION));
		sb.append(",NOM_PROMOTION="+NOM_PROMOTION);
		sb.append(",DESCRIPTION="+DESCRIPTION);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(STG_DIM_PROMOTIONStruct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.ID_PROMOTION, other.ID_PROMOTION);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row30Struct implements routines.system.IPersistableRow<row30Struct> {
    final static byte[] commonByteArrayLock_LOCAL_PROJECT_STG_Load = new byte[0];
    static byte[] commonByteArray_LOCAL_PROJECT_STG_Load = new byte[0];

	
			    public Integer IDPromotion;

				public Integer getIDPromotion () {
					return this.IDPromotion;
				}
				
			    public String NomPromotion;

				public String getNomPromotion () {
					return this.NomPromotion;
				}
				
			    public String Description;

				public String getDescription () {
					return this.Description;
				}
				


	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
						this.IDPromotion = readInteger(dis);
					
					this.NomPromotion = readString(dis);
					
					this.Description = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
						this.IDPromotion = readInteger(dis);
					
					this.NomPromotion = readString(dis);
					
					this.Description = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.IDPromotion,dos);
					
					// String
				
						writeString(this.NomPromotion,dos);
					
					// String
				
						writeString(this.Description,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// Integer
				
						writeInteger(this.IDPromotion,dos);
					
					// String
				
						writeString(this.NomPromotion,dos);
					
					// String
				
						writeString(this.Description,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("IDPromotion="+String.valueOf(IDPromotion));
		sb.append(",NomPromotion="+NomPromotion);
		sb.append(",Description="+Description);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row30Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row29Struct implements routines.system.IPersistableRow<row29Struct> {
    final static byte[] commonByteArrayLock_LOCAL_PROJECT_STG_Load = new byte[0];
    static byte[] commonByteArray_LOCAL_PROJECT_STG_Load = new byte[0];

	
			    public Integer IDPromotion;

				public Integer getIDPromotion () {
					return this.IDPromotion;
				}
				
			    public String NomPromotion;

				public String getNomPromotion () {
					return this.NomPromotion;
				}
				
			    public String Description;

				public String getDescription () {
					return this.Description;
				}
				


	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
						this.IDPromotion = readInteger(dis);
					
					this.NomPromotion = readString(dis);
					
					this.Description = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
						this.IDPromotion = readInteger(dis);
					
					this.NomPromotion = readString(dis);
					
					this.Description = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.IDPromotion,dos);
					
					// String
				
						writeString(this.NomPromotion,dos);
					
					// String
				
						writeString(this.Description,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// Integer
				
						writeInteger(this.IDPromotion,dos);
					
					// String
				
						writeString(this.NomPromotion,dos);
					
					// String
				
						writeString(this.Description,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("IDPromotion="+String.valueOf(IDPromotion));
		sb.append(",NomPromotion="+NomPromotion);
		sb.append(",Description="+Description);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row29Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row28Struct implements routines.system.IPersistableRow<row28Struct> {
    final static byte[] commonByteArrayLock_LOCAL_PROJECT_STG_Load = new byte[0];
    static byte[] commonByteArray_LOCAL_PROJECT_STG_Load = new byte[0];

	
			    public Integer IDPromotion;

				public Integer getIDPromotion () {
					return this.IDPromotion;
				}
				
			    public String NomPromotion;

				public String getNomPromotion () {
					return this.NomPromotion;
				}
				
			    public String Description;

				public String getDescription () {
					return this.Description;
				}
				


	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
						this.IDPromotion = readInteger(dis);
					
					this.NomPromotion = readString(dis);
					
					this.Description = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
						this.IDPromotion = readInteger(dis);
					
					this.NomPromotion = readString(dis);
					
					this.Description = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.IDPromotion,dos);
					
					// String
				
						writeString(this.NomPromotion,dos);
					
					// String
				
						writeString(this.Description,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// Integer
				
						writeInteger(this.IDPromotion,dos);
					
					// String
				
						writeString(this.NomPromotion,dos);
					
					// String
				
						writeString(this.Description,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("IDPromotion="+String.valueOf(IDPromotion));
		sb.append(",NomPromotion="+NomPromotion);
		sb.append(",Description="+Description);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row28Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tFileInputDelimited_10Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFileInputDelimited_10_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row28Struct row28 = new row28Struct();
row29Struct row29 = new row29Struct();
row30Struct row30 = new row30Struct();
STG_DIM_PROMOTIONStruct STG_DIM_PROMOTION = new STG_DIM_PROMOTIONStruct();







	
	/**
	 * [tDBOutput_10 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_10", false);
		start_Hash.put("tDBOutput_10", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_10";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"STG_DIM_PROMOTION");
					}
				
		int tos_count_tDBOutput_10 = 0;
		






        int updateKeyCount_tDBOutput_10 = 1;
        if(updateKeyCount_tDBOutput_10 < 1) {
            throw new RuntimeException("For update, Schema must have a key");
        } else if (updateKeyCount_tDBOutput_10 == 3 && true) {
                    System.err.println("For update, every Schema column can not be a key");
        }
    
    int nb_line_tDBOutput_10 = 0;
    int nb_line_update_tDBOutput_10 = 0;
    int nb_line_inserted_tDBOutput_10 = 0;
    int nb_line_deleted_tDBOutput_10 = 0;
    int nb_line_rejected_tDBOutput_10 = 0;

    int tmp_batchUpdateCount_tDBOutput_10 = 0;

    int deletedCount_tDBOutput_10=0;
    int updatedCount_tDBOutput_10=0;
    int insertedCount_tDBOutput_10=0;
    int rowsToCommitCount_tDBOutput_10=0;
    int rejectedCount_tDBOutput_10=0;

    boolean whetherReject_tDBOutput_10 = false;

    java.sql.Connection conn_tDBOutput_10 = null;

    //optional table
    String dbschema_tDBOutput_10 = null;
    String tableName_tDBOutput_10 = null;
        dbschema_tDBOutput_10 = (String)globalMap.get("dbschema_tDBConnection_2");
		
        conn_tDBOutput_10 = (java.sql.Connection)globalMap.get("conn_tDBConnection_2");
        int count_tDBOutput_10=0;

        if(dbschema_tDBOutput_10 == null || dbschema_tDBOutput_10.trim().length() == 0) {
            tableName_tDBOutput_10 = ("STG_DIM_PROMOTION");
        } else {
            tableName_tDBOutput_10 = dbschema_tDBOutput_10 + "." + ("STG_DIM_PROMOTION");
        }
            try (java.sql.Statement stmtClear_tDBOutput_10 = conn_tDBOutput_10.createStatement()) {
                stmtClear_tDBOutput_10.executeUpdate("DELETE FROM " + tableName_tDBOutput_10 + "");
            }
                java.sql.PreparedStatement pstmt_tDBOutput_10 = conn_tDBOutput_10.prepareStatement("SELECT COUNT(1) FROM " + tableName_tDBOutput_10 + " WHERE ID_PROMOTION = ?");
                resourceMap.put("pstmt_tDBOutput_10", pstmt_tDBOutput_10);
                String insert_tDBOutput_10 = "INSERT INTO " + tableName_tDBOutput_10 + " (ID_PROMOTION,NOM_PROMOTION,DESCRIPTION) VALUES (?,?,?)";    
                java.sql.PreparedStatement pstmtInsert_tDBOutput_10 = conn_tDBOutput_10.prepareStatement(insert_tDBOutput_10);
                resourceMap.put("pstmtInsert_tDBOutput_10", pstmtInsert_tDBOutput_10);
                String update_tDBOutput_10 = "UPDATE " + tableName_tDBOutput_10 + " SET NOM_PROMOTION = ?,DESCRIPTION = ? WHERE ID_PROMOTION = ?";
                java.sql.PreparedStatement pstmtUpdate_tDBOutput_10 = conn_tDBOutput_10.prepareStatement(update_tDBOutput_10);
                resourceMap.put("pstmtUpdate_tDBOutput_10", pstmtUpdate_tDBOutput_10);





 



/**
 * [tDBOutput_10 begin ] stop
 */



	
	/**
	 * [tMap_5 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_5", false);
		start_Hash.put("tMap_5", System.currentTimeMillis());
		
	
	currentComponent="tMap_5";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row30");
					}
				
		int tos_count_tMap_5 = 0;
		




// ###############################
// # Lookup's keys initialization
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_5__Struct  {
}
Var__tMap_5__Struct Var__tMap_5 = new Var__tMap_5__Struct();
// ###############################

// ###############################
// # Outputs initialization
STG_DIM_PROMOTIONStruct STG_DIM_PROMOTION_tmp = new STG_DIM_PROMOTIONStruct();
// ###############################

        
        



        









 



/**
 * [tMap_5 begin ] stop
 */



	
	/**
	 * [tSchemaComplianceCheck_10 begin ] start
	 */

	

	
		
		ok_Hash.put("tSchemaComplianceCheck_10", false);
		start_Hash.put("tSchemaComplianceCheck_10", System.currentTimeMillis());
		
	
	currentComponent="tSchemaComplianceCheck_10";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row29");
					}
				
		int tos_count_tSchemaComplianceCheck_10 = 0;
		

    class RowSetValueUtil_tSchemaComplianceCheck_10 {

        boolean ifPassedThrough = true;
        int errorCodeThrough = 0;
        String errorMessageThrough = "";
        int resultErrorCodeThrough = 0;
        String resultErrorMessageThrough = "";
        String tmpContentThrough = null;

        boolean ifPassed = true;
        int errorCode = 0;
        String errorMessage = "";

        void handleBigdecimalPrecision(String data, int iPrecision, int maxLength){
            //number of digits before the decimal point(ignoring frontend zeroes)
            int len1 = 0;
            int len2 = 0;
            ifPassed = true;
            errorCode = 0;
            errorMessage = "";
            if(data.startsWith("-")){
                data = data.substring(1);
            }
            data = org.apache.commons.lang.StringUtils.stripStart(data, "0");

            if(data.indexOf(".") >= 0){
                len1 = data.indexOf(".");
                data = org.apache.commons.lang.StringUtils.stripEnd(data, "0");
                len2 = data.length() - (len1 + 1);
            }else{
                len1 = data.length();
            }

            if (iPrecision < len2) {
                ifPassed = false;
                errorCode += 8;
                errorMessage += "|precision Non-matches";
            } else if (maxLength < len1 + iPrecision) {
                ifPassed = false;
                errorCode += 8;
                errorMessage += "|invalid Length setting is unsuitable for Precision";
            }
        }

        int handleErrorCode(int errorCode, int resultErrorCode){
            if (errorCode > 0) {
                if (resultErrorCode > 0) {
                    resultErrorCode = 16;
                } else {
                    resultErrorCode = errorCode;
                }
            }
            return resultErrorCode;
        }

        String handleErrorMessage(String errorMessage, String resultErrorMessage, String columnLabel){
            if (errorMessage.length() > 0) {
                if (resultErrorMessage.length() > 0) {
                    resultErrorMessage += ";"+ errorMessage.replaceFirst("\\|", columnLabel);
                } else {
                    resultErrorMessage = errorMessage.replaceFirst("\\|", columnLabel);
                }
            }
            return resultErrorMessage;
        }

        void reset(){
            ifPassedThrough = true;
            errorCodeThrough = 0;
            errorMessageThrough = "";
            resultErrorCodeThrough = 0;
            resultErrorMessageThrough = "";
            tmpContentThrough = null;

            ifPassed = true;
            errorCode = 0;
            errorMessage = "";
        }

        void setRowValue_0(row29Struct row29) {
    // validate nullable (empty as null)
    if ((row29.IDPromotion == null) || ("".equals(row29.IDPromotion))) {
        ifPassedThrough = false;
        errorCodeThrough += 4;
        errorMessageThrough += "|empty or null";
    }
            resultErrorCodeThrough = handleErrorCode(errorCodeThrough,resultErrorCodeThrough);
            errorCodeThrough = 0;
            resultErrorMessageThrough = handleErrorMessage(errorMessageThrough,resultErrorMessageThrough,"IDPromotion:");
            errorMessageThrough = "";
    // validate nullable (empty as null)
    if ((row29.NomPromotion == null) || ("".equals(row29.NomPromotion))) {
        ifPassedThrough = false;
        errorCodeThrough += 4;
        errorMessageThrough += "|empty or null";
    }    try {
        if(
        row29.NomPromotion != null
        ) {
            String tester_tSchemaComplianceCheck_10 = String.valueOf(row29.NomPromotion);
        }
    } catch(java.lang.Exception e) {
globalMap.put("tSchemaComplianceCheck_10_ERROR_MESSAGE",e.getMessage());
        ifPassedThrough = false;
        errorCodeThrough += 2;
        errorMessageThrough += "|wrong type";
    }
            resultErrorCodeThrough = handleErrorCode(errorCodeThrough,resultErrorCodeThrough);
            errorCodeThrough = 0;
            resultErrorMessageThrough = handleErrorMessage(errorMessageThrough,resultErrorMessageThrough,"NomPromotion:");
            errorMessageThrough = "";
    // validate nullable (empty as null)
    if ((row29.Description == null) || ("".equals(row29.Description))) {
        ifPassedThrough = false;
        errorCodeThrough += 4;
        errorMessageThrough += "|empty or null";
    }    try {
        if(
        row29.Description != null
        ) {
            String tester_tSchemaComplianceCheck_10 = String.valueOf(row29.Description);
        }
    } catch(java.lang.Exception e) {
globalMap.put("tSchemaComplianceCheck_10_ERROR_MESSAGE",e.getMessage());
        ifPassedThrough = false;
        errorCodeThrough += 2;
        errorMessageThrough += "|wrong type";
    }
            resultErrorCodeThrough = handleErrorCode(errorCodeThrough,resultErrorCodeThrough);
            errorCodeThrough = 0;
            resultErrorMessageThrough = handleErrorMessage(errorMessageThrough,resultErrorMessageThrough,"Description:");
            errorMessageThrough = "";
        }
    }
    RowSetValueUtil_tSchemaComplianceCheck_10 rsvUtil_tSchemaComplianceCheck_10 = new RowSetValueUtil_tSchemaComplianceCheck_10();

 



/**
 * [tSchemaComplianceCheck_10 begin ] stop
 */



	
	/**
	 * [tUniqRow_10 begin ] start
	 */

	

	
		
		ok_Hash.put("tUniqRow_10", false);
		start_Hash.put("tUniqRow_10", System.currentTimeMillis());
		
	
	currentComponent="tUniqRow_10";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row28");
					}
				
		int tos_count_tUniqRow_10 = 0;
		

	
		class KeyStruct_tUniqRow_10 {
	
			private static final int DEFAULT_HASHCODE = 1;
		    private static final int PRIME = 31;
		    private int hashCode = DEFAULT_HASHCODE;
		    public boolean hashCodeDirty = true;
	
	        
					Integer IDPromotion;        
	        
		    @Override
			public int hashCode() {
				if (this.hashCodeDirty) {
					final int prime = PRIME;
					int result = DEFAULT_HASHCODE;
			
								result = prime * result + ((this.IDPromotion == null) ? 0 : this.IDPromotion.hashCode());
								
		    		this.hashCode = result;
		    		this.hashCodeDirty = false;		
				}
				return this.hashCode;
			}
			
			@Override
			public boolean equals(Object obj) {
				if (this == obj) return true;
				if (obj == null) return false;
				if (getClass() != obj.getClass()) return false;
				final KeyStruct_tUniqRow_10 other = (KeyStruct_tUniqRow_10) obj;
				
									if (this.IDPromotion == null) {
										if (other.IDPromotion != null) 
											return false;
								
									} else if (!this.IDPromotion.equals(other.IDPromotion))
								 
										return false;
								
				
				return true;
			}
	  
	        
		}

	
int nb_uniques_tUniqRow_10 = 0;
int nb_duplicates_tUniqRow_10 = 0;
KeyStruct_tUniqRow_10 finder_tUniqRow_10 = new KeyStruct_tUniqRow_10();
java.util.Set<KeyStruct_tUniqRow_10> keystUniqRow_10 = new java.util.HashSet<KeyStruct_tUniqRow_10>(); 

 



/**
 * [tUniqRow_10 begin ] stop
 */



	
	/**
	 * [tFileInputDelimited_10 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileInputDelimited_10", false);
		start_Hash.put("tFileInputDelimited_10", System.currentTimeMillis());
		
	
	currentComponent="tFileInputDelimited_10";

	
		int tos_count_tFileInputDelimited_10 = 0;
		
	
	
	
 
	
	
	final routines.system.RowState rowstate_tFileInputDelimited_10 = new routines.system.RowState();
	
	
				int nb_line_tFileInputDelimited_10 = 0;
				org.talend.fileprocess.FileInputDelimited fid_tFileInputDelimited_10 = null;
				int limit_tFileInputDelimited_10 = -1;
				try{
					
						Object filename_tFileInputDelimited_10 = context.source_path+"promotion.csv";
						if(filename_tFileInputDelimited_10 instanceof java.io.InputStream){
							
			int footer_value_tFileInputDelimited_10 = 0, random_value_tFileInputDelimited_10 = -1;
			if(footer_value_tFileInputDelimited_10 >0 || random_value_tFileInputDelimited_10 > 0){
				throw new java.lang.Exception("When the input source is a stream,footer and random shouldn't be bigger than 0.");				
			}
		
						}
						try {
							fid_tFileInputDelimited_10 = new org.talend.fileprocess.FileInputDelimited(context.source_path+"promotion.csv", "UTF-8",";","\n",false,1,0,
									limit_tFileInputDelimited_10
								,-1, false);
						} catch(java.lang.Exception e) {
globalMap.put("tFileInputDelimited_10_ERROR_MESSAGE",e.getMessage());
							
								
								System.err.println(e.getMessage());
							
						}
					
				    
					while (fid_tFileInputDelimited_10!=null && fid_tFileInputDelimited_10.nextRecord()) {
						rowstate_tFileInputDelimited_10.reset();
						
			    						row28 = null;			
												
									boolean whetherReject_tFileInputDelimited_10 = false;
									row28 = new row28Struct();
									try {
										
				int columnIndexWithD_tFileInputDelimited_10 = 0;
				
					String temp = ""; 
				
					columnIndexWithD_tFileInputDelimited_10 = 0;
					
						temp = fid_tFileInputDelimited_10.get(columnIndexWithD_tFileInputDelimited_10);
						if(temp.length() > 0) {
							
								try {
								
    								row28.IDPromotion = ParserUtils.parseTo_Integer(temp);
    							
    							} catch(java.lang.Exception ex_tFileInputDelimited_10) {
globalMap.put("tFileInputDelimited_10_ERROR_MESSAGE",ex_tFileInputDelimited_10.getMessage());
									rowstate_tFileInputDelimited_10.setException(new RuntimeException(String.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
										"IDPromotion", "row28", temp, ex_tFileInputDelimited_10), ex_tFileInputDelimited_10));
								}
    							
						} else {						
							
								
									row28.IDPromotion = null;
								
							
						}
					
				
					columnIndexWithD_tFileInputDelimited_10 = 1;
					
							row28.NomPromotion = fid_tFileInputDelimited_10.get(columnIndexWithD_tFileInputDelimited_10);
						
				
					columnIndexWithD_tFileInputDelimited_10 = 2;
					
							row28.Description = fid_tFileInputDelimited_10.get(columnIndexWithD_tFileInputDelimited_10);
						
				
				
										
										if(rowstate_tFileInputDelimited_10.getException()!=null) {
											throw rowstate_tFileInputDelimited_10.getException();
										}
										
										
							
			    					} catch (java.lang.Exception e) {
globalMap.put("tFileInputDelimited_10_ERROR_MESSAGE",e.getMessage());
			        					whetherReject_tFileInputDelimited_10 = true;
			        					
			                					System.err.println(e.getMessage());
			                					row28 = null;
			                				
										
			    					}
								

 



/**
 * [tFileInputDelimited_10 begin ] stop
 */
	
	/**
	 * [tFileInputDelimited_10 main ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_10";

	

 


	tos_count_tFileInputDelimited_10++;

/**
 * [tFileInputDelimited_10 main ] stop
 */
	
	/**
	 * [tFileInputDelimited_10 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_10";

	

 



/**
 * [tFileInputDelimited_10 process_data_begin ] stop
 */
// Start of branch "row28"
if(row28 != null) { 



	
	/**
	 * [tUniqRow_10 main ] start
	 */

	

	
	
	currentComponent="tUniqRow_10";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row28"
						
						);
					}
					
row29 = null;			
finder_tUniqRow_10.IDPromotion = row28.IDPromotion;	
finder_tUniqRow_10.hashCodeDirty = true;
if (!keystUniqRow_10.contains(finder_tUniqRow_10)) {
		KeyStruct_tUniqRow_10 new_tUniqRow_10 = new KeyStruct_tUniqRow_10();

		
new_tUniqRow_10.IDPromotion = row28.IDPromotion;
		
		keystUniqRow_10.add(new_tUniqRow_10);if(row29 == null){ 
	
	row29 = new row29Struct();
}row29.IDPromotion = row28.IDPromotion;			row29.NomPromotion = row28.NomPromotion;			row29.Description = row28.Description;					
		nb_uniques_tUniqRow_10++;
	} else {
	  nb_duplicates_tUniqRow_10++;
	}

 


	tos_count_tUniqRow_10++;

/**
 * [tUniqRow_10 main ] stop
 */
	
	/**
	 * [tUniqRow_10 process_data_begin ] start
	 */

	

	
	
	currentComponent="tUniqRow_10";

	

 



/**
 * [tUniqRow_10 process_data_begin ] stop
 */
// Start of branch "row29"
if(row29 != null) { 



	
	/**
	 * [tSchemaComplianceCheck_10 main ] start
	 */

	

	
	
	currentComponent="tSchemaComplianceCheck_10";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row29"
						
						);
					}
					
	row30 = null;
	rsvUtil_tSchemaComplianceCheck_10.setRowValue_0(row29);
	if (rsvUtil_tSchemaComplianceCheck_10.ifPassedThrough) {
		row30 = new row30Struct();
		row30.IDPromotion = row29.IDPromotion;
		row30.NomPromotion = row29.NomPromotion;
		row30.Description = row29.Description;
	}
	rsvUtil_tSchemaComplianceCheck_10.reset();

 


	tos_count_tSchemaComplianceCheck_10++;

/**
 * [tSchemaComplianceCheck_10 main ] stop
 */
	
	/**
	 * [tSchemaComplianceCheck_10 process_data_begin ] start
	 */

	

	
	
	currentComponent="tSchemaComplianceCheck_10";

	

 



/**
 * [tSchemaComplianceCheck_10 process_data_begin ] stop
 */
// Start of branch "row30"
if(row30 != null) { 



	
	/**
	 * [tMap_5 main ] start
	 */

	

	
	
	currentComponent="tMap_5";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row30"
						
						);
					}
					

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_5 = false;
		

        // ###############################
        // # Input tables (lookups)
		  boolean rejectedInnerJoin_tMap_5 = false;
		  boolean mainRowRejected_tMap_5 = false;
            				    								  
		// ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_5__Struct Var = Var__tMap_5;// ###############################
        // ###############################
        // # Output tables

STG_DIM_PROMOTION = null;


// # Output table : 'STG_DIM_PROMOTION'
STG_DIM_PROMOTION_tmp.ID_PROMOTION = row30.IDPromotion ;
STG_DIM_PROMOTION_tmp.NOM_PROMOTION = row30.NomPromotion ;
STG_DIM_PROMOTION_tmp.DESCRIPTION = row30.Description ;
STG_DIM_PROMOTION = STG_DIM_PROMOTION_tmp;
// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_5 = false;










 


	tos_count_tMap_5++;

/**
 * [tMap_5 main ] stop
 */
	
	/**
	 * [tMap_5 process_data_begin ] start
	 */

	

	
	
	currentComponent="tMap_5";

	

 



/**
 * [tMap_5 process_data_begin ] stop
 */
// Start of branch "STG_DIM_PROMOTION"
if(STG_DIM_PROMOTION != null) { 



	
	/**
	 * [tDBOutput_10 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_10";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"STG_DIM_PROMOTION"
						
						);
					}
					



        whetherReject_tDBOutput_10 = false;
                    pstmt_tDBOutput_10.setInt(1, STG_DIM_PROMOTION.ID_PROMOTION);

            int checkCount_tDBOutput_10 = -1;
            try (java.sql.ResultSet rs_tDBOutput_10 = pstmt_tDBOutput_10.executeQuery()) {
                while(rs_tDBOutput_10.next()) {
                    checkCount_tDBOutput_10 = rs_tDBOutput_10.getInt(1);
                }
            }
            if(checkCount_tDBOutput_10 > 0) {
                        if(STG_DIM_PROMOTION.NOM_PROMOTION == null) {
pstmtUpdate_tDBOutput_10.setNull(1, java.sql.Types.VARCHAR);
} else {pstmtUpdate_tDBOutput_10.setString(1, STG_DIM_PROMOTION.NOM_PROMOTION);
}

                        if(STG_DIM_PROMOTION.DESCRIPTION == null) {
pstmtUpdate_tDBOutput_10.setNull(2, java.sql.Types.VARCHAR);
} else {pstmtUpdate_tDBOutput_10.setString(2, STG_DIM_PROMOTION.DESCRIPTION);
}

                        pstmtUpdate_tDBOutput_10.setInt(3 + count_tDBOutput_10, STG_DIM_PROMOTION.ID_PROMOTION);

                try {
                    int processedCount_tDBOutput_10 = pstmtUpdate_tDBOutput_10.executeUpdate();
                    updatedCount_tDBOutput_10 += processedCount_tDBOutput_10;
                    rowsToCommitCount_tDBOutput_10 += processedCount_tDBOutput_10;
                    nb_line_tDBOutput_10++;
                } catch(java.lang.Exception e_tDBOutput_10) {
globalMap.put("tDBOutput_10_ERROR_MESSAGE",e_tDBOutput_10.getMessage());
                    whetherReject_tDBOutput_10 = true;
                        nb_line_tDBOutput_10++;
                            System.err.print(e_tDBOutput_10.getMessage());
                }
            } else {
                        pstmtInsert_tDBOutput_10.setInt(1, STG_DIM_PROMOTION.ID_PROMOTION);

                        if(STG_DIM_PROMOTION.NOM_PROMOTION == null) {
pstmtInsert_tDBOutput_10.setNull(2, java.sql.Types.VARCHAR);
} else {pstmtInsert_tDBOutput_10.setString(2, STG_DIM_PROMOTION.NOM_PROMOTION);
}

                        if(STG_DIM_PROMOTION.DESCRIPTION == null) {
pstmtInsert_tDBOutput_10.setNull(3, java.sql.Types.VARCHAR);
} else {pstmtInsert_tDBOutput_10.setString(3, STG_DIM_PROMOTION.DESCRIPTION);
}

                try {
                    int processedCount_tDBOutput_10 = pstmtInsert_tDBOutput_10.executeUpdate();
                    insertedCount_tDBOutput_10 += processedCount_tDBOutput_10;
                    rowsToCommitCount_tDBOutput_10 += processedCount_tDBOutput_10;
                    nb_line_tDBOutput_10++;
                } catch(java.lang.Exception e_tDBOutput_10) {
globalMap.put("tDBOutput_10_ERROR_MESSAGE",e_tDBOutput_10.getMessage());
                    whetherReject_tDBOutput_10 = true;
                        nb_line_tDBOutput_10++;
                            System.err.print(e_tDBOutput_10.getMessage());
                }
            }

 


	tos_count_tDBOutput_10++;

/**
 * [tDBOutput_10 main ] stop
 */
	
	/**
	 * [tDBOutput_10 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_10";

	

 



/**
 * [tDBOutput_10 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_10 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_10";

	

 



/**
 * [tDBOutput_10 process_data_end ] stop
 */

} // End of branch "STG_DIM_PROMOTION"




	
	/**
	 * [tMap_5 process_data_end ] start
	 */

	

	
	
	currentComponent="tMap_5";

	

 



/**
 * [tMap_5 process_data_end ] stop
 */

} // End of branch "row30"




	
	/**
	 * [tSchemaComplianceCheck_10 process_data_end ] start
	 */

	

	
	
	currentComponent="tSchemaComplianceCheck_10";

	

 



/**
 * [tSchemaComplianceCheck_10 process_data_end ] stop
 */

} // End of branch "row29"




	
	/**
	 * [tUniqRow_10 process_data_end ] start
	 */

	

	
	
	currentComponent="tUniqRow_10";

	

 



/**
 * [tUniqRow_10 process_data_end ] stop
 */

} // End of branch "row28"




	
	/**
	 * [tFileInputDelimited_10 process_data_end ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_10";

	

 



/**
 * [tFileInputDelimited_10 process_data_end ] stop
 */
	
	/**
	 * [tFileInputDelimited_10 end ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_10";

	



            }
            }finally{
                if(!((Object)(context.source_path+"promotion.csv") instanceof java.io.InputStream)){
                	if(fid_tFileInputDelimited_10!=null){
                		fid_tFileInputDelimited_10.close();
                	}
                }
                if(fid_tFileInputDelimited_10!=null){
                	globalMap.put("tFileInputDelimited_10_NB_LINE", fid_tFileInputDelimited_10.getRowNumber());
					
                }
			}
			  

 

ok_Hash.put("tFileInputDelimited_10", true);
end_Hash.put("tFileInputDelimited_10", System.currentTimeMillis());




/**
 * [tFileInputDelimited_10 end ] stop
 */

	
	/**
	 * [tUniqRow_10 end ] start
	 */

	

	
	
	currentComponent="tUniqRow_10";

	

globalMap.put("tUniqRow_10_NB_UNIQUES",nb_uniques_tUniqRow_10);
globalMap.put("tUniqRow_10_NB_DUPLICATES",nb_duplicates_tUniqRow_10);

				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row28");
			  	}
			  	
 

ok_Hash.put("tUniqRow_10", true);
end_Hash.put("tUniqRow_10", System.currentTimeMillis());




/**
 * [tUniqRow_10 end ] stop
 */

	
	/**
	 * [tSchemaComplianceCheck_10 end ] start
	 */

	

	
	
	currentComponent="tSchemaComplianceCheck_10";

	

				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row29");
			  	}
			  	
 

ok_Hash.put("tSchemaComplianceCheck_10", true);
end_Hash.put("tSchemaComplianceCheck_10", System.currentTimeMillis());




/**
 * [tSchemaComplianceCheck_10 end ] stop
 */

	
	/**
	 * [tMap_5 end ] start
	 */

	

	
	
	currentComponent="tMap_5";

	


// ###############################
// # Lookup hashes releasing
// ###############################      





				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row30");
			  	}
			  	
 

ok_Hash.put("tMap_5", true);
end_Hash.put("tMap_5", System.currentTimeMillis());




/**
 * [tMap_5 end ] stop
 */

	
	/**
	 * [tDBOutput_10 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_10";

	
	



	
        if(pstmtUpdate_tDBOutput_10 != null){
            pstmtUpdate_tDBOutput_10.close();
            resourceMap.remove("pstmtUpdate_tDBOutput_10");
        }
        if(pstmtInsert_tDBOutput_10 != null){
            pstmtInsert_tDBOutput_10.close();
            resourceMap.remove("pstmtInsert_tDBOutput_10");
        }
        if(pstmt_tDBOutput_10 != null) {
            pstmt_tDBOutput_10.close();
            resourceMap.remove("pstmt_tDBOutput_10");
        }
    resourceMap.put("statementClosed_tDBOutput_10", true);

	
	nb_line_deleted_tDBOutput_10=nb_line_deleted_tDBOutput_10+ deletedCount_tDBOutput_10;
	nb_line_update_tDBOutput_10=nb_line_update_tDBOutput_10 + updatedCount_tDBOutput_10;
	nb_line_inserted_tDBOutput_10=nb_line_inserted_tDBOutput_10 + insertedCount_tDBOutput_10;
	nb_line_rejected_tDBOutput_10=nb_line_rejected_tDBOutput_10 + rejectedCount_tDBOutput_10;
	
        globalMap.put("tDBOutput_10_NB_LINE",nb_line_tDBOutput_10);
        globalMap.put("tDBOutput_10_NB_LINE_UPDATED",nb_line_update_tDBOutput_10);
        globalMap.put("tDBOutput_10_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_10);
        globalMap.put("tDBOutput_10_NB_LINE_DELETED",nb_line_deleted_tDBOutput_10);
        globalMap.put("tDBOutput_10_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_10);
    

	



				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"STG_DIM_PROMOTION");
			  	}
			  	
 

ok_Hash.put("tDBOutput_10", true);
end_Hash.put("tDBOutput_10", System.currentTimeMillis());




/**
 * [tDBOutput_10 end ] stop
 */












				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tFileInputDelimited_10:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk13", 0, "ok");
								} 
							
							tFileInputDelimited_11Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFileInputDelimited_10 finally ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_10";

	

 



/**
 * [tFileInputDelimited_10 finally ] stop
 */

	
	/**
	 * [tUniqRow_10 finally ] start
	 */

	

	
	
	currentComponent="tUniqRow_10";

	

 



/**
 * [tUniqRow_10 finally ] stop
 */

	
	/**
	 * [tSchemaComplianceCheck_10 finally ] start
	 */

	

	
	
	currentComponent="tSchemaComplianceCheck_10";

	

 



/**
 * [tSchemaComplianceCheck_10 finally ] stop
 */

	
	/**
	 * [tMap_5 finally ] start
	 */

	

	
	
	currentComponent="tMap_5";

	

 



/**
 * [tMap_5 finally ] stop
 */

	
	/**
	 * [tDBOutput_10 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_10";

	



    if (resourceMap.get("statementClosed_tDBOutput_10") == null) {
                java.sql.PreparedStatement pstmtUpdateToClose_tDBOutput_10 = null;
                if ((pstmtUpdateToClose_tDBOutput_10 = (java.sql.PreparedStatement) resourceMap.remove("pstmtUpdate_tDBOutput_10")) != null) {
                    pstmtUpdateToClose_tDBOutput_10.close();
                }
                java.sql.PreparedStatement pstmtInsertToClose_tDBOutput_10 = null;
                if ((pstmtInsertToClose_tDBOutput_10 = (java.sql.PreparedStatement) resourceMap.remove("pstmtInsert_tDBOutput_10")) != null) {
                    pstmtInsertToClose_tDBOutput_10.close();
                }
                java.sql.PreparedStatement pstmtToClose_tDBOutput_10 = null;
                if ((pstmtToClose_tDBOutput_10 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_10")) != null) {
                    pstmtToClose_tDBOutput_10.close();
                }
    }
 



/**
 * [tDBOutput_10 finally ] stop
 */












				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFileInputDelimited_10_SUBPROCESS_STATE", 1);
	}
	


public static class OUT_STG_DIM_CLASSEStruct implements routines.system.IPersistableRow<OUT_STG_DIM_CLASSEStruct> {
    final static byte[] commonByteArrayLock_LOCAL_PROJECT_STG_Load = new byte[0];
    static byte[] commonByteArray_LOCAL_PROJECT_STG_Load = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int ID_CLASSE;

				public int getID_CLASSE () {
					return this.ID_CLASSE;
				}
				
			    public String NOM_CLASSE;

				public String getNOM_CLASSE () {
					return this.NOM_CLASSE;
				}
				
			    public String AVANTAGES;

				public String getAVANTAGES () {
					return this.AVANTAGES;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.ID_CLASSE;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final OUT_STG_DIM_CLASSEStruct other = (OUT_STG_DIM_CLASSEStruct) obj;
		
						if (this.ID_CLASSE != other.ID_CLASSE)
							return false;
					

		return true;
    }

	public void copyDataTo(OUT_STG_DIM_CLASSEStruct other) {

		other.ID_CLASSE = this.ID_CLASSE;
	            other.NOM_CLASSE = this.NOM_CLASSE;
	            other.AVANTAGES = this.AVANTAGES;
	            
	}

	public void copyKeysDataTo(OUT_STG_DIM_CLASSEStruct other) {

		other.ID_CLASSE = this.ID_CLASSE;
	            	
	}




	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
			        this.ID_CLASSE = dis.readInt();
					
					this.NOM_CLASSE = readString(dis);
					
					this.AVANTAGES = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
			        this.ID_CLASSE = dis.readInt();
					
					this.NOM_CLASSE = readString(dis);
					
					this.AVANTAGES = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.ID_CLASSE);
					
					// String
				
						writeString(this.NOM_CLASSE,dos);
					
					// String
				
						writeString(this.AVANTAGES,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.ID_CLASSE);
					
					// String
				
						writeString(this.NOM_CLASSE,dos);
					
					// String
				
						writeString(this.AVANTAGES,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("ID_CLASSE="+String.valueOf(ID_CLASSE));
		sb.append(",NOM_CLASSE="+NOM_CLASSE);
		sb.append(",AVANTAGES="+AVANTAGES);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(OUT_STG_DIM_CLASSEStruct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.ID_CLASSE, other.ID_CLASSE);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row33Struct implements routines.system.IPersistableRow<row33Struct> {
    final static byte[] commonByteArrayLock_LOCAL_PROJECT_STG_Load = new byte[0];
    static byte[] commonByteArray_LOCAL_PROJECT_STG_Load = new byte[0];

	
			    public Integer IDClasse;

				public Integer getIDClasse () {
					return this.IDClasse;
				}
				
			    public String NomClasse;

				public String getNomClasse () {
					return this.NomClasse;
				}
				
			    public String Avantages;

				public String getAvantages () {
					return this.Avantages;
				}
				


	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
						this.IDClasse = readInteger(dis);
					
					this.NomClasse = readString(dis);
					
					this.Avantages = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
						this.IDClasse = readInteger(dis);
					
					this.NomClasse = readString(dis);
					
					this.Avantages = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.IDClasse,dos);
					
					// String
				
						writeString(this.NomClasse,dos);
					
					// String
				
						writeString(this.Avantages,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// Integer
				
						writeInteger(this.IDClasse,dos);
					
					// String
				
						writeString(this.NomClasse,dos);
					
					// String
				
						writeString(this.Avantages,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("IDClasse="+String.valueOf(IDClasse));
		sb.append(",NomClasse="+NomClasse);
		sb.append(",Avantages="+Avantages);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row33Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row32Struct implements routines.system.IPersistableRow<row32Struct> {
    final static byte[] commonByteArrayLock_LOCAL_PROJECT_STG_Load = new byte[0];
    static byte[] commonByteArray_LOCAL_PROJECT_STG_Load = new byte[0];

	
			    public Integer IDClasse;

				public Integer getIDClasse () {
					return this.IDClasse;
				}
				
			    public String NomClasse;

				public String getNomClasse () {
					return this.NomClasse;
				}
				
			    public String Avantages;

				public String getAvantages () {
					return this.Avantages;
				}
				


	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
						this.IDClasse = readInteger(dis);
					
					this.NomClasse = readString(dis);
					
					this.Avantages = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
						this.IDClasse = readInteger(dis);
					
					this.NomClasse = readString(dis);
					
					this.Avantages = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.IDClasse,dos);
					
					// String
				
						writeString(this.NomClasse,dos);
					
					// String
				
						writeString(this.Avantages,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// Integer
				
						writeInteger(this.IDClasse,dos);
					
					// String
				
						writeString(this.NomClasse,dos);
					
					// String
				
						writeString(this.Avantages,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("IDClasse="+String.valueOf(IDClasse));
		sb.append(",NomClasse="+NomClasse);
		sb.append(",Avantages="+Avantages);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row32Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row31Struct implements routines.system.IPersistableRow<row31Struct> {
    final static byte[] commonByteArrayLock_LOCAL_PROJECT_STG_Load = new byte[0];
    static byte[] commonByteArray_LOCAL_PROJECT_STG_Load = new byte[0];

	
			    public Integer IDClasse;

				public Integer getIDClasse () {
					return this.IDClasse;
				}
				
			    public String NomClasse;

				public String getNomClasse () {
					return this.NomClasse;
				}
				
			    public String Avantages;

				public String getAvantages () {
					return this.Avantages;
				}
				


	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
						this.IDClasse = readInteger(dis);
					
					this.NomClasse = readString(dis);
					
					this.Avantages = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
						this.IDClasse = readInteger(dis);
					
					this.NomClasse = readString(dis);
					
					this.Avantages = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.IDClasse,dos);
					
					// String
				
						writeString(this.NomClasse,dos);
					
					// String
				
						writeString(this.Avantages,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// Integer
				
						writeInteger(this.IDClasse,dos);
					
					// String
				
						writeString(this.NomClasse,dos);
					
					// String
				
						writeString(this.Avantages,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("IDClasse="+String.valueOf(IDClasse));
		sb.append(",NomClasse="+NomClasse);
		sb.append(",Avantages="+Avantages);
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row31Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tFileInputDelimited_11Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFileInputDelimited_11_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row31Struct row31 = new row31Struct();
row32Struct row32 = new row32Struct();
row33Struct row33 = new row33Struct();
OUT_STG_DIM_CLASSEStruct OUT_STG_DIM_CLASSE = new OUT_STG_DIM_CLASSEStruct();







	
	/**
	 * [tDBOutput_11 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_11", false);
		start_Hash.put("tDBOutput_11", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_11";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"OUT_STG_DIM_CLASSE");
					}
				
		int tos_count_tDBOutput_11 = 0;
		






        int updateKeyCount_tDBOutput_11 = 1;
        if(updateKeyCount_tDBOutput_11 < 1) {
            throw new RuntimeException("For update, Schema must have a key");
        } else if (updateKeyCount_tDBOutput_11 == 3 && true) {
                    System.err.println("For update, every Schema column can not be a key");
        }
    
    int nb_line_tDBOutput_11 = 0;
    int nb_line_update_tDBOutput_11 = 0;
    int nb_line_inserted_tDBOutput_11 = 0;
    int nb_line_deleted_tDBOutput_11 = 0;
    int nb_line_rejected_tDBOutput_11 = 0;

    int tmp_batchUpdateCount_tDBOutput_11 = 0;

    int deletedCount_tDBOutput_11=0;
    int updatedCount_tDBOutput_11=0;
    int insertedCount_tDBOutput_11=0;
    int rowsToCommitCount_tDBOutput_11=0;
    int rejectedCount_tDBOutput_11=0;

    boolean whetherReject_tDBOutput_11 = false;

    java.sql.Connection conn_tDBOutput_11 = null;

    //optional table
    String dbschema_tDBOutput_11 = null;
    String tableName_tDBOutput_11 = null;
        dbschema_tDBOutput_11 = (String)globalMap.get("dbschema_tDBConnection_2");
		
        conn_tDBOutput_11 = (java.sql.Connection)globalMap.get("conn_tDBConnection_2");
        int count_tDBOutput_11=0;

        if(dbschema_tDBOutput_11 == null || dbschema_tDBOutput_11.trim().length() == 0) {
            tableName_tDBOutput_11 = ("STG_DIM_CLASSE");
        } else {
            tableName_tDBOutput_11 = dbschema_tDBOutput_11 + "." + ("STG_DIM_CLASSE");
        }
            try (java.sql.Statement stmtClear_tDBOutput_11 = conn_tDBOutput_11.createStatement()) {
                stmtClear_tDBOutput_11.executeUpdate("DELETE FROM " + tableName_tDBOutput_11 + "");
            }
                java.sql.PreparedStatement pstmt_tDBOutput_11 = conn_tDBOutput_11.prepareStatement("SELECT COUNT(1) FROM " + tableName_tDBOutput_11 + " WHERE ID_CLASSE = ?");
                resourceMap.put("pstmt_tDBOutput_11", pstmt_tDBOutput_11);
                String insert_tDBOutput_11 = "INSERT INTO " + tableName_tDBOutput_11 + " (ID_CLASSE,NOM_CLASSE,AVANTAGES) VALUES (?,?,?)";    
                java.sql.PreparedStatement pstmtInsert_tDBOutput_11 = conn_tDBOutput_11.prepareStatement(insert_tDBOutput_11);
                resourceMap.put("pstmtInsert_tDBOutput_11", pstmtInsert_tDBOutput_11);
                String update_tDBOutput_11 = "UPDATE " + tableName_tDBOutput_11 + " SET NOM_CLASSE = ?,AVANTAGES = ? WHERE ID_CLASSE = ?";
                java.sql.PreparedStatement pstmtUpdate_tDBOutput_11 = conn_tDBOutput_11.prepareStatement(update_tDBOutput_11);
                resourceMap.put("pstmtUpdate_tDBOutput_11", pstmtUpdate_tDBOutput_11);





 



/**
 * [tDBOutput_11 begin ] stop
 */



	
	/**
	 * [tMap_12 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_12", false);
		start_Hash.put("tMap_12", System.currentTimeMillis());
		
	
	currentComponent="tMap_12";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row33");
					}
				
		int tos_count_tMap_12 = 0;
		




// ###############################
// # Lookup's keys initialization
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_12__Struct  {
}
Var__tMap_12__Struct Var__tMap_12 = new Var__tMap_12__Struct();
// ###############################

// ###############################
// # Outputs initialization
OUT_STG_DIM_CLASSEStruct OUT_STG_DIM_CLASSE_tmp = new OUT_STG_DIM_CLASSEStruct();
// ###############################

        
        



        









 



/**
 * [tMap_12 begin ] stop
 */



	
	/**
	 * [tSchemaComplianceCheck_11 begin ] start
	 */

	

	
		
		ok_Hash.put("tSchemaComplianceCheck_11", false);
		start_Hash.put("tSchemaComplianceCheck_11", System.currentTimeMillis());
		
	
	currentComponent="tSchemaComplianceCheck_11";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row32");
					}
				
		int tos_count_tSchemaComplianceCheck_11 = 0;
		

    class RowSetValueUtil_tSchemaComplianceCheck_11 {

        boolean ifPassedThrough = true;
        int errorCodeThrough = 0;
        String errorMessageThrough = "";
        int resultErrorCodeThrough = 0;
        String resultErrorMessageThrough = "";
        String tmpContentThrough = null;

        boolean ifPassed = true;
        int errorCode = 0;
        String errorMessage = "";

        void handleBigdecimalPrecision(String data, int iPrecision, int maxLength){
            //number of digits before the decimal point(ignoring frontend zeroes)
            int len1 = 0;
            int len2 = 0;
            ifPassed = true;
            errorCode = 0;
            errorMessage = "";
            if(data.startsWith("-")){
                data = data.substring(1);
            }
            data = org.apache.commons.lang.StringUtils.stripStart(data, "0");

            if(data.indexOf(".") >= 0){
                len1 = data.indexOf(".");
                data = org.apache.commons.lang.StringUtils.stripEnd(data, "0");
                len2 = data.length() - (len1 + 1);
            }else{
                len1 = data.length();
            }

            if (iPrecision < len2) {
                ifPassed = false;
                errorCode += 8;
                errorMessage += "|precision Non-matches";
            } else if (maxLength < len1 + iPrecision) {
                ifPassed = false;
                errorCode += 8;
                errorMessage += "|invalid Length setting is unsuitable for Precision";
            }
        }

        int handleErrorCode(int errorCode, int resultErrorCode){
            if (errorCode > 0) {
                if (resultErrorCode > 0) {
                    resultErrorCode = 16;
                } else {
                    resultErrorCode = errorCode;
                }
            }
            return resultErrorCode;
        }

        String handleErrorMessage(String errorMessage, String resultErrorMessage, String columnLabel){
            if (errorMessage.length() > 0) {
                if (resultErrorMessage.length() > 0) {
                    resultErrorMessage += ";"+ errorMessage.replaceFirst("\\|", columnLabel);
                } else {
                    resultErrorMessage = errorMessage.replaceFirst("\\|", columnLabel);
                }
            }
            return resultErrorMessage;
        }

        void reset(){
            ifPassedThrough = true;
            errorCodeThrough = 0;
            errorMessageThrough = "";
            resultErrorCodeThrough = 0;
            resultErrorMessageThrough = "";
            tmpContentThrough = null;

            ifPassed = true;
            errorCode = 0;
            errorMessage = "";
        }

        void setRowValue_0(row32Struct row32) {
    // validate nullable (empty as null)
    if ((row32.IDClasse == null) || ("".equals(row32.IDClasse))) {
        ifPassedThrough = false;
        errorCodeThrough += 4;
        errorMessageThrough += "|empty or null";
    }
            resultErrorCodeThrough = handleErrorCode(errorCodeThrough,resultErrorCodeThrough);
            errorCodeThrough = 0;
            resultErrorMessageThrough = handleErrorMessage(errorMessageThrough,resultErrorMessageThrough,"IDClasse:");
            errorMessageThrough = "";
    // validate nullable (empty as null)
    if ((row32.NomClasse == null) || ("".equals(row32.NomClasse))) {
        ifPassedThrough = false;
        errorCodeThrough += 4;
        errorMessageThrough += "|empty or null";
    }    try {
        if(
        row32.NomClasse != null
        ) {
            String tester_tSchemaComplianceCheck_11 = String.valueOf(row32.NomClasse);
        }
    } catch(java.lang.Exception e) {
globalMap.put("tSchemaComplianceCheck_11_ERROR_MESSAGE",e.getMessage());
        ifPassedThrough = false;
        errorCodeThrough += 2;
        errorMessageThrough += "|wrong type";
    }
            resultErrorCodeThrough = handleErrorCode(errorCodeThrough,resultErrorCodeThrough);
            errorCodeThrough = 0;
            resultErrorMessageThrough = handleErrorMessage(errorMessageThrough,resultErrorMessageThrough,"NomClasse:");
            errorMessageThrough = "";
    // validate nullable (empty as null)
    if ((row32.Avantages == null) || ("".equals(row32.Avantages))) {
        ifPassedThrough = false;
        errorCodeThrough += 4;
        errorMessageThrough += "|empty or null";
    }    try {
        if(
        row32.Avantages != null
        ) {
            String tester_tSchemaComplianceCheck_11 = String.valueOf(row32.Avantages);
        }
    } catch(java.lang.Exception e) {
globalMap.put("tSchemaComplianceCheck_11_ERROR_MESSAGE",e.getMessage());
        ifPassedThrough = false;
        errorCodeThrough += 2;
        errorMessageThrough += "|wrong type";
    }
            resultErrorCodeThrough = handleErrorCode(errorCodeThrough,resultErrorCodeThrough);
            errorCodeThrough = 0;
            resultErrorMessageThrough = handleErrorMessage(errorMessageThrough,resultErrorMessageThrough,"Avantages:");
            errorMessageThrough = "";
        }
    }
    RowSetValueUtil_tSchemaComplianceCheck_11 rsvUtil_tSchemaComplianceCheck_11 = new RowSetValueUtil_tSchemaComplianceCheck_11();

 



/**
 * [tSchemaComplianceCheck_11 begin ] stop
 */



	
	/**
	 * [tUniqRow_11 begin ] start
	 */

	

	
		
		ok_Hash.put("tUniqRow_11", false);
		start_Hash.put("tUniqRow_11", System.currentTimeMillis());
		
	
	currentComponent="tUniqRow_11";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row31");
					}
				
		int tos_count_tUniqRow_11 = 0;
		

int nb_uniques_tUniqRow_11 = 0;
int nb_duplicates_tUniqRow_11 = 0; 

 



/**
 * [tUniqRow_11 begin ] stop
 */



	
	/**
	 * [tFileInputDelimited_11 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileInputDelimited_11", false);
		start_Hash.put("tFileInputDelimited_11", System.currentTimeMillis());
		
	
	currentComponent="tFileInputDelimited_11";

	
		int tos_count_tFileInputDelimited_11 = 0;
		
	
	
	
 
	
	
	final routines.system.RowState rowstate_tFileInputDelimited_11 = new routines.system.RowState();
	
	
				int nb_line_tFileInputDelimited_11 = 0;
				int footer_tFileInputDelimited_11 = 0;
				int totalLinetFileInputDelimited_11 = 0;
				int limittFileInputDelimited_11 = -1;
				int lastLinetFileInputDelimited_11 = -1;	
				
				char fieldSeparator_tFileInputDelimited_11[] = null;
				
				//support passing value (property: Field Separator) by 'context.fs' or 'globalMap.get("fs")'. 
				if ( ((String)";").length() > 0 ){
					fieldSeparator_tFileInputDelimited_11 = ((String)";").toCharArray();
				}else {			
					throw new IllegalArgumentException("Field Separator must be assigned a char."); 
				}
			
				char rowSeparator_tFileInputDelimited_11[] = null;
			
				//support passing value (property: Row Separator) by 'context.rs' or 'globalMap.get("rs")'. 
				if ( ((String)"\n").length() > 0 ){
					rowSeparator_tFileInputDelimited_11 = ((String)"\n").toCharArray();
				}else {
					throw new IllegalArgumentException("Row Separator must be assigned a char."); 
				}
			
				Object filename_tFileInputDelimited_11 = /** Start field tFileInputDelimited_11:FILENAME */"C:/Users/phili/OneDrive/Documents/coursS9/conceptionSID/Conception-SID/donnees/classe.csv"/** End field tFileInputDelimited_11:FILENAME */;		
				com.talend.csv.CSVReader csvReadertFileInputDelimited_11 = null;
	
				try{
					
						String[] rowtFileInputDelimited_11=null;
						int currentLinetFileInputDelimited_11 = 0;
	        			int outputLinetFileInputDelimited_11 = 0;
						try {//TD110 begin
							if(filename_tFileInputDelimited_11 instanceof java.io.InputStream){
							
			int footer_value_tFileInputDelimited_11 = 0;
			if(footer_value_tFileInputDelimited_11 > 0){
				throw new java.lang.Exception("When the input source is a stream,footer shouldn't be bigger than 0.");
			}
		
								csvReadertFileInputDelimited_11=new com.talend.csv.CSVReader((java.io.InputStream)filename_tFileInputDelimited_11, fieldSeparator_tFileInputDelimited_11[0], "UTF-8");
							}else{
								csvReadertFileInputDelimited_11=new com.talend.csv.CSVReader(String.valueOf(filename_tFileInputDelimited_11),fieldSeparator_tFileInputDelimited_11[0], "UTF-8");
		        			}
					
					
					csvReadertFileInputDelimited_11.setTrimWhitespace(false);
					if ( (rowSeparator_tFileInputDelimited_11[0] != '\n') && (rowSeparator_tFileInputDelimited_11[0] != '\r') )
	        			csvReadertFileInputDelimited_11.setLineEnd(""+rowSeparator_tFileInputDelimited_11[0]);
						
	        				csvReadertFileInputDelimited_11.setQuoteChar('"');
						
	            				csvReadertFileInputDelimited_11.setEscapeChar(csvReadertFileInputDelimited_11.getQuoteChar());
							      
		
			
						if(footer_tFileInputDelimited_11 > 0){
						for(totalLinetFileInputDelimited_11=0;totalLinetFileInputDelimited_11 < 1; totalLinetFileInputDelimited_11++){
							csvReadertFileInputDelimited_11.readNext();
						}
						csvReadertFileInputDelimited_11.setSkipEmptyRecords(false);
			            while (csvReadertFileInputDelimited_11.readNext()) {
							
	                
	                		totalLinetFileInputDelimited_11++;
	                
							
	                
			            }
	            		int lastLineTemptFileInputDelimited_11 = totalLinetFileInputDelimited_11 - footer_tFileInputDelimited_11   < 0? 0 : totalLinetFileInputDelimited_11 - footer_tFileInputDelimited_11 ;
	            		if(lastLinetFileInputDelimited_11 > 0){
	                		lastLinetFileInputDelimited_11 = lastLinetFileInputDelimited_11 < lastLineTemptFileInputDelimited_11 ? lastLinetFileInputDelimited_11 : lastLineTemptFileInputDelimited_11; 
	            		}else {
	                		lastLinetFileInputDelimited_11 = lastLineTemptFileInputDelimited_11;
	            		}
	         
			          	csvReadertFileInputDelimited_11.close();
				        if(filename_tFileInputDelimited_11 instanceof java.io.InputStream){
				 			csvReadertFileInputDelimited_11=new com.talend.csv.CSVReader((java.io.InputStream)filename_tFileInputDelimited_11, fieldSeparator_tFileInputDelimited_11[0], "UTF-8");
		        		}else{
							csvReadertFileInputDelimited_11=new com.talend.csv.CSVReader(String.valueOf(filename_tFileInputDelimited_11),fieldSeparator_tFileInputDelimited_11[0], "UTF-8");
						}
						csvReadertFileInputDelimited_11.setTrimWhitespace(false);
						if ( (rowSeparator_tFileInputDelimited_11[0] != '\n') && (rowSeparator_tFileInputDelimited_11[0] != '\r') )	
	        				csvReadertFileInputDelimited_11.setLineEnd(""+rowSeparator_tFileInputDelimited_11[0]);
						
							csvReadertFileInputDelimited_11.setQuoteChar('"');
						
	        				csvReadertFileInputDelimited_11.setEscapeChar(csvReadertFileInputDelimited_11.getQuoteChar());
							  
	        		}
	        
			        if(limittFileInputDelimited_11 != 0){
			        	for(currentLinetFileInputDelimited_11=0;currentLinetFileInputDelimited_11 < 1;currentLinetFileInputDelimited_11++){
			        		csvReadertFileInputDelimited_11.readNext();
			        	}
			        }
			        csvReadertFileInputDelimited_11.setSkipEmptyRecords(false);
	        
	    		} catch(java.lang.Exception e) {
globalMap.put("tFileInputDelimited_11_ERROR_MESSAGE",e.getMessage());
					
						
						System.err.println(e.getMessage());
					
	    		}//TD110 end
	        
			    
	        	while ( limittFileInputDelimited_11 != 0 && csvReadertFileInputDelimited_11!=null && csvReadertFileInputDelimited_11.readNext() ) { 
	        		rowstate_tFileInputDelimited_11.reset();
	        
		        	rowtFileInputDelimited_11=csvReadertFileInputDelimited_11.getValues();
		        	
					
	        	
	        	
	        		currentLinetFileInputDelimited_11++;
	            
		            if(lastLinetFileInputDelimited_11 > -1 && currentLinetFileInputDelimited_11 > lastLinetFileInputDelimited_11) {
		                break;
	    	        }
	        	    outputLinetFileInputDelimited_11++;
	            	if (limittFileInputDelimited_11 > 0 && outputLinetFileInputDelimited_11 > limittFileInputDelimited_11) {
	                	break;
	            	}  
	                                                                      
					
	    							row31 = null;			
								
								boolean whetherReject_tFileInputDelimited_11 = false;
								row31 = new row31Struct();
								try {			
									
				char fieldSeparator_tFileInputDelimited_11_ListType[] = null;
				//support passing value (property: Field Separator) by 'context.fs' or 'globalMap.get("fs")'. 
				if ( ((String)";").length() > 0 ){
					fieldSeparator_tFileInputDelimited_11_ListType = ((String)";").toCharArray();
				}else {			
					throw new IllegalArgumentException("Field Separator must be assigned a char."); 
				}
				if(rowtFileInputDelimited_11.length == 1 && ("\015").equals(rowtFileInputDelimited_11[0])){//empty line when row separator is '\n'
					
							row31.IDClasse = null;
					
							row31.NomClasse = null;
					
							row31.Avantages = null;
					
				}else{
					
	                int columnIndexWithD_tFileInputDelimited_11 = 0; //Column Index 
	                
						columnIndexWithD_tFileInputDelimited_11 = 0;
						
						
						
						if(columnIndexWithD_tFileInputDelimited_11 < rowtFileInputDelimited_11.length){
						
						
							
								
									if(rowtFileInputDelimited_11[columnIndexWithD_tFileInputDelimited_11].length() > 0) {
										try {
									
										row31.IDClasse = ParserUtils.parseTo_Integer(rowtFileInputDelimited_11[columnIndexWithD_tFileInputDelimited_11]);
									
									
										} catch(java.lang.Exception ex_tFileInputDelimited_11) {
globalMap.put("tFileInputDelimited_11_ERROR_MESSAGE",ex_tFileInputDelimited_11.getMessage());
											rowstate_tFileInputDelimited_11.setException(new RuntimeException(String.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
												"IDClasse", "row31", rowtFileInputDelimited_11[columnIndexWithD_tFileInputDelimited_11], ex_tFileInputDelimited_11), ex_tFileInputDelimited_11));
										}
    								}else{
    									
											
												row31.IDClasse = null;
											
    									
    								}
									
									
							
						
						}else{
						
							
								row31.IDClasse = null;
							
						
						}
						
						
					
						columnIndexWithD_tFileInputDelimited_11 = 1;
						
						
						
						if(columnIndexWithD_tFileInputDelimited_11 < rowtFileInputDelimited_11.length){
						
						
							
									row31.NomClasse = rowtFileInputDelimited_11[columnIndexWithD_tFileInputDelimited_11];
									
							
						
						}else{
						
							
								row31.NomClasse = null;
							
						
						}
						
						
					
						columnIndexWithD_tFileInputDelimited_11 = 2;
						
						
						
						if(columnIndexWithD_tFileInputDelimited_11 < rowtFileInputDelimited_11.length){
						
						
							
									row31.Avantages = rowtFileInputDelimited_11[columnIndexWithD_tFileInputDelimited_11];
									
							
						
						}else{
						
							
								row31.Avantages = null;
							
						
						}
						
						
					
				}
				
									
									if(rowstate_tFileInputDelimited_11.getException()!=null) {
										throw rowstate_tFileInputDelimited_11.getException();
									}
									
									
	    						} catch (java.lang.Exception e) {
globalMap.put("tFileInputDelimited_11_ERROR_MESSAGE",e.getMessage());
							        whetherReject_tFileInputDelimited_11 = true;
        							
                							System.err.println(e.getMessage());
                							row31 = null;
                						
            							globalMap.put("tFileInputDelimited_11_ERROR_MESSAGE", e.getMessage());
            							
	    						}
	
							

 



/**
 * [tFileInputDelimited_11 begin ] stop
 */
	
	/**
	 * [tFileInputDelimited_11 main ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_11";

	

 


	tos_count_tFileInputDelimited_11++;

/**
 * [tFileInputDelimited_11 main ] stop
 */
	
	/**
	 * [tFileInputDelimited_11 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_11";

	

 



/**
 * [tFileInputDelimited_11 process_data_begin ] stop
 */
// Start of branch "row31"
if(row31 != null) { 



	
	/**
	 * [tUniqRow_11 main ] start
	 */

	

	
	
	currentComponent="tUniqRow_11";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row31"
						
						);
					}
					
row32.IDClasse = row31.IDClasse;			row32.NomClasse = row31.NomClasse;			row32.Avantages = row31.Avantages;			

 


	tos_count_tUniqRow_11++;

/**
 * [tUniqRow_11 main ] stop
 */
	
	/**
	 * [tUniqRow_11 process_data_begin ] start
	 */

	

	
	
	currentComponent="tUniqRow_11";

	

 



/**
 * [tUniqRow_11 process_data_begin ] stop
 */
// Start of branch "row32"
if(row32 != null) { 



	
	/**
	 * [tSchemaComplianceCheck_11 main ] start
	 */

	

	
	
	currentComponent="tSchemaComplianceCheck_11";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row32"
						
						);
					}
					
	row33 = null;
	rsvUtil_tSchemaComplianceCheck_11.setRowValue_0(row32);
	if (rsvUtil_tSchemaComplianceCheck_11.ifPassedThrough) {
		row33 = new row33Struct();
		row33.IDClasse = row32.IDClasse;
		row33.NomClasse = row32.NomClasse;
		row33.Avantages = row32.Avantages;
	}
	rsvUtil_tSchemaComplianceCheck_11.reset();

 


	tos_count_tSchemaComplianceCheck_11++;

/**
 * [tSchemaComplianceCheck_11 main ] stop
 */
	
	/**
	 * [tSchemaComplianceCheck_11 process_data_begin ] start
	 */

	

	
	
	currentComponent="tSchemaComplianceCheck_11";

	

 



/**
 * [tSchemaComplianceCheck_11 process_data_begin ] stop
 */
// Start of branch "row33"
if(row33 != null) { 



	
	/**
	 * [tMap_12 main ] start
	 */

	

	
	
	currentComponent="tMap_12";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row33"
						
						);
					}
					

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_12 = false;
		

        // ###############################
        // # Input tables (lookups)
		  boolean rejectedInnerJoin_tMap_12 = false;
		  boolean mainRowRejected_tMap_12 = false;
            				    								  
		// ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_12__Struct Var = Var__tMap_12;// ###############################
        // ###############################
        // # Output tables

OUT_STG_DIM_CLASSE = null;


// # Output table : 'OUT_STG_DIM_CLASSE'
OUT_STG_DIM_CLASSE_tmp.ID_CLASSE = row33.IDClasse ;
OUT_STG_DIM_CLASSE_tmp.NOM_CLASSE = row33.NomClasse ;
OUT_STG_DIM_CLASSE_tmp.AVANTAGES = row33.Avantages ;
OUT_STG_DIM_CLASSE = OUT_STG_DIM_CLASSE_tmp;
// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_12 = false;










 


	tos_count_tMap_12++;

/**
 * [tMap_12 main ] stop
 */
	
	/**
	 * [tMap_12 process_data_begin ] start
	 */

	

	
	
	currentComponent="tMap_12";

	

 



/**
 * [tMap_12 process_data_begin ] stop
 */
// Start of branch "OUT_STG_DIM_CLASSE"
if(OUT_STG_DIM_CLASSE != null) { 



	
	/**
	 * [tDBOutput_11 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_11";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"OUT_STG_DIM_CLASSE"
						
						);
					}
					



        whetherReject_tDBOutput_11 = false;
                    pstmt_tDBOutput_11.setInt(1, OUT_STG_DIM_CLASSE.ID_CLASSE);

            int checkCount_tDBOutput_11 = -1;
            try (java.sql.ResultSet rs_tDBOutput_11 = pstmt_tDBOutput_11.executeQuery()) {
                while(rs_tDBOutput_11.next()) {
                    checkCount_tDBOutput_11 = rs_tDBOutput_11.getInt(1);
                }
            }
            if(checkCount_tDBOutput_11 > 0) {
                        if(OUT_STG_DIM_CLASSE.NOM_CLASSE == null) {
pstmtUpdate_tDBOutput_11.setNull(1, java.sql.Types.VARCHAR);
} else {pstmtUpdate_tDBOutput_11.setString(1, OUT_STG_DIM_CLASSE.NOM_CLASSE);
}

                        if(OUT_STG_DIM_CLASSE.AVANTAGES == null) {
pstmtUpdate_tDBOutput_11.setNull(2, java.sql.Types.VARCHAR);
} else {pstmtUpdate_tDBOutput_11.setString(2, OUT_STG_DIM_CLASSE.AVANTAGES);
}

                        pstmtUpdate_tDBOutput_11.setInt(3 + count_tDBOutput_11, OUT_STG_DIM_CLASSE.ID_CLASSE);

                try {
                    int processedCount_tDBOutput_11 = pstmtUpdate_tDBOutput_11.executeUpdate();
                    updatedCount_tDBOutput_11 += processedCount_tDBOutput_11;
                    rowsToCommitCount_tDBOutput_11 += processedCount_tDBOutput_11;
                    nb_line_tDBOutput_11++;
                } catch(java.lang.Exception e_tDBOutput_11) {
globalMap.put("tDBOutput_11_ERROR_MESSAGE",e_tDBOutput_11.getMessage());
                    whetherReject_tDBOutput_11 = true;
                        nb_line_tDBOutput_11++;
                            System.err.print(e_tDBOutput_11.getMessage());
                }
            } else {
                        pstmtInsert_tDBOutput_11.setInt(1, OUT_STG_DIM_CLASSE.ID_CLASSE);

                        if(OUT_STG_DIM_CLASSE.NOM_CLASSE == null) {
pstmtInsert_tDBOutput_11.setNull(2, java.sql.Types.VARCHAR);
} else {pstmtInsert_tDBOutput_11.setString(2, OUT_STG_DIM_CLASSE.NOM_CLASSE);
}

                        if(OUT_STG_DIM_CLASSE.AVANTAGES == null) {
pstmtInsert_tDBOutput_11.setNull(3, java.sql.Types.VARCHAR);
} else {pstmtInsert_tDBOutput_11.setString(3, OUT_STG_DIM_CLASSE.AVANTAGES);
}

                try {
                    int processedCount_tDBOutput_11 = pstmtInsert_tDBOutput_11.executeUpdate();
                    insertedCount_tDBOutput_11 += processedCount_tDBOutput_11;
                    rowsToCommitCount_tDBOutput_11 += processedCount_tDBOutput_11;
                    nb_line_tDBOutput_11++;
                } catch(java.lang.Exception e_tDBOutput_11) {
globalMap.put("tDBOutput_11_ERROR_MESSAGE",e_tDBOutput_11.getMessage());
                    whetherReject_tDBOutput_11 = true;
                        nb_line_tDBOutput_11++;
                            System.err.print(e_tDBOutput_11.getMessage());
                }
            }

 


	tos_count_tDBOutput_11++;

/**
 * [tDBOutput_11 main ] stop
 */
	
	/**
	 * [tDBOutput_11 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_11";

	

 



/**
 * [tDBOutput_11 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_11 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_11";

	

 



/**
 * [tDBOutput_11 process_data_end ] stop
 */

} // End of branch "OUT_STG_DIM_CLASSE"




	
	/**
	 * [tMap_12 process_data_end ] start
	 */

	

	
	
	currentComponent="tMap_12";

	

 



/**
 * [tMap_12 process_data_end ] stop
 */

} // End of branch "row33"




	
	/**
	 * [tSchemaComplianceCheck_11 process_data_end ] start
	 */

	

	
	
	currentComponent="tSchemaComplianceCheck_11";

	

 



/**
 * [tSchemaComplianceCheck_11 process_data_end ] stop
 */

} // End of branch "row32"




	
	/**
	 * [tUniqRow_11 process_data_end ] start
	 */

	

	
	
	currentComponent="tUniqRow_11";

	

 



/**
 * [tUniqRow_11 process_data_end ] stop
 */

} // End of branch "row31"




	
	/**
	 * [tFileInputDelimited_11 process_data_end ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_11";

	

 



/**
 * [tFileInputDelimited_11 process_data_end ] stop
 */
	
	/**
	 * [tFileInputDelimited_11 end ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_11";

	


				nb_line_tFileInputDelimited_11++;
			}
			
			}finally{
    			if(!(filename_tFileInputDelimited_11 instanceof java.io.InputStream)){
    				if(csvReadertFileInputDelimited_11!=null){
    					csvReadertFileInputDelimited_11.close();
    				}
    			}
    			if(csvReadertFileInputDelimited_11!=null){
    				globalMap.put("tFileInputDelimited_11_NB_LINE",nb_line_tFileInputDelimited_11);
    			}
				
			}
						  

 

ok_Hash.put("tFileInputDelimited_11", true);
end_Hash.put("tFileInputDelimited_11", System.currentTimeMillis());




/**
 * [tFileInputDelimited_11 end ] stop
 */

	
	/**
	 * [tUniqRow_11 end ] start
	 */

	

	
	
	currentComponent="tUniqRow_11";

	

globalMap.put("tUniqRow_11_NB_UNIQUES",nb_uniques_tUniqRow_11);
globalMap.put("tUniqRow_11_NB_DUPLICATES",nb_duplicates_tUniqRow_11);

				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row31");
			  	}
			  	
 

ok_Hash.put("tUniqRow_11", true);
end_Hash.put("tUniqRow_11", System.currentTimeMillis());




/**
 * [tUniqRow_11 end ] stop
 */

	
	/**
	 * [tSchemaComplianceCheck_11 end ] start
	 */

	

	
	
	currentComponent="tSchemaComplianceCheck_11";

	

				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row32");
			  	}
			  	
 

ok_Hash.put("tSchemaComplianceCheck_11", true);
end_Hash.put("tSchemaComplianceCheck_11", System.currentTimeMillis());




/**
 * [tSchemaComplianceCheck_11 end ] stop
 */

	
	/**
	 * [tMap_12 end ] start
	 */

	

	
	
	currentComponent="tMap_12";

	


// ###############################
// # Lookup hashes releasing
// ###############################      





				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row33");
			  	}
			  	
 

ok_Hash.put("tMap_12", true);
end_Hash.put("tMap_12", System.currentTimeMillis());




/**
 * [tMap_12 end ] stop
 */

	
	/**
	 * [tDBOutput_11 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_11";

	
	



	
        if(pstmtUpdate_tDBOutput_11 != null){
            pstmtUpdate_tDBOutput_11.close();
            resourceMap.remove("pstmtUpdate_tDBOutput_11");
        }
        if(pstmtInsert_tDBOutput_11 != null){
            pstmtInsert_tDBOutput_11.close();
            resourceMap.remove("pstmtInsert_tDBOutput_11");
        }
        if(pstmt_tDBOutput_11 != null) {
            pstmt_tDBOutput_11.close();
            resourceMap.remove("pstmt_tDBOutput_11");
        }
    resourceMap.put("statementClosed_tDBOutput_11", true);

	
	nb_line_deleted_tDBOutput_11=nb_line_deleted_tDBOutput_11+ deletedCount_tDBOutput_11;
	nb_line_update_tDBOutput_11=nb_line_update_tDBOutput_11 + updatedCount_tDBOutput_11;
	nb_line_inserted_tDBOutput_11=nb_line_inserted_tDBOutput_11 + insertedCount_tDBOutput_11;
	nb_line_rejected_tDBOutput_11=nb_line_rejected_tDBOutput_11 + rejectedCount_tDBOutput_11;
	
        globalMap.put("tDBOutput_11_NB_LINE",nb_line_tDBOutput_11);
        globalMap.put("tDBOutput_11_NB_LINE_UPDATED",nb_line_update_tDBOutput_11);
        globalMap.put("tDBOutput_11_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_11);
        globalMap.put("tDBOutput_11_NB_LINE_DELETED",nb_line_deleted_tDBOutput_11);
        globalMap.put("tDBOutput_11_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_11);
    

	



				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"OUT_STG_DIM_CLASSE");
			  	}
			  	
 

ok_Hash.put("tDBOutput_11", true);
end_Hash.put("tDBOutput_11", System.currentTimeMillis());




/**
 * [tDBOutput_11 end ] stop
 */












				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tFileInputDelimited_11:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk14", 0, "ok");
								} 
							
							tFileInputDelimited_12Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFileInputDelimited_11 finally ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_11";

	

 



/**
 * [tFileInputDelimited_11 finally ] stop
 */

	
	/**
	 * [tUniqRow_11 finally ] start
	 */

	

	
	
	currentComponent="tUniqRow_11";

	

 



/**
 * [tUniqRow_11 finally ] stop
 */

	
	/**
	 * [tSchemaComplianceCheck_11 finally ] start
	 */

	

	
	
	currentComponent="tSchemaComplianceCheck_11";

	

 



/**
 * [tSchemaComplianceCheck_11 finally ] stop
 */

	
	/**
	 * [tMap_12 finally ] start
	 */

	

	
	
	currentComponent="tMap_12";

	

 



/**
 * [tMap_12 finally ] stop
 */

	
	/**
	 * [tDBOutput_11 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_11";

	



    if (resourceMap.get("statementClosed_tDBOutput_11") == null) {
                java.sql.PreparedStatement pstmtUpdateToClose_tDBOutput_11 = null;
                if ((pstmtUpdateToClose_tDBOutput_11 = (java.sql.PreparedStatement) resourceMap.remove("pstmtUpdate_tDBOutput_11")) != null) {
                    pstmtUpdateToClose_tDBOutput_11.close();
                }
                java.sql.PreparedStatement pstmtInsertToClose_tDBOutput_11 = null;
                if ((pstmtInsertToClose_tDBOutput_11 = (java.sql.PreparedStatement) resourceMap.remove("pstmtInsert_tDBOutput_11")) != null) {
                    pstmtInsertToClose_tDBOutput_11.close();
                }
                java.sql.PreparedStatement pstmtToClose_tDBOutput_11 = null;
                if ((pstmtToClose_tDBOutput_11 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_11")) != null) {
                    pstmtToClose_tDBOutput_11.close();
                }
    }
 



/**
 * [tDBOutput_11 finally ] stop
 */












				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFileInputDelimited_11_SUBPROCESS_STATE", 1);
	}
	


public static class OUT_STG_FAIT_SURCLASSEMENTStruct implements routines.system.IPersistableRow<OUT_STG_FAIT_SURCLASSEMENTStruct> {
    final static byte[] commonByteArrayLock_LOCAL_PROJECT_STG_Load = new byte[0];
    static byte[] commonByteArray_LOCAL_PROJECT_STG_Load = new byte[0];
	protected static final int DEFAULT_HASHCODE = 1;
    protected static final int PRIME = 31;
    protected int hashCode = DEFAULT_HASHCODE;
    public boolean hashCodeDirty = true;

    public String loopKey;



	
			    public int ID_SURCLASSEMENT;

				public int getID_SURCLASSEMENT () {
					return this.ID_SURCLASSEMENT;
				}
				
			    public int SK_BILLET_ID;

				public int getSK_BILLET_ID () {
					return this.SK_BILLET_ID;
				}
				
			    public int SK_CLASSE_ID;

				public int getSK_CLASSE_ID () {
					return this.SK_CLASSE_ID;
				}
				
			    public int SURCLASSEMENT;

				public int getSURCLASSEMENT () {
					return this.SURCLASSEMENT;
				}
				
			    public Float TARIF_SUPPLEMENTAIRE;

				public Float getTARIF_SUPPLEMENTAIRE () {
					return this.TARIF_SUPPLEMENTAIRE;
				}
				


	@Override
	public int hashCode() {
		if (this.hashCodeDirty) {
			final int prime = PRIME;
			int result = DEFAULT_HASHCODE;
	
							result = prime * result + (int) this.ID_SURCLASSEMENT;
						
    		this.hashCode = result;
    		this.hashCodeDirty = false;
		}
		return this.hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		final OUT_STG_FAIT_SURCLASSEMENTStruct other = (OUT_STG_FAIT_SURCLASSEMENTStruct) obj;
		
						if (this.ID_SURCLASSEMENT != other.ID_SURCLASSEMENT)
							return false;
					

		return true;
    }

	public void copyDataTo(OUT_STG_FAIT_SURCLASSEMENTStruct other) {

		other.ID_SURCLASSEMENT = this.ID_SURCLASSEMENT;
	            other.SK_BILLET_ID = this.SK_BILLET_ID;
	            other.SK_CLASSE_ID = this.SK_CLASSE_ID;
	            other.SURCLASSEMENT = this.SURCLASSEMENT;
	            other.TARIF_SUPPLEMENTAIRE = this.TARIF_SUPPLEMENTAIRE;
	            
	}

	public void copyKeysDataTo(OUT_STG_FAIT_SURCLASSEMENTStruct other) {

		other.ID_SURCLASSEMENT = this.ID_SURCLASSEMENT;
	            	
	}




    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
			        this.ID_SURCLASSEMENT = dis.readInt();
					
			        this.SK_BILLET_ID = dis.readInt();
					
			        this.SK_CLASSE_ID = dis.readInt();
					
			        this.SURCLASSEMENT = dis.readInt();
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.TARIF_SUPPLEMENTAIRE = null;
           				} else {
           			    	this.TARIF_SUPPLEMENTAIRE = dis.readFloat();
           				}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
			        this.ID_SURCLASSEMENT = dis.readInt();
					
			        this.SK_BILLET_ID = dis.readInt();
					
			        this.SK_CLASSE_ID = dis.readInt();
					
			        this.SURCLASSEMENT = dis.readInt();
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.TARIF_SUPPLEMENTAIRE = null;
           				} else {
           			    	this.TARIF_SUPPLEMENTAIRE = dis.readFloat();
           				}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.ID_SURCLASSEMENT);
					
					// int
				
		            	dos.writeInt(this.SK_BILLET_ID);
					
					// int
				
		            	dos.writeInt(this.SK_CLASSE_ID);
					
					// int
				
		            	dos.writeInt(this.SURCLASSEMENT);
					
					// Float
				
						if(this.TARIF_SUPPLEMENTAIRE == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.TARIF_SUPPLEMENTAIRE);
		            	}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// int
				
		            	dos.writeInt(this.ID_SURCLASSEMENT);
					
					// int
				
		            	dos.writeInt(this.SK_BILLET_ID);
					
					// int
				
		            	dos.writeInt(this.SK_CLASSE_ID);
					
					// int
				
		            	dos.writeInt(this.SURCLASSEMENT);
					
					// Float
				
						if(this.TARIF_SUPPLEMENTAIRE == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.TARIF_SUPPLEMENTAIRE);
		            	}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("ID_SURCLASSEMENT="+String.valueOf(ID_SURCLASSEMENT));
		sb.append(",SK_BILLET_ID="+String.valueOf(SK_BILLET_ID));
		sb.append(",SK_CLASSE_ID="+String.valueOf(SK_CLASSE_ID));
		sb.append(",SURCLASSEMENT="+String.valueOf(SURCLASSEMENT));
		sb.append(",TARIF_SUPPLEMENTAIRE="+String.valueOf(TARIF_SUPPLEMENTAIRE));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(OUT_STG_FAIT_SURCLASSEMENTStruct other) {

		int returnValue = -1;
		
						returnValue = checkNullsAndCompare(this.ID_SURCLASSEMENT, other.ID_SURCLASSEMENT);
						if(returnValue != 0) {
							return returnValue;
						}

					
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row36Struct implements routines.system.IPersistableRow<row36Struct> {
    final static byte[] commonByteArrayLock_LOCAL_PROJECT_STG_Load = new byte[0];
    static byte[] commonByteArray_LOCAL_PROJECT_STG_Load = new byte[0];

	
			    public Integer IDBillet;

				public Integer getIDBillet () {
					return this.IDBillet;
				}
				
			    public Integer IDClasse;

				public Integer getIDClasse () {
					return this.IDClasse;
				}
				
			    public String Surclassement;

				public String getSurclassement () {
					return this.Surclassement;
				}
				
			    public Float TarifSupplementaire;

				public Float getTarifSupplementaire () {
					return this.TarifSupplementaire;
				}
				


	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
						this.IDBillet = readInteger(dis);
					
						this.IDClasse = readInteger(dis);
					
					this.Surclassement = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.TarifSupplementaire = null;
           				} else {
           			    	this.TarifSupplementaire = dis.readFloat();
           				}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
						this.IDBillet = readInteger(dis);
					
						this.IDClasse = readInteger(dis);
					
					this.Surclassement = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.TarifSupplementaire = null;
           				} else {
           			    	this.TarifSupplementaire = dis.readFloat();
           				}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.IDBillet,dos);
					
					// Integer
				
						writeInteger(this.IDClasse,dos);
					
					// String
				
						writeString(this.Surclassement,dos);
					
					// Float
				
						if(this.TarifSupplementaire == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.TarifSupplementaire);
		            	}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// Integer
				
						writeInteger(this.IDBillet,dos);
					
					// Integer
				
						writeInteger(this.IDClasse,dos);
					
					// String
				
						writeString(this.Surclassement,dos);
					
					// Float
				
						if(this.TarifSupplementaire == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.TarifSupplementaire);
		            	}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("IDBillet="+String.valueOf(IDBillet));
		sb.append(",IDClasse="+String.valueOf(IDClasse));
		sb.append(",Surclassement="+Surclassement);
		sb.append(",TarifSupplementaire="+String.valueOf(TarifSupplementaire));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row36Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row35Struct implements routines.system.IPersistableRow<row35Struct> {
    final static byte[] commonByteArrayLock_LOCAL_PROJECT_STG_Load = new byte[0];
    static byte[] commonByteArray_LOCAL_PROJECT_STG_Load = new byte[0];

	
			    public Integer IDBillet;

				public Integer getIDBillet () {
					return this.IDBillet;
				}
				
			    public Integer IDClasse;

				public Integer getIDClasse () {
					return this.IDClasse;
				}
				
			    public String Surclassement;

				public String getSurclassement () {
					return this.Surclassement;
				}
				
			    public Float TarifSupplementaire;

				public Float getTarifSupplementaire () {
					return this.TarifSupplementaire;
				}
				


	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
						this.IDBillet = readInteger(dis);
					
						this.IDClasse = readInteger(dis);
					
					this.Surclassement = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.TarifSupplementaire = null;
           				} else {
           			    	this.TarifSupplementaire = dis.readFloat();
           				}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
						this.IDBillet = readInteger(dis);
					
						this.IDClasse = readInteger(dis);
					
					this.Surclassement = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.TarifSupplementaire = null;
           				} else {
           			    	this.TarifSupplementaire = dis.readFloat();
           				}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.IDBillet,dos);
					
					// Integer
				
						writeInteger(this.IDClasse,dos);
					
					// String
				
						writeString(this.Surclassement,dos);
					
					// Float
				
						if(this.TarifSupplementaire == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.TarifSupplementaire);
		            	}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// Integer
				
						writeInteger(this.IDBillet,dos);
					
					// Integer
				
						writeInteger(this.IDClasse,dos);
					
					// String
				
						writeString(this.Surclassement,dos);
					
					// Float
				
						if(this.TarifSupplementaire == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.TarifSupplementaire);
		            	}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("IDBillet="+String.valueOf(IDBillet));
		sb.append(",IDClasse="+String.valueOf(IDClasse));
		sb.append(",Surclassement="+Surclassement);
		sb.append(",TarifSupplementaire="+String.valueOf(TarifSupplementaire));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row35Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row34Struct implements routines.system.IPersistableRow<row34Struct> {
    final static byte[] commonByteArrayLock_LOCAL_PROJECT_STG_Load = new byte[0];
    static byte[] commonByteArray_LOCAL_PROJECT_STG_Load = new byte[0];

	
			    public Integer IDBillet;

				public Integer getIDBillet () {
					return this.IDBillet;
				}
				
			    public Integer IDClasse;

				public Integer getIDClasse () {
					return this.IDClasse;
				}
				
			    public String Surclassement;

				public String getSurclassement () {
					return this.Surclassement;
				}
				
			    public Float TarifSupplementaire;

				public Float getTarifSupplementaire () {
					return this.TarifSupplementaire;
				}
				


	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}
	
	private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}
	
	private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(intNum == null) {
			marshaller.writeByte(-1);
		} else {
			marshaller.writeByte(0);
			marshaller.writeInt(intNum);
    	}
	}

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}
	
	private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException{
		String strReturn = null;
		int length = 0;
        length = unmarshaller.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_LOCAL_PROJECT_STG_Load.length) {
				if(length < 1024 && commonByteArray_LOCAL_PROJECT_STG_Load.length == 0) {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[1024];
				} else {
   					commonByteArray_LOCAL_PROJECT_STG_Load = new byte[2 * length];
   				}
			}
			unmarshaller.readFully(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length);
			strReturn = new String(commonByteArray_LOCAL_PROJECT_STG_Load, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
    
    private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException{
		if(str == null) {
			marshaller.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
            marshaller.writeInt(byteArray.length);
            marshaller.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
						this.IDBillet = readInteger(dis);
					
						this.IDClasse = readInteger(dis);
					
					this.Surclassement = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.TarifSupplementaire = null;
           				} else {
           			    	this.TarifSupplementaire = dis.readFloat();
           				}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }
    
    public void readData(org.jboss.marshalling.Unmarshaller dis) {

		synchronized(commonByteArrayLock_LOCAL_PROJECT_STG_Load) {

        	try {

        		int length = 0;
		
						this.IDBillet = readInteger(dis);
					
						this.IDClasse = readInteger(dis);
					
					this.Surclassement = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.TarifSupplementaire = null;
           				} else {
           			    	this.TarifSupplementaire = dis.readFloat();
           				}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.IDBillet,dos);
					
					// Integer
				
						writeInteger(this.IDClasse,dos);
					
					// String
				
						writeString(this.Surclassement,dos);
					
					// Float
				
						if(this.TarifSupplementaire == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.TarifSupplementaire);
		            	}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }
    
    public void writeData(org.jboss.marshalling.Marshaller dos) {
        try {

		
					// Integer
				
						writeInteger(this.IDBillet,dos);
					
					// Integer
				
						writeInteger(this.IDClasse,dos);
					
					// String
				
						writeString(this.Surclassement,dos);
					
					// Float
				
						if(this.TarifSupplementaire == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeFloat(this.TarifSupplementaire);
		            	}
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("IDBillet="+String.valueOf(IDBillet));
		sb.append(",IDClasse="+String.valueOf(IDClasse));
		sb.append(",Surclassement="+Surclassement);
		sb.append(",TarifSupplementaire="+String.valueOf(TarifSupplementaire));
	    sb.append("]");

	    return sb.toString();
    }

    /**
     * Compare keys
     */
    public int compareTo(row34Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tFileInputDelimited_12Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFileInputDelimited_12_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row34Struct row34 = new row34Struct();
row35Struct row35 = new row35Struct();
row36Struct row36 = new row36Struct();
OUT_STG_FAIT_SURCLASSEMENTStruct OUT_STG_FAIT_SURCLASSEMENT = new OUT_STG_FAIT_SURCLASSEMENTStruct();







	
	/**
	 * [tDBOutput_12 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBOutput_12", false);
		start_Hash.put("tDBOutput_12", System.currentTimeMillis());
		
	
	currentComponent="tDBOutput_12";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"OUT_STG_FAIT_SURCLASSEMENT");
					}
				
		int tos_count_tDBOutput_12 = 0;
		






        int updateKeyCount_tDBOutput_12 = 1;
        if(updateKeyCount_tDBOutput_12 < 1) {
            throw new RuntimeException("For update, Schema must have a key");
        } else if (updateKeyCount_tDBOutput_12 == 5 && true) {
                    System.err.println("For update, every Schema column can not be a key");
        }
    
    int nb_line_tDBOutput_12 = 0;
    int nb_line_update_tDBOutput_12 = 0;
    int nb_line_inserted_tDBOutput_12 = 0;
    int nb_line_deleted_tDBOutput_12 = 0;
    int nb_line_rejected_tDBOutput_12 = 0;

    int tmp_batchUpdateCount_tDBOutput_12 = 0;

    int deletedCount_tDBOutput_12=0;
    int updatedCount_tDBOutput_12=0;
    int insertedCount_tDBOutput_12=0;
    int rowsToCommitCount_tDBOutput_12=0;
    int rejectedCount_tDBOutput_12=0;

    boolean whetherReject_tDBOutput_12 = false;

    java.sql.Connection conn_tDBOutput_12 = null;

    //optional table
    String dbschema_tDBOutput_12 = null;
    String tableName_tDBOutput_12 = null;
        dbschema_tDBOutput_12 = (String)globalMap.get("dbschema_tDBConnection_2");
		
        conn_tDBOutput_12 = (java.sql.Connection)globalMap.get("conn_tDBConnection_2");
        int count_tDBOutput_12=0;

        if(dbschema_tDBOutput_12 == null || dbschema_tDBOutput_12.trim().length() == 0) {
            tableName_tDBOutput_12 = ("STG_FAIT_SURCLASSEMENT");
        } else {
            tableName_tDBOutput_12 = dbschema_tDBOutput_12 + "." + ("STG_FAIT_SURCLASSEMENT");
        }
            try (java.sql.Statement stmtClear_tDBOutput_12 = conn_tDBOutput_12.createStatement()) {
                stmtClear_tDBOutput_12.executeUpdate("DELETE FROM " + tableName_tDBOutput_12 + "");
            }
                java.sql.PreparedStatement pstmt_tDBOutput_12 = conn_tDBOutput_12.prepareStatement("SELECT COUNT(1) FROM " + tableName_tDBOutput_12 + " WHERE ID_SURCLASSEMENT = ?");
                resourceMap.put("pstmt_tDBOutput_12", pstmt_tDBOutput_12);
                String insert_tDBOutput_12 = "INSERT INTO " + tableName_tDBOutput_12 + " (ID_SURCLASSEMENT,SK_BILLET_ID,SK_CLASSE_ID,SURCLASSEMENT,TARIF_SUPPLEMENTAIRE) VALUES (?,?,?,?,?)";    
                java.sql.PreparedStatement pstmtInsert_tDBOutput_12 = conn_tDBOutput_12.prepareStatement(insert_tDBOutput_12);
                resourceMap.put("pstmtInsert_tDBOutput_12", pstmtInsert_tDBOutput_12);
                String update_tDBOutput_12 = "UPDATE " + tableName_tDBOutput_12 + " SET SK_BILLET_ID = ?,SK_CLASSE_ID = ?,SURCLASSEMENT = ?,TARIF_SUPPLEMENTAIRE = ? WHERE ID_SURCLASSEMENT = ?";
                java.sql.PreparedStatement pstmtUpdate_tDBOutput_12 = conn_tDBOutput_12.prepareStatement(update_tDBOutput_12);
                resourceMap.put("pstmtUpdate_tDBOutput_12", pstmtUpdate_tDBOutput_12);





 



/**
 * [tDBOutput_12 begin ] stop
 */



	
	/**
	 * [tMap_13 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_13", false);
		start_Hash.put("tMap_13", System.currentTimeMillis());
		
	
	currentComponent="tMap_13";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row36");
					}
				
		int tos_count_tMap_13 = 0;
		




// ###############################
// # Lookup's keys initialization
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_13__Struct  {
}
Var__tMap_13__Struct Var__tMap_13 = new Var__tMap_13__Struct();
// ###############################

// ###############################
// # Outputs initialization
OUT_STG_FAIT_SURCLASSEMENTStruct OUT_STG_FAIT_SURCLASSEMENT_tmp = new OUT_STG_FAIT_SURCLASSEMENTStruct();
// ###############################

        
        



        









 



/**
 * [tMap_13 begin ] stop
 */



	
	/**
	 * [tSchemaComplianceCheck_12 begin ] start
	 */

	

	
		
		ok_Hash.put("tSchemaComplianceCheck_12", false);
		start_Hash.put("tSchemaComplianceCheck_12", System.currentTimeMillis());
		
	
	currentComponent="tSchemaComplianceCheck_12";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row35");
					}
				
		int tos_count_tSchemaComplianceCheck_12 = 0;
		

    class RowSetValueUtil_tSchemaComplianceCheck_12 {

        boolean ifPassedThrough = true;
        int errorCodeThrough = 0;
        String errorMessageThrough = "";
        int resultErrorCodeThrough = 0;
        String resultErrorMessageThrough = "";
        String tmpContentThrough = null;

        boolean ifPassed = true;
        int errorCode = 0;
        String errorMessage = "";

        void handleBigdecimalPrecision(String data, int iPrecision, int maxLength){
            //number of digits before the decimal point(ignoring frontend zeroes)
            int len1 = 0;
            int len2 = 0;
            ifPassed = true;
            errorCode = 0;
            errorMessage = "";
            if(data.startsWith("-")){
                data = data.substring(1);
            }
            data = org.apache.commons.lang.StringUtils.stripStart(data, "0");

            if(data.indexOf(".") >= 0){
                len1 = data.indexOf(".");
                data = org.apache.commons.lang.StringUtils.stripEnd(data, "0");
                len2 = data.length() - (len1 + 1);
            }else{
                len1 = data.length();
            }

            if (iPrecision < len2) {
                ifPassed = false;
                errorCode += 8;
                errorMessage += "|precision Non-matches";
            } else if (maxLength < len1 + iPrecision) {
                ifPassed = false;
                errorCode += 8;
                errorMessage += "|invalid Length setting is unsuitable for Precision";
            }
        }

        int handleErrorCode(int errorCode, int resultErrorCode){
            if (errorCode > 0) {
                if (resultErrorCode > 0) {
                    resultErrorCode = 16;
                } else {
                    resultErrorCode = errorCode;
                }
            }
            return resultErrorCode;
        }

        String handleErrorMessage(String errorMessage, String resultErrorMessage, String columnLabel){
            if (errorMessage.length() > 0) {
                if (resultErrorMessage.length() > 0) {
                    resultErrorMessage += ";"+ errorMessage.replaceFirst("\\|", columnLabel);
                } else {
                    resultErrorMessage = errorMessage.replaceFirst("\\|", columnLabel);
                }
            }
            return resultErrorMessage;
        }

        void reset(){
            ifPassedThrough = true;
            errorCodeThrough = 0;
            errorMessageThrough = "";
            resultErrorCodeThrough = 0;
            resultErrorMessageThrough = "";
            tmpContentThrough = null;

            ifPassed = true;
            errorCode = 0;
            errorMessage = "";
        }

        void setRowValue_0(row35Struct row35) {
    // validate nullable (empty as null)
    if ((row35.IDBillet == null) || ("".equals(row35.IDBillet))) {
        ifPassedThrough = false;
        errorCodeThrough += 4;
        errorMessageThrough += "|empty or null";
    }
            resultErrorCodeThrough = handleErrorCode(errorCodeThrough,resultErrorCodeThrough);
            errorCodeThrough = 0;
            resultErrorMessageThrough = handleErrorMessage(errorMessageThrough,resultErrorMessageThrough,"IDBillet:");
            errorMessageThrough = "";
    // validate nullable (empty as null)
    if ((row35.IDClasse == null) || ("".equals(row35.IDClasse))) {
        ifPassedThrough = false;
        errorCodeThrough += 4;
        errorMessageThrough += "|empty or null";
    }
            resultErrorCodeThrough = handleErrorCode(errorCodeThrough,resultErrorCodeThrough);
            errorCodeThrough = 0;
            resultErrorMessageThrough = handleErrorMessage(errorMessageThrough,resultErrorMessageThrough,"IDClasse:");
            errorMessageThrough = "";
    // validate nullable (empty as null)
    if ((row35.Surclassement == null) || ("".equals(row35.Surclassement))) {
        ifPassedThrough = false;
        errorCodeThrough += 4;
        errorMessageThrough += "|empty or null";
    }    try {
        if(
        row35.Surclassement != null
        ) {
            String tester_tSchemaComplianceCheck_12 = String.valueOf(row35.Surclassement);
        }
    } catch(java.lang.Exception e) {
globalMap.put("tSchemaComplianceCheck_12_ERROR_MESSAGE",e.getMessage());
        ifPassedThrough = false;
        errorCodeThrough += 2;
        errorMessageThrough += "|wrong type";
    }
            resultErrorCodeThrough = handleErrorCode(errorCodeThrough,resultErrorCodeThrough);
            errorCodeThrough = 0;
            resultErrorMessageThrough = handleErrorMessage(errorMessageThrough,resultErrorMessageThrough,"Surclassement:");
            errorMessageThrough = "";
    // validate nullable (empty as null)
    if ((row35.TarifSupplementaire == null) || ("".equals(row35.TarifSupplementaire))) {
        ifPassedThrough = false;
        errorCodeThrough += 4;
        errorMessageThrough += "|empty or null";
    }
            resultErrorCodeThrough = handleErrorCode(errorCodeThrough,resultErrorCodeThrough);
            errorCodeThrough = 0;
            resultErrorMessageThrough = handleErrorMessage(errorMessageThrough,resultErrorMessageThrough,"TarifSupplementaire:");
            errorMessageThrough = "";
        }
    }
    RowSetValueUtil_tSchemaComplianceCheck_12 rsvUtil_tSchemaComplianceCheck_12 = new RowSetValueUtil_tSchemaComplianceCheck_12();

 



/**
 * [tSchemaComplianceCheck_12 begin ] stop
 */



	
	/**
	 * [tUniqRow_12 begin ] start
	 */

	

	
		
		ok_Hash.put("tUniqRow_12", false);
		start_Hash.put("tUniqRow_12", System.currentTimeMillis());
		
	
	currentComponent="tUniqRow_12";

	
					if(execStat) {
						runStat.updateStatOnConnection(resourceMap,iterateId,0,0,"row34");
					}
				
		int tos_count_tUniqRow_12 = 0;
		

int nb_uniques_tUniqRow_12 = 0;
int nb_duplicates_tUniqRow_12 = 0; 

 



/**
 * [tUniqRow_12 begin ] stop
 */



	
	/**
	 * [tFileInputDelimited_12 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileInputDelimited_12", false);
		start_Hash.put("tFileInputDelimited_12", System.currentTimeMillis());
		
	
	currentComponent="tFileInputDelimited_12";

	
		int tos_count_tFileInputDelimited_12 = 0;
		
	
	
	
 
	
	
	final routines.system.RowState rowstate_tFileInputDelimited_12 = new routines.system.RowState();
	
	
				int nb_line_tFileInputDelimited_12 = 0;
				org.talend.fileprocess.FileInputDelimited fid_tFileInputDelimited_12 = null;
				int limit_tFileInputDelimited_12 = -1;
				try{
					
						Object filename_tFileInputDelimited_12 = "C:/Users/phili/OneDrive/Documents/coursS9/conceptionSID/Conception-SID/donnees/surclassement.csv";
						if(filename_tFileInputDelimited_12 instanceof java.io.InputStream){
							
			int footer_value_tFileInputDelimited_12 = 0, random_value_tFileInputDelimited_12 = -1;
			if(footer_value_tFileInputDelimited_12 >0 || random_value_tFileInputDelimited_12 > 0){
				throw new java.lang.Exception("When the input source is a stream,footer and random shouldn't be bigger than 0.");				
			}
		
						}
						try {
							fid_tFileInputDelimited_12 = new org.talend.fileprocess.FileInputDelimited("C:/Users/phili/OneDrive/Documents/coursS9/conceptionSID/Conception-SID/donnees/surclassement.csv", "US-ASCII",",","\n",false,1,0,
									limit_tFileInputDelimited_12
								,-1, false);
						} catch(java.lang.Exception e) {
globalMap.put("tFileInputDelimited_12_ERROR_MESSAGE",e.getMessage());
							
								
								System.err.println(e.getMessage());
							
						}
					
				    
					while (fid_tFileInputDelimited_12!=null && fid_tFileInputDelimited_12.nextRecord()) {
						rowstate_tFileInputDelimited_12.reset();
						
			    						row34 = null;			
												
									boolean whetherReject_tFileInputDelimited_12 = false;
									row34 = new row34Struct();
									try {
										
				int columnIndexWithD_tFileInputDelimited_12 = 0;
				
					String temp = ""; 
				
					columnIndexWithD_tFileInputDelimited_12 = 0;
					
						temp = fid_tFileInputDelimited_12.get(columnIndexWithD_tFileInputDelimited_12);
						if(temp.length() > 0) {
							
								try {
								
    								row34.IDBillet = ParserUtils.parseTo_Integer(temp);
    							
    							} catch(java.lang.Exception ex_tFileInputDelimited_12) {
globalMap.put("tFileInputDelimited_12_ERROR_MESSAGE",ex_tFileInputDelimited_12.getMessage());
									rowstate_tFileInputDelimited_12.setException(new RuntimeException(String.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
										"IDBillet", "row34", temp, ex_tFileInputDelimited_12), ex_tFileInputDelimited_12));
								}
    							
						} else {						
							
								
									row34.IDBillet = null;
								
							
						}
					
				
					columnIndexWithD_tFileInputDelimited_12 = 1;
					
						temp = fid_tFileInputDelimited_12.get(columnIndexWithD_tFileInputDelimited_12);
						if(temp.length() > 0) {
							
								try {
								
    								row34.IDClasse = ParserUtils.parseTo_Integer(temp);
    							
    							} catch(java.lang.Exception ex_tFileInputDelimited_12) {
globalMap.put("tFileInputDelimited_12_ERROR_MESSAGE",ex_tFileInputDelimited_12.getMessage());
									rowstate_tFileInputDelimited_12.setException(new RuntimeException(String.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
										"IDClasse", "row34", temp, ex_tFileInputDelimited_12), ex_tFileInputDelimited_12));
								}
    							
						} else {						
							
								
									row34.IDClasse = null;
								
							
						}
					
				
					columnIndexWithD_tFileInputDelimited_12 = 2;
					
							row34.Surclassement = fid_tFileInputDelimited_12.get(columnIndexWithD_tFileInputDelimited_12);
						
				
					columnIndexWithD_tFileInputDelimited_12 = 3;
					
						temp = fid_tFileInputDelimited_12.get(columnIndexWithD_tFileInputDelimited_12);
						if(temp.length() > 0) {
							
								try {
								
    								row34.TarifSupplementaire = ParserUtils.parseTo_Float(temp);
    							
    							} catch(java.lang.Exception ex_tFileInputDelimited_12) {
globalMap.put("tFileInputDelimited_12_ERROR_MESSAGE",ex_tFileInputDelimited_12.getMessage());
									rowstate_tFileInputDelimited_12.setException(new RuntimeException(String.format("Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
										"TarifSupplementaire", "row34", temp, ex_tFileInputDelimited_12), ex_tFileInputDelimited_12));
								}
    							
						} else {						
							
								
									row34.TarifSupplementaire = null;
								
							
						}
					
				
				
										
										if(rowstate_tFileInputDelimited_12.getException()!=null) {
											throw rowstate_tFileInputDelimited_12.getException();
										}
										
										
							
			    					} catch (java.lang.Exception e) {
globalMap.put("tFileInputDelimited_12_ERROR_MESSAGE",e.getMessage());
			        					whetherReject_tFileInputDelimited_12 = true;
			        					
			                					System.err.println(e.getMessage());
			                					row34 = null;
			                				
										
			    					}
								

 



/**
 * [tFileInputDelimited_12 begin ] stop
 */
	
	/**
	 * [tFileInputDelimited_12 main ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_12";

	

 


	tos_count_tFileInputDelimited_12++;

/**
 * [tFileInputDelimited_12 main ] stop
 */
	
	/**
	 * [tFileInputDelimited_12 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_12";

	

 



/**
 * [tFileInputDelimited_12 process_data_begin ] stop
 */
// Start of branch "row34"
if(row34 != null) { 



	
	/**
	 * [tUniqRow_12 main ] start
	 */

	

	
	
	currentComponent="tUniqRow_12";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row34"
						
						);
					}
					
row35.IDBillet = row34.IDBillet;			row35.IDClasse = row34.IDClasse;			row35.Surclassement = row34.Surclassement;			row35.TarifSupplementaire = row34.TarifSupplementaire;			

 


	tos_count_tUniqRow_12++;

/**
 * [tUniqRow_12 main ] stop
 */
	
	/**
	 * [tUniqRow_12 process_data_begin ] start
	 */

	

	
	
	currentComponent="tUniqRow_12";

	

 



/**
 * [tUniqRow_12 process_data_begin ] stop
 */
// Start of branch "row35"
if(row35 != null) { 



	
	/**
	 * [tSchemaComplianceCheck_12 main ] start
	 */

	

	
	
	currentComponent="tSchemaComplianceCheck_12";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row35"
						
						);
					}
					
	row36 = null;
	rsvUtil_tSchemaComplianceCheck_12.setRowValue_0(row35);
	if (rsvUtil_tSchemaComplianceCheck_12.ifPassedThrough) {
		row36 = new row36Struct();
		row36.IDBillet = row35.IDBillet;
		row36.IDClasse = row35.IDClasse;
		row36.Surclassement = row35.Surclassement;
		row36.TarifSupplementaire = row35.TarifSupplementaire;
	}
	rsvUtil_tSchemaComplianceCheck_12.reset();

 


	tos_count_tSchemaComplianceCheck_12++;

/**
 * [tSchemaComplianceCheck_12 main ] stop
 */
	
	/**
	 * [tSchemaComplianceCheck_12 process_data_begin ] start
	 */

	

	
	
	currentComponent="tSchemaComplianceCheck_12";

	

 



/**
 * [tSchemaComplianceCheck_12 process_data_begin ] stop
 */
// Start of branch "row36"
if(row36 != null) { 



	
	/**
	 * [tMap_13 main ] start
	 */

	

	
	
	currentComponent="tMap_13";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"row36"
						
						);
					}
					

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_13 = false;
		

        // ###############################
        // # Input tables (lookups)
		  boolean rejectedInnerJoin_tMap_13 = false;
		  boolean mainRowRejected_tMap_13 = false;
            				    								  
		// ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_13__Struct Var = Var__tMap_13;// ###############################
        // ###############################
        // # Output tables

OUT_STG_FAIT_SURCLASSEMENT = null;


// # Output table : 'OUT_STG_FAIT_SURCLASSEMENT'
OUT_STG_FAIT_SURCLASSEMENT_tmp.ID_SURCLASSEMENT = Numeric.sequence("s1",1,1) ;
OUT_STG_FAIT_SURCLASSEMENT_tmp.SK_BILLET_ID = row36.IDBillet ;
OUT_STG_FAIT_SURCLASSEMENT_tmp.SK_CLASSE_ID = row36.IDClasse ;
OUT_STG_FAIT_SURCLASSEMENT_tmp.SURCLASSEMENT = "TRUE".equals(row36.Surclassement) ? 1 : 0;
OUT_STG_FAIT_SURCLASSEMENT_tmp.TARIF_SUPPLEMENTAIRE = row36.TarifSupplementaire ;
OUT_STG_FAIT_SURCLASSEMENT = OUT_STG_FAIT_SURCLASSEMENT_tmp;
// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_13 = false;










 


	tos_count_tMap_13++;

/**
 * [tMap_13 main ] stop
 */
	
	/**
	 * [tMap_13 process_data_begin ] start
	 */

	

	
	
	currentComponent="tMap_13";

	

 



/**
 * [tMap_13 process_data_begin ] stop
 */
// Start of branch "OUT_STG_FAIT_SURCLASSEMENT"
if(OUT_STG_FAIT_SURCLASSEMENT != null) { 



	
	/**
	 * [tDBOutput_12 main ] start
	 */

	

	
	
	currentComponent="tDBOutput_12";

	
					if(execStat){
						runStat.updateStatOnConnection(iterateId,1,1
						
							,"OUT_STG_FAIT_SURCLASSEMENT"
						
						);
					}
					



        whetherReject_tDBOutput_12 = false;
                    pstmt_tDBOutput_12.setInt(1, OUT_STG_FAIT_SURCLASSEMENT.ID_SURCLASSEMENT);

            int checkCount_tDBOutput_12 = -1;
            try (java.sql.ResultSet rs_tDBOutput_12 = pstmt_tDBOutput_12.executeQuery()) {
                while(rs_tDBOutput_12.next()) {
                    checkCount_tDBOutput_12 = rs_tDBOutput_12.getInt(1);
                }
            }
            if(checkCount_tDBOutput_12 > 0) {
                        pstmtUpdate_tDBOutput_12.setInt(1, OUT_STG_FAIT_SURCLASSEMENT.SK_BILLET_ID);

                        pstmtUpdate_tDBOutput_12.setInt(2, OUT_STG_FAIT_SURCLASSEMENT.SK_CLASSE_ID);

                        pstmtUpdate_tDBOutput_12.setInt(3, OUT_STG_FAIT_SURCLASSEMENT.SURCLASSEMENT);

                        if(OUT_STG_FAIT_SURCLASSEMENT.TARIF_SUPPLEMENTAIRE == null) {
pstmtUpdate_tDBOutput_12.setNull(4, java.sql.Types.FLOAT);
} else {pstmtUpdate_tDBOutput_12.setFloat(4, OUT_STG_FAIT_SURCLASSEMENT.TARIF_SUPPLEMENTAIRE);
}

                        pstmtUpdate_tDBOutput_12.setInt(5 + count_tDBOutput_12, OUT_STG_FAIT_SURCLASSEMENT.ID_SURCLASSEMENT);

                try {
                    int processedCount_tDBOutput_12 = pstmtUpdate_tDBOutput_12.executeUpdate();
                    updatedCount_tDBOutput_12 += processedCount_tDBOutput_12;
                    rowsToCommitCount_tDBOutput_12 += processedCount_tDBOutput_12;
                    nb_line_tDBOutput_12++;
                } catch(java.lang.Exception e_tDBOutput_12) {
globalMap.put("tDBOutput_12_ERROR_MESSAGE",e_tDBOutput_12.getMessage());
                    whetherReject_tDBOutput_12 = true;
                        nb_line_tDBOutput_12++;
                            System.err.print(e_tDBOutput_12.getMessage());
                }
            } else {
                        pstmtInsert_tDBOutput_12.setInt(1, OUT_STG_FAIT_SURCLASSEMENT.ID_SURCLASSEMENT);

                        pstmtInsert_tDBOutput_12.setInt(2, OUT_STG_FAIT_SURCLASSEMENT.SK_BILLET_ID);

                        pstmtInsert_tDBOutput_12.setInt(3, OUT_STG_FAIT_SURCLASSEMENT.SK_CLASSE_ID);

                        pstmtInsert_tDBOutput_12.setInt(4, OUT_STG_FAIT_SURCLASSEMENT.SURCLASSEMENT);

                        if(OUT_STG_FAIT_SURCLASSEMENT.TARIF_SUPPLEMENTAIRE == null) {
pstmtInsert_tDBOutput_12.setNull(5, java.sql.Types.FLOAT);
} else {pstmtInsert_tDBOutput_12.setFloat(5, OUT_STG_FAIT_SURCLASSEMENT.TARIF_SUPPLEMENTAIRE);
}

                try {
                    int processedCount_tDBOutput_12 = pstmtInsert_tDBOutput_12.executeUpdate();
                    insertedCount_tDBOutput_12 += processedCount_tDBOutput_12;
                    rowsToCommitCount_tDBOutput_12 += processedCount_tDBOutput_12;
                    nb_line_tDBOutput_12++;
                } catch(java.lang.Exception e_tDBOutput_12) {
globalMap.put("tDBOutput_12_ERROR_MESSAGE",e_tDBOutput_12.getMessage());
                    whetherReject_tDBOutput_12 = true;
                        nb_line_tDBOutput_12++;
                            System.err.print(e_tDBOutput_12.getMessage());
                }
            }

 


	tos_count_tDBOutput_12++;

/**
 * [tDBOutput_12 main ] stop
 */
	
	/**
	 * [tDBOutput_12 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBOutput_12";

	

 



/**
 * [tDBOutput_12 process_data_begin ] stop
 */
	
	/**
	 * [tDBOutput_12 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBOutput_12";

	

 



/**
 * [tDBOutput_12 process_data_end ] stop
 */

} // End of branch "OUT_STG_FAIT_SURCLASSEMENT"




	
	/**
	 * [tMap_13 process_data_end ] start
	 */

	

	
	
	currentComponent="tMap_13";

	

 



/**
 * [tMap_13 process_data_end ] stop
 */

} // End of branch "row36"




	
	/**
	 * [tSchemaComplianceCheck_12 process_data_end ] start
	 */

	

	
	
	currentComponent="tSchemaComplianceCheck_12";

	

 



/**
 * [tSchemaComplianceCheck_12 process_data_end ] stop
 */

} // End of branch "row35"




	
	/**
	 * [tUniqRow_12 process_data_end ] start
	 */

	

	
	
	currentComponent="tUniqRow_12";

	

 



/**
 * [tUniqRow_12 process_data_end ] stop
 */

} // End of branch "row34"




	
	/**
	 * [tFileInputDelimited_12 process_data_end ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_12";

	

 



/**
 * [tFileInputDelimited_12 process_data_end ] stop
 */
	
	/**
	 * [tFileInputDelimited_12 end ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_12";

	



            }
            }finally{
                if(!((Object)("C:/Users/phili/OneDrive/Documents/coursS9/conceptionSID/Conception-SID/donnees/surclassement.csv") instanceof java.io.InputStream)){
                	if(fid_tFileInputDelimited_12!=null){
                		fid_tFileInputDelimited_12.close();
                	}
                }
                if(fid_tFileInputDelimited_12!=null){
                	globalMap.put("tFileInputDelimited_12_NB_LINE", fid_tFileInputDelimited_12.getRowNumber());
					
                }
			}
			  

 

ok_Hash.put("tFileInputDelimited_12", true);
end_Hash.put("tFileInputDelimited_12", System.currentTimeMillis());




/**
 * [tFileInputDelimited_12 end ] stop
 */

	
	/**
	 * [tUniqRow_12 end ] start
	 */

	

	
	
	currentComponent="tUniqRow_12";

	

globalMap.put("tUniqRow_12_NB_UNIQUES",nb_uniques_tUniqRow_12);
globalMap.put("tUniqRow_12_NB_DUPLICATES",nb_duplicates_tUniqRow_12);

				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row34");
			  	}
			  	
 

ok_Hash.put("tUniqRow_12", true);
end_Hash.put("tUniqRow_12", System.currentTimeMillis());




/**
 * [tUniqRow_12 end ] stop
 */

	
	/**
	 * [tSchemaComplianceCheck_12 end ] start
	 */

	

	
	
	currentComponent="tSchemaComplianceCheck_12";

	

				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row35");
			  	}
			  	
 

ok_Hash.put("tSchemaComplianceCheck_12", true);
end_Hash.put("tSchemaComplianceCheck_12", System.currentTimeMillis());




/**
 * [tSchemaComplianceCheck_12 end ] stop
 */

	
	/**
	 * [tMap_13 end ] start
	 */

	

	
	
	currentComponent="tMap_13";

	


// ###############################
// # Lookup hashes releasing
// ###############################      





				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"row36");
			  	}
			  	
 

ok_Hash.put("tMap_13", true);
end_Hash.put("tMap_13", System.currentTimeMillis());




/**
 * [tMap_13 end ] stop
 */

	
	/**
	 * [tDBOutput_12 end ] start
	 */

	

	
	
	currentComponent="tDBOutput_12";

	
	



	
        if(pstmtUpdate_tDBOutput_12 != null){
            pstmtUpdate_tDBOutput_12.close();
            resourceMap.remove("pstmtUpdate_tDBOutput_12");
        }
        if(pstmtInsert_tDBOutput_12 != null){
            pstmtInsert_tDBOutput_12.close();
            resourceMap.remove("pstmtInsert_tDBOutput_12");
        }
        if(pstmt_tDBOutput_12 != null) {
            pstmt_tDBOutput_12.close();
            resourceMap.remove("pstmt_tDBOutput_12");
        }
    resourceMap.put("statementClosed_tDBOutput_12", true);

	
	nb_line_deleted_tDBOutput_12=nb_line_deleted_tDBOutput_12+ deletedCount_tDBOutput_12;
	nb_line_update_tDBOutput_12=nb_line_update_tDBOutput_12 + updatedCount_tDBOutput_12;
	nb_line_inserted_tDBOutput_12=nb_line_inserted_tDBOutput_12 + insertedCount_tDBOutput_12;
	nb_line_rejected_tDBOutput_12=nb_line_rejected_tDBOutput_12 + rejectedCount_tDBOutput_12;
	
        globalMap.put("tDBOutput_12_NB_LINE",nb_line_tDBOutput_12);
        globalMap.put("tDBOutput_12_NB_LINE_UPDATED",nb_line_update_tDBOutput_12);
        globalMap.put("tDBOutput_12_NB_LINE_INSERTED",nb_line_inserted_tDBOutput_12);
        globalMap.put("tDBOutput_12_NB_LINE_DELETED",nb_line_deleted_tDBOutput_12);
        globalMap.put("tDBOutput_12_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_12);
    

	



				if(execStat){
			  		runStat.updateStat(resourceMap,iterateId,2,0,"OUT_STG_FAIT_SURCLASSEMENT");
			  	}
			  	
 

ok_Hash.put("tDBOutput_12", true);
end_Hash.put("tDBOutput_12", System.currentTimeMillis());




/**
 * [tDBOutput_12 end ] stop
 */












				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tFileInputDelimited_12:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk15", 0, "ok");
								} 
							
							tDBCommit_1Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFileInputDelimited_12 finally ] start
	 */

	

	
	
	currentComponent="tFileInputDelimited_12";

	

 



/**
 * [tFileInputDelimited_12 finally ] stop
 */

	
	/**
	 * [tUniqRow_12 finally ] start
	 */

	

	
	
	currentComponent="tUniqRow_12";

	

 



/**
 * [tUniqRow_12 finally ] stop
 */

	
	/**
	 * [tSchemaComplianceCheck_12 finally ] start
	 */

	

	
	
	currentComponent="tSchemaComplianceCheck_12";

	

 



/**
 * [tSchemaComplianceCheck_12 finally ] stop
 */

	
	/**
	 * [tMap_13 finally ] start
	 */

	

	
	
	currentComponent="tMap_13";

	

 



/**
 * [tMap_13 finally ] stop
 */

	
	/**
	 * [tDBOutput_12 finally ] start
	 */

	

	
	
	currentComponent="tDBOutput_12";

	



    if (resourceMap.get("statementClosed_tDBOutput_12") == null) {
                java.sql.PreparedStatement pstmtUpdateToClose_tDBOutput_12 = null;
                if ((pstmtUpdateToClose_tDBOutput_12 = (java.sql.PreparedStatement) resourceMap.remove("pstmtUpdate_tDBOutput_12")) != null) {
                    pstmtUpdateToClose_tDBOutput_12.close();
                }
                java.sql.PreparedStatement pstmtInsertToClose_tDBOutput_12 = null;
                if ((pstmtInsertToClose_tDBOutput_12 = (java.sql.PreparedStatement) resourceMap.remove("pstmtInsert_tDBOutput_12")) != null) {
                    pstmtInsertToClose_tDBOutput_12.close();
                }
                java.sql.PreparedStatement pstmtToClose_tDBOutput_12 = null;
                if ((pstmtToClose_tDBOutput_12 = (java.sql.PreparedStatement) resourceMap.remove("pstmt_tDBOutput_12")) != null) {
                    pstmtToClose_tDBOutput_12.close();
                }
    }
 



/**
 * [tDBOutput_12 finally ] stop
 */












				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFileInputDelimited_12_SUBPROCESS_STATE", 1);
	}
	

public void tDBCommit_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBCommit_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [tDBCommit_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBCommit_1", false);
		start_Hash.put("tDBCommit_1", System.currentTimeMillis());
		
	
	currentComponent="tDBCommit_1";

	
		int tos_count_tDBCommit_1 = 0;
		

 



/**
 * [tDBCommit_1 begin ] stop
 */
	
	/**
	 * [tDBCommit_1 main ] start
	 */

	

	
	
	currentComponent="tDBCommit_1";

	

	java.sql.Connection conn_tDBCommit_1 = (java.sql.Connection)globalMap.get("conn_tDBConnection_2");

if(conn_tDBCommit_1 != null && !conn_tDBCommit_1.isClosed()) {
	
		try{
	
			
			conn_tDBCommit_1.commit();
			
	
		}finally{
			
			conn_tDBCommit_1.close();
			
			if("com.mysql.cj.jdbc.Driver".equals((String)globalMap.get("driverClass_tDBConnection_2"))
			    && routines.system.BundleUtils.inOSGi()) {
			        Class.forName("com.mysql.cj.jdbc.AbandonedConnectionCleanupThread").
			            getMethod("checkedShutdown").invoke(null, (Object[]) null);
			}
			
	    }
	
}

 


	tos_count_tDBCommit_1++;

/**
 * [tDBCommit_1 main ] stop
 */
	
	/**
	 * [tDBCommit_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBCommit_1";

	

 



/**
 * [tDBCommit_1 process_data_begin ] stop
 */
	
	/**
	 * [tDBCommit_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBCommit_1";

	

 



/**
 * [tDBCommit_1 process_data_end ] stop
 */
	
	/**
	 * [tDBCommit_1 end ] start
	 */

	

	
	
	currentComponent="tDBCommit_1";

	

 

ok_Hash.put("tDBCommit_1", true);
end_Hash.put("tDBCommit_1", System.currentTimeMillis());




/**
 * [tDBCommit_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBCommit_1 finally ] start
	 */

	

	
	
	currentComponent="tDBCommit_1";

	

 



/**
 * [tDBCommit_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBCommit_1_SUBPROCESS_STATE", 1);
	}
	
    public String resuming_logs_dir_path = null;
    public String resuming_checkpoint_path = null;
    public String parent_part_launcher = null;
    private String resumeEntryMethodName = null;
    private boolean globalResumeTicket = false;

    public boolean watch = false;
    // portStats is null, it means don't execute the statistics
    public Integer portStats = null;
    public int portTraces = 4334;
    public String clientHost;
    public String defaultClientHost = "localhost";
    public String contextStr = "Default";
    public boolean isDefaultContext = true;
    public String pid = "0";
    public String rootPid = null;
    public String fatherPid = null;
    public String fatherNode = null;
    public long startTime = 0;
    public boolean isChildJob = false;
    public String log4jLevel = "";
    
    private boolean enableLogStash;

    private boolean execStat = true;

    private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
        protected java.util.Map<String, String> initialValue() {
            java.util.Map<String,String> threadRunResultMap = new java.util.HashMap<String, String>();
            threadRunResultMap.put("errorCode", null);
            threadRunResultMap.put("status", "");
            return threadRunResultMap;
        };
    };


    protected PropertiesWithType context_param = new PropertiesWithType();
    public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

    public String status= "";
    

    public static void main(String[] args){
        final STG_Load STG_LoadClass = new STG_Load();

        int exitCode = STG_LoadClass.runJobInTOS(args);

        System.exit(exitCode);
    }


    public String[][] runJob(String[] args) {

        int exitCode = runJobInTOS(args);
        String[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };

        return bufferValue;
    }

    public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;
    	
        return hastBufferOutput;
    }

    public int runJobInTOS(String[] args) {
	   	// reset status
	   	status = "";
	   	
        String lastStr = "";
        for (String arg : args) {
            if (arg.equalsIgnoreCase("--context_param")) {
                lastStr = arg;
            } else if (lastStr.equals("")) {
                evalParam(arg);
            } else {
                evalParam(lastStr + " " + arg);
                lastStr = "";
            }
        }
        enableLogStash = "true".equalsIgnoreCase(System.getProperty("audit.enabled"));

    	
    	

        if(clientHost == null) {
            clientHost = defaultClientHost;
        }

        if(pid == null || "0".equals(pid)) {
            pid = TalendString.getAsciiRandomString(6);
        }

        if (rootPid==null) {
            rootPid = pid;
        }
        if (fatherPid==null) {
            fatherPid = pid;
        }else{
            isChildJob = true;
        }

        if (portStats != null) {
            // portStats = -1; //for testing
            if (portStats < 0 || portStats > 65535) {
                // issue:10869, the portStats is invalid, so this client socket can't open
                System.err.println("The statistics socket port " + portStats + " is invalid.");
                execStat = false;
            }
        } else {
            execStat = false;
        }
        boolean inOSGi = routines.system.BundleUtils.inOSGi();

        if (inOSGi) {
            java.util.Dictionary<String, Object> jobProperties = routines.system.BundleUtils.getJobProperties(jobName);

            if (jobProperties != null && jobProperties.get("context") != null) {
                contextStr = (String)jobProperties.get("context");
            }
        }

        try {
            //call job/subjob with an existing context, like: --context=production. if without this parameter, there will use the default context instead.
            java.io.InputStream inContext = STG_Load.class.getClassLoader().getResourceAsStream("local_project/stg_load_0_1/contexts/" + contextStr + ".properties");
            if (inContext == null) {
                inContext = STG_Load.class.getClassLoader().getResourceAsStream("config/contexts/" + contextStr + ".properties");
            }
            if (inContext != null) {
                try {
                    //defaultProps is in order to keep the original context value
                    if(context != null && context.isEmpty()) {
	                defaultProps.load(inContext);
	                context = new ContextProperties(defaultProps);
                    }
                } finally {
                    inContext.close();
                }
            } else if (!isDefaultContext) {
                //print info and job continue to run, for case: context_param is not empty.
                System.err.println("Could not find the context " + contextStr);
            }

            if(!context_param.isEmpty()) {
                context.putAll(context_param);
				//set types for params from parentJobs
				for (Object key: context_param.keySet()){
					String context_key = key.toString();
					String context_type = context_param.getContextType(context_key);
					context.setContextType(context_key, context_type);

				}
            }
            class ContextProcessing {
                private void processContext_0() {
                        context.setContextType("AIRLINE_AdditionalParams", "id_String");
                        if(context.getStringValue("AIRLINE_AdditionalParams") == null) {
                            context.AIRLINE_AdditionalParams = null;
                        } else {
                            context.AIRLINE_AdditionalParams=(String) context.getProperty("AIRLINE_AdditionalParams");
                        }
                        context.setContextType("AIRLINE_Login", "id_String");
                        if(context.getStringValue("AIRLINE_Login") == null) {
                            context.AIRLINE_Login = null;
                        } else {
                            context.AIRLINE_Login=(String) context.getProperty("AIRLINE_Login");
                        }
                        context.setContextType("AIRLINE_Password", "id_Password");
                        if(context.getStringValue("AIRLINE_Password") == null) {
                            context.AIRLINE_Password = null;
                        } else {
                            String pwd_AIRLINE_Password_value = context.getProperty("AIRLINE_Password");
                            context.AIRLINE_Password = null;
                            if(pwd_AIRLINE_Password_value!=null) {
                                if(context_param.containsKey("AIRLINE_Password")) {//no need to decrypt if it come from program argument or parent job runtime
                                    context.AIRLINE_Password = pwd_AIRLINE_Password_value;
                                } else if (!pwd_AIRLINE_Password_value.isEmpty()) {
                                    try {
                                        context.AIRLINE_Password = routines.system.PasswordEncryptUtil.decryptPassword(pwd_AIRLINE_Password_value);
                                        context.put("AIRLINE_Password",context.AIRLINE_Password);
                                    } catch (java.lang.RuntimeException e) {
                                        //do nothing
                                    }
                                }
                            }
                        }
                        context.setContextType("AIRLINE_Port", "id_String");
                        if(context.getStringValue("AIRLINE_Port") == null) {
                            context.AIRLINE_Port = null;
                        } else {
                            context.AIRLINE_Port=(String) context.getProperty("AIRLINE_Port");
                        }
                        context.setContextType("AIRLINE_Schema", "id_String");
                        if(context.getStringValue("AIRLINE_Schema") == null) {
                            context.AIRLINE_Schema = null;
                        } else {
                            context.AIRLINE_Schema=(String) context.getProperty("AIRLINE_Schema");
                        }
                        context.setContextType("AIRLINE_Server", "id_String");
                        if(context.getStringValue("AIRLINE_Server") == null) {
                            context.AIRLINE_Server = null;
                        } else {
                            context.AIRLINE_Server=(String) context.getProperty("AIRLINE_Server");
                        }
                        context.setContextType("AIRLINE_Sid", "id_String");
                        if(context.getStringValue("AIRLINE_Sid") == null) {
                            context.AIRLINE_Sid = null;
                        } else {
                            context.AIRLINE_Sid=(String) context.getProperty("AIRLINE_Sid");
                        }
                        context.setContextType("source_path", "id_String");
                        if(context.getStringValue("source_path") == null) {
                            context.source_path = null;
                        } else {
                            context.source_path=(String) context.getProperty("source_path");
                        }
                } 
                public void processAllContext() {
                        processContext_0();
                }
            }

            new ContextProcessing().processAllContext();
        } catch (java.io.IOException ie) {
            System.err.println("Could not load context "+contextStr);
            ie.printStackTrace();
        }

        // get context value from parent directly
        if (parentContextMap != null && !parentContextMap.isEmpty()) {if (parentContextMap.containsKey("AIRLINE_AdditionalParams")) {
                context.AIRLINE_AdditionalParams = (String) parentContextMap.get("AIRLINE_AdditionalParams");
            }if (parentContextMap.containsKey("AIRLINE_Login")) {
                context.AIRLINE_Login = (String) parentContextMap.get("AIRLINE_Login");
            }if (parentContextMap.containsKey("AIRLINE_Password")) {
                context.AIRLINE_Password = (java.lang.String) parentContextMap.get("AIRLINE_Password");
            }if (parentContextMap.containsKey("AIRLINE_Port")) {
                context.AIRLINE_Port = (String) parentContextMap.get("AIRLINE_Port");
            }if (parentContextMap.containsKey("AIRLINE_Schema")) {
                context.AIRLINE_Schema = (String) parentContextMap.get("AIRLINE_Schema");
            }if (parentContextMap.containsKey("AIRLINE_Server")) {
                context.AIRLINE_Server = (String) parentContextMap.get("AIRLINE_Server");
            }if (parentContextMap.containsKey("AIRLINE_Sid")) {
                context.AIRLINE_Sid = (String) parentContextMap.get("AIRLINE_Sid");
            }if (parentContextMap.containsKey("source_path")) {
                context.source_path = (String) parentContextMap.get("source_path");
            }
        }

        //Resume: init the resumeUtil
        resumeEntryMethodName = ResumeUtil.getResumeEntryMethodName(resuming_checkpoint_path);
        resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
        resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName, jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
			parametersToEncrypt.add("AIRLINE_Password");
        //Resume: jobStart
        resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","","","",resumeUtil.convertToJsonText(context,parametersToEncrypt));

if(execStat) {
    try {
        runStat.openSocket(!isChildJob);
        runStat.setAllPID(rootPid, fatherPid, pid, jobName);
        runStat.startThreadStat(clientHost, portStats);
        runStat.updateStatOnJob(RunStat.JOBSTART, fatherNode);
    } catch (java.io.IOException ioException) {
        ioException.printStackTrace();
    }
}



	
	    java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
	    globalMap.put("concurrentHashMap", concurrentHashMap);
	

    long startUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
    long endUsedMemory = 0;
    long end = 0;

    startTime = System.currentTimeMillis();


this.globalResumeTicket = true;//to run tPreJob





this.globalResumeTicket = false;//to run others jobs

try {
errorCode = null;tDBConnection_2Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tDBConnection_2) {
globalMap.put("tDBConnection_2_SUBPROCESS_STATE", -1);

e_tDBConnection_2.printStackTrace();

}

this.globalResumeTicket = true;//to run tPostJob




        end = System.currentTimeMillis();

        if (watch) {
            System.out.println((end-startTime)+" milliseconds");
        }

        endUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        if (false) {
            System.out.println((endUsedMemory - startUsedMemory) + " bytes memory increase when running : STG_Load");
        }



if (execStat) {
    runStat.updateStatOnJob(RunStat.JOBEND, fatherNode);
    runStat.stopThreadStat();
}
    int returnCode = 0;


    if(errorCode == null) {
         returnCode = status != null && status.equals("failure") ? 1 : 0;
    } else {
         returnCode = errorCode.intValue();
    }
    resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","" + returnCode,"","","");

    return returnCode;

  }

    // only for OSGi env
    public void destroy() {
    closeSqlDbConnections();


    }



    private void closeSqlDbConnections() {
        try {
            Object obj_conn;
            obj_conn = globalMap.remove("conn_tDBConnection_2");
            if (null != obj_conn) {
                ((java.sql.Connection) obj_conn).close();
            }
            obj_conn = globalMap.remove("conn_tDBConnection_2");
            if (null != obj_conn) {
                ((java.sql.Connection) obj_conn).close();
            }
        } catch (java.lang.Exception e) {
        }
    }











    private java.util.Map<String, Object> getSharedConnections4REST() {
        java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();
            connections.put("conn_tDBConnection_2", globalMap.get("conn_tDBConnection_2"));
            connections.put("conn_tDBConnection_2", globalMap.get("conn_tDBConnection_2"));






        return connections;
    }

    private void evalParam(String arg) {
        if (arg.startsWith("--resuming_logs_dir_path")) {
            resuming_logs_dir_path = arg.substring(25);
        } else if (arg.startsWith("--resuming_checkpoint_path")) {
            resuming_checkpoint_path = arg.substring(27);
        } else if (arg.startsWith("--parent_part_launcher")) {
            parent_part_launcher = arg.substring(23);
        } else if (arg.startsWith("--watch")) {
            watch = true;
        } else if (arg.startsWith("--stat_port=")) {
            String portStatsStr = arg.substring(12);
            if (portStatsStr != null && !portStatsStr.equals("null")) {
                portStats = Integer.parseInt(portStatsStr);
            }
        } else if (arg.startsWith("--trace_port=")) {
            portTraces = Integer.parseInt(arg.substring(13));
        } else if (arg.startsWith("--client_host=")) {
            clientHost = arg.substring(14);
        } else if (arg.startsWith("--context=")) {
            contextStr = arg.substring(10);
            isDefaultContext = false;
        } else if (arg.startsWith("--father_pid=")) {
            fatherPid = arg.substring(13);
        } else if (arg.startsWith("--root_pid=")) {
            rootPid = arg.substring(11);
        } else if (arg.startsWith("--father_node=")) {
            fatherNode = arg.substring(14);
        } else if (arg.startsWith("--pid=")) {
            pid = arg.substring(6);
        } else if (arg.startsWith("--context_type")) {
            String keyValue = arg.substring(15);
			int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.setContextType(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.setContextType(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }

            }

		} else if (arg.startsWith("--context_param")) {
            String keyValue = arg.substring(16);
            int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.put(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.put(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }
            }
        } else if (arg.startsWith("--log4jLevel=")) {
            log4jLevel = arg.substring(13);
		} else if (arg.startsWith("--audit.enabled") && arg.contains("=")) {//for trunjob call
		    final int equal = arg.indexOf('=');
			final String key = arg.substring("--".length(), equal);
			System.setProperty(key, arg.substring(equal + 1));
		}
    }
    
    private static final String NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY = "<TALEND_NULL>";

    private final String[][] escapeChars = {
        {"\\\\","\\"},{"\\n","\n"},{"\\'","\'"},{"\\r","\r"},
        {"\\f","\f"},{"\\b","\b"},{"\\t","\t"}
        };
    private String replaceEscapeChars (String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0],currIndex);
				if (index>=0) {

					result.append(keyValue.substring(currIndex, index + strArray[0].length()).replace(strArray[0], strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left into the result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
    }

    public Integer getErrorCode() {
        return errorCode;
    }


    public String getStatus() {
        return status;
    }

    ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 *     868852 characters generated by Talend Open Studio for Data Integration 
 *     on the 9 janvier 2025 à 15:54:46 CET
 ************************************************************************************************/